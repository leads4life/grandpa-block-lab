# Hook, value and reward ladder

This is an editorial production requirement for new videos and meaningful revisions. Existing published review copies remain unchanged unless the user authorizes a revision. A structurally valid plan cannot predict watch time; viewer-retention claims require actual audience data.

Open on a concrete situation or surprising mechanism the viewer can see. State a specific benefit the film will deliver. Give an early useful answer, then open the next meaningful question. Build increasing understanding: situation → consequence → mechanism → useful limit → application. Each rung must teach something new and earn the next rung.

Record exact spoken prompt and payoff quotes, their shot IDs and local times, a new knowledge reward, the visible action that proves it, the narrator's delivery, and the supporting verified claims. Close every promise. A carrot is a specific upcoming observation that is actually delivered; “watch until the end” and unsupported product promises do not qualify.

The default planning checks expect a hook in eight seconds, a concrete reward by thirty seconds, no more than two simultaneous open questions, and no more than forty-five seconds between declared rewards or between a short promise and its payoff. These are configurable editorial heuristics, not scientifically established YouTube thresholds. Adjust them deliberately for the subject and review the result.

Visual hooks must change the viewer's understanding. Prefer a prediction followed by a visible result, a revealed interaction, a comparison whose consequence is visible, a constrained mechanical action, or a branch that visibly stops developing while its road user remains. Camera movement and background decoration alone do not satisfy a visual payoff. Avoid replaying the same graph for successive definitions.

Use different visual treatments for different jobs: a detailed street scene for a driving decision, a spatial decision model for alternatives, a clear comparison for scoring factors, and a physical workbench for hardware. Frame the cause and reveal its consequence. Rich staging, depth and lighting should make the subject easier to follow.

Audio hooks can come from a concise question, a change in emphasis, a short anticipatory pause or a quiet sound tied to a visible mechanical action. Preserve the selected narrator and the measured natural pace near179wpm. Do not slow the whole passage, force speech into a time slot, add music, introduce extra characters or use repeated arbitrary whooshes. Auditory quality needs an actual audition; word-rate and level checks cannot prove engaging delivery.

Before recording production approval, measure and freeze narration; fit the actual hook/payoff times to it; inspect the representative animation and audition delivery. Record a current editorial review tied to the script, sources, timing and frozen speech. Source or timing changes make that review stale. The retention checker verifies structure, exact-quote anchors, support references, paid promises and review freshness. Codex must still judge whether a reveal is clear, interesting and truthful.

The Tesla v1 audit found a useful opening and teaching content but no explicit enforced reward ladder. Its technical/media QA pass is not a retention pass. Treat the new script and visual sample as revision proposals, not proof that the delivered v1 already contains these improvements.
