"""Technical explainer production tools; independent of Grandpa's scene content."""
