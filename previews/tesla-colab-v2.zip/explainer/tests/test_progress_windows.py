import unittest
from explainer.progress_media.sneak_peeks import windows,chunks


class ProgressWindowTests(unittest.TestCase):
    def test_full_thirty_second_windows_cover_the_tail_without_padding(self):
        result=windows(6239)
        self.assertEqual(result,[(0,900),(900,1800),(1800,2700),(2700,3600),(3600,4500),(4500,5400),(5339,6239)])
        self.assertTrue(all(end-start==900 for start,end in result))

    def test_cross_chapter_window_preserves_every_source_frame_once(self):
        shots=[{'id':'a','frames':709},{'id':'b','frames':723}]
        self.assertEqual(chunks(shots,0,900),[(shots[0],0,709),(shots[1],0,191)])
        self.assertEqual(chunks(shots,700,710),[(shots[0],700,709),(shots[1],0,1)])
        with self.assertRaises(ValueError):chunks(shots,0,1500)

    def test_short_and_exact_videos_need_no_repeated_footage(self):
        self.assertEqual(windows(900),[(0,900)])
        self.assertEqual(windows(600),[(0,600)])
        with self.assertRaises(ValueError):windows(0)
