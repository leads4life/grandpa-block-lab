# Colab production package

Open `Tesla_Explainer_Colab.ipynb` in Google Colab, select a GPU runtime if available, and follow the cells in order. Upload the ZIP when prompted. The notebook validates file hashes, creates a separate Python 3.13 render environment, tests actual rendering, then reuses the completed chapters and renders only missing chapters.

The package includes the original procedural engine/model/camera sources, topic bibles and source-backed plan, master project JSON, frozen narration, the approved opening, completed checked chapters and QA records. Native frame sequences, temporary denoise files and voice weight binaries are excluded. All film geometry is original schematic work, not manufacturer CAD. No new speech generation or AI API key is required to resume the bundled film.

GPU support depends on the Colab device, driver and Blender wheel. The smoke cell reports what device actually renders. A CPU-only runtime works but will be slower. The notebook does not claim the final video passed actual visual review merely because encoding succeeded.

For a new episode, create a separate project and use the full engine intake/research/approval workflow. New narration additionally requires the full dependencies in `explainer/requirements.txt` and the matching Kokoro model and voices. Do not replace the frozen Tesla narration while resuming this snapshot.

The package builder takes a consistent snapshot of completed clips; an unfinished clip is excluded. Local cloud production continues independently. Outputs stay inside the extracted project; nothing is automatically published.
