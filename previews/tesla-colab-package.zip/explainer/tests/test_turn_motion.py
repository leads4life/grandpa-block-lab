import math
import unittest
from explainer.turn_motion import pose,circle_clearance,rectangles_overlap
class TurnMotion(unittest.TestCase):
 def test_vehicle_waits_before_conflicts_clear(self):
  for t in [0,2,4,6.69]:self.assertEqual(pose(t,18)['ev'],(1.8,-8.5,0))
 def test_turn_ends_in_right_hand_westbound_lane(self):
  p=pose(18,18)['ev'];self.assertAlmostEqual(p[0],-11);self.assertAlmostEqual(p[1],1.8);self.assertAlmostEqual(p[2],math.pi/2)
 def test_all_sampled_actors_stay_separated(self):
  for i in range(1081):
   p=pose(i/60,18)
   self.assertFalse(rectangles_overlap(p['ev'],p['other']))
   for car in [p['ev'],p['other']]:self.assertGreater(circle_clearance(car,p['pedestrian']),.1)
 def test_distance_is_monotonic(self):
  d=[pose(i/60,18)['ev_distance'] for i in range(1081)]
  self.assertTrue(all(b>=a for a,b in zip(d,d[1:])))
