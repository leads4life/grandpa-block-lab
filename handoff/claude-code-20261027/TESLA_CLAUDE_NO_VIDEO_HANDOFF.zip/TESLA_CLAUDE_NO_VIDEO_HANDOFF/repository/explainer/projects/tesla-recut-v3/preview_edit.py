"""Bounded opening edit study; no full rendering or approval mutations."""
from pathlib import Path
import hashlib,json,math,os,re,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.io import wavfile
from scipy.signal import resample_poly
from kokoro_onnx import Kokoro
from explainer.core import VOICE_DELIVERY
from explainer.media import synthesize_paced,mix_mechanical,check_video
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/opening-edit';BASE=ROOT.parent/'tesla-hw3/build/full-v2'
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 OUT.mkdir(parents=True,exist_ok=True);draft=read(ROOT/'recut-draft.json');text=draft['scenes'][0]['narration']
 if (OUT/'voice.json').exists():
  v=read(OUT/'voice.json');assert v['text']==text and sha(OUT/'voice.wav')==v['sha256']
 else:
  engine=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES']);parts=re.split(r'(?<=[.!?])\s+',text)
  class Thoughts:
   def create(self,text,voice,speed,**delivery):
    arrays=[];self.groups=[];cursor=0;sr0=None
    for k,part in enumerate(parts):
     a,sr=engine.create(part,voice=voice,speed=speed,**delivery)[:2];a=np.asarray(a,dtype=np.float64)
     active=np.flatnonzero(np.abs(a)>np.abs(a).max()*.005);assert len(active)
     a=a[max(0,active[0]-round(sr*.025)):min(len(a),active[-1]+round(sr*.055))]
     if sr0 is not None:assert sr==sr0
     sr0=sr;self.groups.append({'text':part,'start':cursor/sr,'seconds':len(a)/sr});arrays.append(a);cursor+=len(a)
     if k<len(parts)-1:
      gap=np.zeros(round(sr*(.13 if part.endswith('?') else .08)));arrays.append(gap);cursor+=len(gap)
    return np.concatenate(arrays),sr0
  grouped=Thoughts();samples,sr,speed,attempts=synthesize_paced(grouped,text,'am_fenrir',1.24,VOICE_DELIVERY,target=179,tolerance=7,max_attempts=5)
  div=math.gcd(int(sr),48000);samples=resample_poly(samples,48000//div,int(sr)//div);samples*=.7/np.abs(samples).max()
  lead=.12;tail=.45;samples=np.concatenate([np.zeros(round(lead*48000)),samples,np.zeros(round(tail*48000))]);seconds=math.ceil(len(samples)/48000*30)/30;samples=np.pad(samples,(0,round(seconds*48000)-len(samples)))
  wavfile.write(OUT/'voice.wav',48000,(samples*32767).astype(np.int16))
  v={'text':text,'voice':'am_fenrir','synthesis_speed':speed,'seconds':seconds,'measured_words_per_minute':attempts[-1]['words_per_minute'],'pace_attempts':attempts,'thought_groups':[dict(g,start=g['start']+lead) for g in grouped.groups],'sha256':sha(OUT/'voice.wav'),'speech_time_stretched':False,'model_sha256':sha(os.environ['KOKORO_MODEL']),'voices_sha256':sha(os.environ['KOKORO_VOICES'])};write(OUT/'voice.json',v)
 print('VOICE FROZEN',v['seconds'],v['measured_words_per_minute'],flush=True)
 groups=v['thought_groups']
 def event(needle):return next(g['start'] for g in groups if needle in g['text'])
 at_intersection=event('Look at this');at_growth=event('Each choice');at_prune=event('The useful trick');at_patent=event("Tesla's planning");at_follow=event('Follow one turn')
 cuts=[0,min(4.5,at_intersection*.5),at_intersection,at_growth,at_prune,at_patent,at_follow,v['seconds']]
 specs=[('chip','HARDWARE LIMITS?', 'r7',0),('split','MORE HARDWARE?                         LESS SEARCH?',None,0),('street','TURN / CREEP / WAIT','r1',2.43),('growth','CHOICES MULTIPLY','r2',3),('prune','STOP DEVELOPING POOR OPTIONS','r6',3.8),('patent','US20260105614A1 · PLANNING APPLICATION','r3',4.5),('follow','SEARCH EFFICIENCY ≠ HARDWARE ELIGIBILITY','r8',7)]
 clips=[];edits=[]
 for i,(kind,title,chapter,start) in enumerate(specs):
  duration=cuts[i+1]-cuts[i];frames=round(cuts[i+1]*30)-round(cuts[i]*30);duration=frames/30;clip=OUT/f'edit-{i:02}.mp4'
  overlay=Image.new('RGBA',(960,540),(0,0,0,0));d=ImageDraw.Draw(overlay);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',22);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
  d.rectangle((0,0,960,78),fill='#091620');d.text((22,29),title,font=font,fill='#d7f8ff');d.rectangle((0,512,960,540),fill='#091620');d.text((14,520),'Original schematic 3D · illustrative search · no Tesla performance measurement',font=small,fill='#c3d5df');overlay.save(OUT/f'overlay-{i:02}.png')
  if kind=='split':
   inputs=['-ss','2','-i',str(BASE/'r7/chapter.mp4'),'-ss','1','-i',str(BASE/'r2/chapter.mp4'),'-i',str(OUT/f'overlay-{i:02}.png')]
   filters=f'[0:v]trim=duration={duration},setpts=PTS-STARTPTS,crop=640:432:160:78,scale=480:432[left];[1:v]trim=duration={duration},setpts=PTS-STARTPTS,scale=480:270,pad=480:432:0:120:color=0x091620[right];[left][right]hstack,pad=960:540:0:78:color=0x091620[base];[base][2:v]overlay=0:0[out]'
  else:
   inputs=['-ss',str(start),'-i',str(BASE/chapter/'chapter.mp4'),'-i',str(OUT/f'overlay-{i:02}.png')]
   filters=f'[0:v]trim=duration={duration},setpts=PTS-STARTPTS[base];[base][1:v]overlay=0:0[out]'
  subprocess.run(['ffmpeg','-v','error','-y',*inputs,'-filter_complex',filters,'-map','[out]','-an','-frames:v',str(frames),'-r','30','-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p',str(clip)],check=True)
  clips.append(clip);edits.append({'kind':kind,'film_start':sum(x['seconds'] for x in edits),'seconds':duration,'frames':frames,'source_chapter':chapter or ['r7','r2'],'source_start':start if chapter else [2,1],'source_shas':{x:sha(BASE/x/'chapter.mp4') for x in ([chapter] if chapter else ['r7','r2'])}})
  print('EDIT COMPLETE',kind,duration,flush=True)
 seconds=sum(x['seconds'] for x in edits);assert abs(seconds-v['seconds'])<.034
 (OUT/'concat.txt').write_text(''.join("file '"+str(c)+"'\n" for c in clips))
 video_only=OUT/'picture.mp4';subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(OUT/'concat.txt'),'-an','-c:v','copy',str(video_only)],check=True)
 cue=at_prune+1.7;mix_mechanical({'id':'recut-v3-opening','sfx':[{'kind':'click','at':cue,'duration':.12,'purpose':'Quiet illustrative mechanical click at visible candidate rejection.'}]},OUT/'voice.wav',OUT/'mix.wav',seconds)
 video=OUT/'tesla-recut-v3-opening-edit.mp4'
 gain=1.0
 for attempt in range(4):
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(video_only),'-i',str(OUT/'mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:level=false:latency=1,apad','-c:a','aac','-ar','48000','-t',str(seconds),'-movflags','+faststart',str(video)],check=True)
  qa=check_video(video,seconds,960,540)
  print('MEDIA CHECK',attempt,qa,flush=True)
  if qa['passed']:break
  gain+=-14-qa['lufs']
 assert qa['passed'],qa;qa.update(status='pending_actual_decoded_visual_review',visual_review='pending',voice_audition='pending_user_judgment',seconds=seconds,video_sha256=sha(video),script_sha256=sha(ROOT/'recut-draft.json'),source_scope='First-scene edit study using completed v2 moving footage; new final scene assets and full recut are not built.',full_production_approval='not_recorded',preview_approval='not_recorded',native_new_3d_frames=0,music=False,narration_captions=False)
 write(OUT/'qa.json',qa);write(OUT/'edit-decisions.json',edits)
 review=OUT/'decoded';review.mkdir(exist_ok=True);subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-vf',"select='not(mod(n,30))'",'-fps_mode','vfr',str(review/'%03d.png')],check=True)
 images=sorted(review.glob('*.png'))
 for start in range(0,len(images),12):
  sheet=Image.new('RGB',(1440,300*((min(12,len(images)-start)+2)//3)),'#081420');d=ImageDraw.Draw(sheet)
  for i,f in enumerate(images[start:start+12]):
   with Image.open(f) as im:sheet.paste(im.resize((480,270)),(i%3*480,i//3*300))
   d.text((i%3*480+8,i//3*300+277),f'Opening {start+i}s',fill='white')
  sheet.save(OUT/f'decoded-{start//12:02}.jpg',quality=95)
 print('EDIT STUDY READY FOR ACTUAL INSPECTION',seconds,flush=True)
if __name__=='__main__':main()
