"""Original staged technical sets for the authorized Tesla revision; no OEM assets."""
import math
import bpy
from mathutils import Vector
from explainer.traffic_scene import cube
from explainer.visual_tools import material, line
from explainer.vehicle_prop import build_vehicle
from explainer.compute_scene import build_compute
from explainer.blender_backend import aim


def empty(name, parent=None):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.parent=parent;return o


def sphere(name,pos,radius,mat,parent=None):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=radius,location=pos)
    o=bpy.context.object;o.name=name;o.parent=parent;o.data.materials.append(mat);return o


def clone(source,name,parent=None):
    o=source.copy();o.name=name;bpy.context.collection.objects.link(o);o.parent=parent
    for child in source.children:clone(child,name+' '+child.name,o)
    return o


def visible(root,show):
    hidden=not show
    if root.hide_render!=hidden:root.hide_render=hidden
    for child in root.children_recursive:
        if child.hide_render!=hidden:child.hide_render=hidden


def palette():
    def matte(name,c):
        m=material(name,(*c,1));p=m.node_tree.nodes['Principled BSDF'];p.inputs['Metallic'].default_value=0;p.inputs['Roughness'].default_value=.7;return m
    return dict(navy=matte('Deep blue studio',(.014,.026,.044)),road=matte('Asphalt',(.055,.072,.085)),
                paving=matte('Cut stone',(.28,.35,.4)),building=matte('Architecture',(.23,.31,.38)),
                leaves=matte('Foliage',(.045,.2,.14)),wood=matte('Warm timber',(.18,.085,.035)),
                paint=matte('Lane paint',(.74,.83,.86)),rim=matte('Display structure',(.08,.13,.18)),
                coat=matte('Road-user coat',(.8,.3,.035)),skin=matte('Skin',(.54,.32,.2)),
                cyan=material('Selected candidate',(.025,.68,.95,1),True),amber=material('Warm interior',(.95,.48,.15,1),True),
                muted=material('Other candidates',(.18,.32,.41,1),True),red=material('Stopped candidate',(.87,.18,.07,1),True))


def studio(scene,m):
    scene.world=bpy.data.worlds.new('Studio sky');scene.world.use_nodes=True
    scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.045,.075,.12,1)
    scene.world.node_tree.nodes['Background'].inputs[1].default_value=.5
    nodes=scene.world.node_tree.nodes;links=scene.world.node_tree.links
    camera_bg=nodes.new('ShaderNodeBackground');camera_bg.inputs['Color'].default_value=(.0003,.0006,.0012,1)
    rays=nodes.new('ShaderNodeLightPath');mix=nodes.new('ShaderNodeMixShader')
    links.new(rays.outputs['Is Camera Ray'],mix.inputs[0]);links.new(nodes['Background'].outputs[0],mix.inputs[1]);links.new(camera_bg.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],nodes['World Output'].inputs['Surface'])
    # The large floor has no nearby wall/cove edge to enter a low camera.
    cube('Continuous studio floor',(0,0,-.9),(4000,4000,.8),m['navy'],bevel=0)
    for name,pos,power,size,color in [('Soft key',(-10,-12,20),4300,13,(.88,.94,1)),('Cool rim',(15,14,23),7000,12,(.38,.7,1)),('Warm fill',(-17,6,12),3000,10,(1,.7,.42))]:
        d=bpy.data.lights.new(name,'AREA');d.energy=power;d.size=size;d.color=color
        o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=pos;aim(o,(0,3,2))


def tree(name,x,y,z,m,scale=1,parent=None):
    cube(name+' trunk',(x,y,z+.65*scale),(.15*scale,.15*scale,1.3*scale),m['wood'],parent,.025)
    for dx,dy,dz,r in [(-.35,0,1.5,.68),(.35,.1,1.7,.72),(0,-.15,2.1,.6)]:
        sphere(name+' crown',(x+dx*scale,y+dy*scale,z+dz*scale),r*scale,m['leaves'],parent)


def house(name,x,y,z,m,scale=1,parent=None):
    cube(name,(x,y,z+1.5*scale),(3*scale,2.7*scale,3*scale),m['building'],parent,.08*scale)
    cube(name+' cornice',(x,y,z+3.08*scale),(3.22*scale,2.92*scale,.18*scale),m['rim'],parent,.025)
    for row in [0,1]:
        for col in [-1,0,1]:cube(name+' window',(x+col*.8*scale,y-1.36*scale,z+(.85+row*1.25)*scale),(.48*scale,.035,.72*scale),m['amber'],parent,.01)
    cube(name+' entry',(x,y-1.38*scale,z+.52*scale),(.55*scale,.05,1.04*scale),m['rim'],parent,.015)


def street(m,extended=False):
    width,length=(36,40) if extended else (17,23)
    cube('Cutaway neighborhood',(0,0,-.25),(width,length,.5),m['rim'],bevel=.2)
    cube('City paving',(0,0,.025),(width-.3,length-.3,.08),m['paving'],bevel=.15)
    cube('North south road',(0,0,.076),(8.4,length-.3,.035),m['road'],bevel=0)
    cube('East west road',(0,0,.080),(width-.3,8.4,.035),m['road'],bevel=0)
    for y in range(-int(length/2)+2,int(length/2)-1,3):
        if abs(y)>4.4:cube('Center dash',(0,y,.107),(.09,1.3,.012),m['paint'],bevel=0)
    for x in range(-int(width/2)+2,int(width/2)-1,3):
        if abs(x)>4.4:cube('Cross-street dash',(x,0,.11),(1.3,.09,.012),m['paint'],bevel=0)
    for x in [-3.2,-2.1,-1, .1,1.2,2.3,3.4]:
        for sign in [-1,1]:cube('Crosswalk',(x,sign*5,.12),(.48,1,.014),m['paint'],bevel=0)
    for sign in [-1,1]:
        x=sign*(9.3 if extended else 6.6)
        for y in ([-13,-7,8,15] if extended else [7.2]):house('Street architecture',x,y,.07,m,1.05 if extended else .85)
        for y in ([-10,8,15] if extended else [-7.6,4.5]):
            tx=sign*(6.8 if extended else 6.4)
            cube('Planted verge',(tx,y,.13),(2.7,2.6,.16),m['leaves'],bevel=.15);tree('Street tree',tx,y,.07,m,.8)
        cube('Bench seat',(sign*5.7,-6.7,.58),(.5,1.5,.14),m['wood'],bevel=.04)
        for dy in [-.55,.55]:cube('Bench support',(sign*5.7,-6.7+dy,.32),(.38,.09,.5),m['rim'],bevel=.025)
        for y in [-9,6.5]:
            cube('Streetlight',(sign*4.8,y,1.8),(.1,.1,3.6),m['rim']);cube('Light aperture',(sign*4.8,y,3.55),(.35,.35,.1),m['amber'])
        cube('Cutaway lit edge',(sign*(width/2-.1),0,-.08),(.035,length-.5,.04),m['cyan'],bevel=.01)


def person(name,m,parent=None):
    root=empty(name,parent);limbs=[]
    cube(name+' coat',(0,0,1.15),(.42,.26,.58),m['coat'],root,.06)
    sphere(name+' head',(0,0,1.62),.16,m['skin'],root)
    for sign in [-1,1]:
        leg=cube(name+' leg',(sign*.12,0,.48),(.15,.18,.75),m['rim'],root,.035)
        arm=cube(name+' sleeve',(sign*.28,0,1.08),(.13,.17,.5),m['coat'],root,.035)
        shoe=cube(name+' shoe',(sign*.12,.04,.07),(.18,.31,.14),m['rim'],root,.025)
        limbs.append((sign,leg,arm,shoe))
    return root,limbs


def walking(limbs,distance):
    for sign,leg,arm,shoe in limbs:
        q=distance*math.tau/1.2+(0 if sign<0 else math.pi)
        leg.rotation_euler.x=.24*math.sin(q);arm.rotation_euler.x=-.25*math.sin(q)
        shoe.location.y=.14*math.sin(q);shoe.location.z=.07+max(0,math.cos(q))*.05


def bicycle(m):
    root=empty('Cyclist');wheels=[]
    for y in [-.65,.65]:
        bpy.ops.mesh.primitive_torus_add(major_radius=.32,minor_radius=.045,major_segments=24,minor_segments=8,location=(0,y,.37),rotation=(0,math.pi/2,0))
        o=bpy.context.object;o.parent=root;o.data.materials.append(m['rim']);wheels.append(o)
        for angle in range(0,180,60):
            a=math.radians(angle);o=line('Bicycle spoke',[(0,y-.3*math.cos(a),.37-.3*math.sin(a)),(0,y+.3*math.cos(a),.37+.3*math.sin(a))],.008,m['paving']);o.parent=root
    for a,b in [((0,-.65,.37),(0,0,1)),((0,0,1),(0,.65,.37)),((0,-.65,.37),(0,.2,.42)),((0,.2,.42),(0,0,1)),((0,.2,.42),(0,.65,.37))]:
        o=line('Bicycle frame',[a,b],.035,m['amber']);o.parent=root
    rider,limbs=person('Rider',m,root);rider.location=(0,-.1,.3);rider.scale=(.75,)*3;rider.rotation_euler.x=.2
    cube('Handlebar',(0,.55,1.12),(.62,.07,.07),m['rim'],root)
    return root,wheels,limbs


def curve(name,a,b,m,r=.035):
    a,b=Vector(a),Vector(b);points=[]
    for i in range(17):
        q=i/16;p=a.lerp(b,q);p.z+=math.sin(q*math.pi)*.5;points.append(tuple(p))
    return line(name,points,r,m)


def futures(m,template,depth=3):
    nodes=[];edges=[];worlds=[];origin=(0,1.8,1.1)
    for i,x in enumerate([-7.5,0,7.5]):
        root=empty('Candidate world '+str(i));root.location=(x,8,3)
        cube('Future cutaway',(0,0,-.18),(5.2,5.6,.36),m['rim'],root,.13)
        cube('Future road',(0,0,.02),(2,5.4,.07),m['road'],root,.02)
        for sign in [-1,1]:cube('Future curb',(sign*1.2,0,.1),(.18,5.4,.17),m['paving'],root,.02)
        mini=clone(template,'Candidate vehicle '+str(i),root);mini.location=(0,-.6,.07);mini.scale=(.38,)*3
        house('Future architecture',-1.9,1.25,.04,m,.42,root);tree('Future tree',1.9,.9,.04,m,.48,root)
        for sign in [-1,1]:cube('Future edge',(sign*2.5,0,0),(.025,5.1,.04),m['cyan'],root,.01)
        p=(x,8,4.0);nodes.append((root,1,i));worlds.append((root,mini,i));edges.append((curve('First choice',origin,p,m['cyan']),1,i))
        for j in range(3):
            k=i*3+j;q=((k-4)*2.65,15,6.5)
            dot=sphere('Second-stage state',q,.23,m['cyan']);nodes.append((dot,2,k));edges.append((curve('Second choice',p,q,m['cyan'],.026),2,k))
            if depth==3:
                for h in range(3):
                    idx=k*3+h;r=((idx-13)*.92,22,8.9)
                    dot=sphere('Third-stage state',r,.17,m['cyan']);nodes.append((dot,3,idx));edges.append((curve('Third choice',q,r,m['cyan'],.018),3,idx))
    assert {l:len({k for _,level,k in nodes if level==l}) for l in range(1,depth+1)}=={l:3**l for l in range(1,depth+1)}
    return nodes,edges,worlds


def workbench(m):
    cube('Workbench',(0,1,1.9),(17,12,.35),m['paving'],bevel=.12)
    for x in [-7.3,7.3]:
        for y in [-4.2,6.2]:cube('Bench leg',(x,y,.6),(.32,.32,2.3),m['rim'])
    cube('Instrument backboard',(0,7,4.2),(17,.3,5),m['rim'],bevel=.08)
    for x in [-5.3,0,5.3]:
        cube('Instrument case',(x,6.6,4.4),(3.4,.55,2.1),m['paving'])
        cube('Instrument face',(x,6.3,4.4),(2.9,.04,1.6),m['navy'],bevel=.02)
        for sign in [-1,1]:sphere('Instrument knob',(x+sign*1.2,6.21,3.8),.09,m['amber'])
    board,core,parts=build_compute('Illustrative compute module');board.location=(0,-1,2.18);board.scale=(1.25,)*3
    for x in [-6.5,6.5]:
        cube('Evidence folder',(x,-1,2.25),(2.7,4,.16),m['building'],bevel=.05)
        cube('Evidence paper',(x,-1,2.36),(2.3,3.55,.035),m['paint'],bevel=.02)
        for y in [-2,-1.5,-1,-.5]:cube('Paper rule',(x,y,2.39),(1.8,.035,.008),m['rim'],bevel=0)
    return board,core,parts


def bake_mesh_modifiers(scene):
    """Resolve static bevel/normal geometry once; keep parent rigs and moving parts."""
    graph=bpy.context.evaluated_depsgraph_get()
    resolved=[]
    for obj in list(scene.objects):
        if obj.type=='MESH' and obj.modifiers:
            mesh=bpy.data.meshes.new_from_object(obj.evaluated_get(graph),depsgraph=graph)
            resolved.append((obj,mesh))
    # Resolve the graph once before changing it, rather than reevaluating the
    # dense static neighborhood for each individual moving-rig modifier.
    for obj,mesh in resolved:obj.modifiers.clear();obj.data=mesh


# Isolated experiment: preserve the original helper implementations.
_base_palette=palette
_base_studio=studio
from .urban_environment import palette,studio,street,house
