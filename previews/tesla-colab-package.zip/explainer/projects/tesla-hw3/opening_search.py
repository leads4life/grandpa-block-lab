"""Moving 3D search-tree opening. Miniature worlds are illustrative candidate states."""
from pathlib import Path
import hashlib
import math
import sys
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
from explainer.core import read, write
from explainer.media import voice
from explainer.vehicle_prop import build_vehicle
from explainer.traffic_scene import cube
from explainer.visual_tools import material, line
from explainer.blender_backend import aim
from explainer.turn_motion import rectangles_overlap

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'build/opening-v2'
OUT.mkdir(parents=True, exist_ok=True)
TEXT = ("How does a car's computer choose its next move without wasting effort on poor choices? "
        "A Tesla patent application describes one approach: score the choices, cut poor branches early, "
        "and develop more promising ones. Here's how that search works—and what it actually proves.")
if not (OUT / 'voice.json').exists():
    voice({'narration': TEXT}, OUT)
audio = read(OUT / 'voice.json')
assert audio['text'] == TEXT, 'Stale voice cache'
FPS = 30
DURATION = math.ceil((audio['seconds'] + .55) * FPS) / FPS
NF = round(DURATION * FPS)
W, H = 640, 360
write(OUT / 'timing.json', {'seconds': DURATION, 'frames': NF, 'script': TEXT,
      'voice': audio['profile'], 'speech_wpm': audio['measured_words_per_minute'],
      'position_in_film': 'opening, from 00:00', 'width': W, 'height': H})

bpy.ops.wm.read_factory_settings(use_empty=True)
s = bpy.context.scene
s.render.engine = 'CYCLES'
s.cycles.samples = 12
s.cycles.use_denoising = False
s.cycles.max_bounces = 3
s.cycles.diffuse_bounces = 1
s.cycles.glossy_bounces = 2
s.render.threads_mode = 'FIXED'
s.render.threads = 4
s.render.resolution_x, s.render.resolution_y = W, H
s.render.resolution_percentage = 100
s.render.fps = FPS
s.frame_start, s.frame_end = 0, NF-1
s.world = bpy.data.worlds.new('Soft studio')
s.world.use_nodes = True
s.world.node_tree.nodes['Background'].inputs[0].default_value = (.24, .32, .43, 1)
s.world.node_tree.nodes['Background'].inputs[1].default_value = .7

def matte(name, color):
    m = material(name, color)
    sh = m.node_tree.nodes['Principled BSDF']
    sh.inputs['Metallic'].default_value = 0
    sh.inputs['Roughness'].default_value = .78
    return m

floor = matte('Studio backdrop', (.025, .045, .07, 1))
asphalt = matte('Road', (.055, .07, .09, 1))
platform = matte('Sectioned world', (.19, .25, .30, 1))
white = matte('Lane paint', (.76, .83, .86, 1))
cyan = material('Develop promising choice', (.025, .68, .88, 1), True)
gray = material('Candidate link', (.26, .36, .43, 1), True)
red = material('Low scoring branch', (.92, .14, .07, 1), True)
orange = matte('Pedestrian coat', (.8, .34, .035, 1))
dark = matte('Pedestrian trousers', (.04, .055, .075, 1))
skin = matte('Pedestrian head', (.55, .32, .18, 1))
cube('Studio floor', (0, 5, -.7), (250, 250, .6), floor, bevel=0)

def clone_tree(source, name, parent):
    copies = {}
    def visit(obj, par):
        cp = obj.copy()
        cp.name = name + ' ' + obj.name
        s.collection.objects.link(cp)
        cp.parent = par
        copies[obj] = cp
        for child in obj.children:
            visit(child, cp)
        return cp
    root = visit(source, parent)
    root.location = (0, 0, 0)
    return root

blue_template = build_vehicle('Blue EV')
red_template = build_vehicle('Oncoming EV', (.48, .065, .035, 1))
worlds = []

def world(name, location, kind):
    root = bpy.data.objects.new(name, None)
    s.collection.objects.link(root)
    root.location = location
    slab = cube(name + ' base', (0, 0, -.18), (15, 22, .36), platform, root, .25)
    cube(name + ' vertical road', (0, 0, .015), (7.3, 22, .06), asphalt, root, .015)
    cube(name + ' crossing road', (0, 0, .02), (15, 7.3, .06), asphalt, root, .015)
    for sign in [-1, 1]:
        for x in [-2.9, -1.8, -.7, .4, 1.5, 2.6]:
            cube(name + ' crossing', (x, sign*4.6, .065), (.55, 1.1, .016), white, root, 0)
        cube(name + ' lane', (0, sign*6.5, .06), (.10, 1.7, .018), white, root, 0)
        cube(name + ' exit lane', (sign*6.4, 0, .06), (1.7, .10, .018), white, root, 0)
    car = clone_tree(blue_template, name, root)
    other = clone_tree(red_template, name, root)
    other.rotation_euler.z = math.pi
    cube(name + ' stop line', (1.8, -5.45, .07), (3.3, .12, .02), white, root, 0)
    pedestrian = None
    legs = []
    if kind in ('present', 'creep', 'wait'):
        pedestrian = bpy.data.objects.new(name + ' pedestrian', None)
        s.collection.objects.link(pedestrian)
        pedestrian.parent = root
        cube(name + ' coat', (0, 0, 1.18), (.43, .27, .59), orange, pedestrian, .08)
        bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=.16, location=(0, 0, 1.64))
        head = bpy.context.object
        head.parent = pedestrian
        head.data.materials.append(skin)
        for sign in [-1, 1]:
            leg = cube(name + ' leg', (sign*.12, 0, .51), (.15, .19, .78), dark, pedestrian, .06)
            cube(name + ' shoe', (sign*.12, .035, .105), (.17, .30, .18), dark, pedestrian, .035)
            arm = cube(name + ' arm', (sign*.29, 0, 1.13), (.13, .16, .55), orange, pedestrian, .05)
            legs.append((sign, leg, arm))
    wheel_sets = [(vehicle, [o for o in vehicle.children if o.get('vehicle_part') == 'wheel'])
                  for vehicle in [car, other]]
    # A road-level target marker identifies the desired left-turn exit.
    marker = line(name + ' goal', [(-5.7, 1.8, .10), (-6.4, 1.8, .10), (-6.0, 2.15, .10)], .07, cyan)
    marker.parent = root
    item = {'root': root, 'base': slab, 'car': car, 'other': other, 'kind': kind,
            'wheels': wheel_sets, 'location': Vector(location), 'pedestrian': pedestrian, 'limbs': legs}
    worlds.append(item)
    return item

base = world('Present', (0, -20, 0), 'present')
choices = [world('Turn now', (-22, 6, .2), 'early'),
           world('Creep forward', (0, 6, .2), 'creep'),
           world('Wait', (22, 6, .2), 'wait')]
future = [world('Next turn', (13, 32, .4), 'turn'),
          world('Next wait', (31, 32, .4), 'later_wait')]
# Source templates are removed; linked copies retain their mesh datablocks.
for template in [blue_template, red_template]:
    for obj in [*template.children_recursive, template]:
        bpy.data.objects.remove(obj, do_unlink=True)

def edge(name, a, b):
    return line(name, [(a[0], a[1]+11.0, .2), ((a[0]+b[0])/2, (a[1]+b[1])/2, .7),
                       (b[0], b[1]-11.0, b[2]+.2)], .10, gray)
links = [edge('Candidate ' + str(i), base['location'], w['location']) for i, w in enumerate(choices)]
next_links = [edge('Further search ' + str(i), choices[2]['location'], w['location']) for i, w in enumerate(future)]

for name, pos, power, size in [('Key', (-18, -20, 45), 42000, 32),
                              ('Fill', (35, 10, 38), 31000, 26)]:
    data = bpy.data.lights.new(name, 'AREA')
    data.energy, data.size = power, size
    obj = bpy.data.objects.new(name, data)
    s.collection.objects.link(obj)
    obj.location = pos
    aim(obj, (6, 0, 0))
bpy.ops.object.camera_add()
cam = bpy.context.object
s.camera = cam
cam.data.dof.use_dof = False
cam.data.clip_end = 400

def ease(v):
    v = min(1, max(0, v))
    return v*v*(3-2*v)

def set_cars(w, u):
    """Each tile is an alternative schematic state, not simultaneous physical traffic."""
    k = w['kind']
    car, other = w['car'], w['other']
    car.rotation_euler.z = 0
    x, y, yaw, distance = 1.8, -7.6, 0, 0
    if k == 'present':
        distance = 1.0*ease(u/.24)
        y = -8.6+distance
    elif k == 'early':
        # A speculative early turn approaches the oncoming path; it stops before contact.
        q = ease((u-.27)/.28)
        theta = q*.58
        x, y, yaw = -2.5+4.3*math.cos(theta), -2.5+4.3*math.sin(theta), theta
        distance = 3.8+theta*4.3
    elif k == 'creep':
        distance = 2.1*ease((u-.28)/.28)
        y += distance
    elif k == 'turn':
        q = ease((u-.72)/.28)
        theta = q*math.pi/2
        x, y, yaw = -2.5+4.3*math.cos(theta), -2.5+4.3*math.sin(theta), theta
        distance = 3.8+theta*4.3
    car.location, car.rotation_euler.z = (x, y, .08), yaw
    if k == 'early':
        other.location = (-1.8, 6.5-1.5*ease((u-.27)/.28), .08)
    else:
        other.location = (-1.8, 6.5-12*ease((u-.16)/.70), .08)
    if w['pedestrian'] is not None:
        progress = ease((u-.25)/.25)
        w['pedestrian'].location = (4.8-1.5*progress, -4.6, .08)
        w['pedestrian'].rotation_euler.z = math.pi/2
        for sign, leg, arm in w['limbs']:
            angle = .3*math.sin(progress*math.tau*1.5+(0 if sign < 0 else math.pi))
            leg.rotation_euler.x = angle
            arm.rotation_euler.x = -angle
    for vehicle, wheels in w['wheels']:
        d = distance if vehicle == car else 6.5-other.location.y
        for wheel in wheels:
            wheel.rotation_euler.x = -d/.34
            wheel.rotation_euler.z = .35 if vehicle == car and yaw > .01 and wheel.location.y > 0 else 0
    assert not rectangles_overlap((x, y, yaw), (other.location.x, other.location.y, math.pi)), ('Vehicle overlap', k, u)

poses = {}
lenses = {'car_question': 50, 'possible_futures': 31,
          'evaluate_and_prune': 28, 'develop_next_choices': 29}
def apply(f):
    u = f / max(1, NF-1)
    for w in worlds:
        set_cars(w, u)
    for i, (w, link) in enumerate(zip(choices, links)):
        grow = ease((u-.24-i*.025)/.13)
        remove = ease((u-.60-i*.025)/.12) if i < 2 else 0
        scale = max(.0001, grow*(1-remove))
        w['root'].scale = (scale,)*3
        link.data.bevel_factor_end = grow*(1-remove)
        link.data.materials[0] = (red if i == 0 else gray) if u > .49 else gray
        if i == 2 and u > .49:
            link.data.materials[0] = cyan
    for i, (w, link) in enumerate(zip(future, next_links)):
        grow = ease((u-.71-i*.035)/.16)
        w['root'].scale = (max(.0001, grow),)*3
        link.data.bevel_factor_end = grow
        link.data.materials[0] = cyan
    if u < .24:
        q = u/.24
        cam.location = (9-2*q, -17-q, 4.5+.4*q)
        target = Vector((2, -27.3, .7))
        lens, shot, important = 48, 'car_question', [base['car']]
    elif u < .49:
        q = (u-.24)/.25
        cam.location = (37-7*q, -58+2*q, 55+4*q)
        target = Vector((0, -5, 0))
        lens, shot, important = 31, 'possible_futures', [base['base'], *[w['base'] for w in choices]]
    elif u < .69:
        q = (u-.49)/.20
        cam.location = (12-5*q, -35+q, 42)
        target = Vector((0, 6, 0))
        lens, shot, important = 28, 'evaluate_and_prune', [w['base'] for w in choices]
    else:
        q = (u-.69)/.31
        cam.location = (57-5*q, -34+6*q, 58)
        target = Vector((20, 17+3*q, .2))
        lens, shot, important = 25, 'develop_next_choices', [choices[2]['base'], *[w['base'] for w in future]]
    cam.data.lens = lenses[shot]
    aim(cam, target)
    bpy.context.view_layer.update()
    # Widen framing once for the entire shot, rather than per-frame lens pumping.
    projected = {}
    for w in worlds:
        p = world_to_camera_view(s, cam, w['root'].matrix_world @ Vector((0, -11.6, .1)))
        projected[w['kind']] = [p.x, 1-p.y, w['root'].scale.x]
    bad = []
    focal_ratio = 1.0
    for obj in important:
        if obj.parent and obj.parent.scale.x < .03:
            continue
        meshes = [o for o in obj.children_recursive if o.type == 'MESH'] if obj.type == 'EMPTY' else [obj]
        for mesh in meshes:
            for corner in mesh.bound_box:
                p = world_to_camera_view(s, cam, mesh.matrix_world @ Vector(corner))
                if p.z <= 0:
                    raise ValueError(('Object behind camera', f, mesh.name))
                focal_ratio = min(focal_ratio, .475/max(abs(p.x-.5), 1e-9),
                                  .44/max(abs(p.y-.5), 1e-9))
                if p.z <= 0 or not (.025 < p.x < .975 and .055 < p.y < .96):
                    bad.append(mesh.name)
                    break
    poses[f] = {'shot': shot, 'labels': projected, 'bad_bounds': sorted(set(bad)),
                'visible_candidates': sum(w['root'].scale.x > .03 for w in choices),
                'next_choices': sum(w['root'].scale.x > .03 for w in future),
                'focal_ratio': focal_ratio,
                'car_positions': {w['kind']: list(w['car'].location) for w in worlds}}
    return bad

for attempt in range(3):
    for f in range(NF):
        apply(f)
    bad = {f: p['bad_bounds'] for f, p in poses.items() if p['bad_bounds']}
    if not bad:
        break
    for shot in lenses:
        ratio = min(p['focal_ratio'] for p in poses.values() if p['shot'] == shot)
        if ratio < 1:
            lenses[shot] *= ratio*.97
    print('Constant-per-shot camera repair', attempt+1, lenses, flush=True)
assert not bad, f'Camera bounds need repair: {dict(list(bad.items())[:3])}'
assert poses[round(NF*.47)]['visible_candidates'] == 3
assert poses[round(NF*.92)]['visible_candidates'] == 1
assert poses[round(NF*.98)]['next_choices'] == 2
write(OUT / 'poses.json', poses)
write(OUT / 'scene-qa.json', {'frames': NF, 'all_frame_bounds_passed': True,
      'choices_before_pruning': 3, 'choices_after_pruning': 1, 'expanded_choices': 2,
      'camera_shots': sorted(set(p['shot'] for p in poses.values())),
      'checked_camera_lenses': lenses,
      'static_image_sections': False, 'accuracy': 'Schematic search over illustrative traffic states; no Tesla policy, numeric score, measured savings, hardware or deployment claim.'})
bpy.ops.wm.save_as_mainfile(filepath=str(OUT / 'opening-scene.blend'))
folder = OUT / 'raw'
folder.mkdir(exist_ok=True)
engine = Path(__file__).resolve().parents[2]
source_paths = [Path(__file__), engine/'vehicle_prop.py', engine/'traffic_scene.py',
                engine/'visual_tools.py', engine/'blender_backend.py', engine/'turn_motion.py', OUT/'voice.wav']
stamp = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
stamp_path = OUT/'render-source.json'
if any(folder.glob('*.png')):
    assert stamp_path.exists() and read(stamp_path) == stamp, 'Stale frames: use a new render directory or deliberately clear the prior generated diagnostics.'
write(stamp_path, stamp)
frames = [0, round(NF*.37), round(NF*.55), round(NF*.64), round(NF*.86), NF-1] if '--stills' in sys.argv else range(NF)
for f in frames:
    path = folder / f'{f:06d}.png'
    if path.exists():
        continue
    apply(f)
    s.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)
print('SEARCH OPENING READY', DURATION, 'seconds', NF, 'frames', flush=True)
