"""Portable v2 device adapter; a render never records an invented final review."""
from pathlib import Path
import argparse,hashlib,json,os,runpy,sys,tempfile
from explainer.core import read,write
from explainer.colab.runtime import choose_device,install_device_handler

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];OUT=ROOT/'build/full-v2'


def verify_package():
    package=read(REPO/'V2_PACKAGE.json')
    for name,expected in package['immutable_sha256'].items():
        path=(REPO/name).resolve()
        if not path.is_relative_to(REPO) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise ValueError('Missing or changed frozen package source/media: '+name)
    return package


def render(index):
    device=choose_device();bind=OUT/'colab-render-device.json'
    identity={k:device.get(k) for k in ['device','backend','names']}
    if bind.exists() and read(bind)!=identity and any(OUT.glob('r*/raw/*.png')):
        raise ValueError('Device changed with native frames present; use a fresh extraction/version rather than mixing frames.')
    write(bind,identity);install_device_handler(device)
    print('V2 render device:',json.dumps(device),flush=True)
    sys.argv=['render_revision','--index',str(index)]
    runpy.run_module('explainer.projects.tesla-hw3.render_revision',run_name='__main__')


def smoke():
    import bpy
    device=choose_device();handler=install_device_handler(device)
    bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=1
    s.render.resolution_x=64;s.render.resolution_y=64;s.render.resolution_percentage=100
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8)
    bpy.ops.object.camera_add(location=(0,-5,2));s.camera=bpy.context.object;s.camera.rotation_euler=(1.19,0,0)
    with tempfile.TemporaryDirectory() as temp:
        s.render.filepath=str(Path(temp)/'smoke.png');bpy.ops.render.render(write_still=True)
        assert Path(s.render.filepath).is_file() and s.cycles.device==device['device']
    bpy.app.handlers.render_pre.remove(handler);write(OUT/'colab-device-smoke.json',dict(device,passed=True))
    print(json.dumps(device,indent=2),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['smoke','render','resume']);p.add_argument('--index',type=int);a=p.parse_args()
    if a.command=='smoke':smoke()
    elif a.command=='render':
        if a.index is None:raise ValueError('Supply a chapter index')
        render(a.index)
    else:
        verify_package();os.environ['EXPLAINER_V2_COLAB']='1'
        from .produce_revision import run
        run()
