# Final written script — completed main v2

This is the actual narration of the completed 3:28 main film, preserved as text. Video is not included; actual frozen narration is supplied separately in the source tree. The later premium re-cut remains a proposal, separately documented in RECUT_V3_PROPOSAL.md.

## 1. Choose what deserves attention (0.00–23.63s)

Three choices: turn, creep forward, or wait. Follow one turn to see how a planner chooses where to spend effort. A pedestrian is crossing and an oncoming car is approaching. Our car waits. The other choices can still be represented, but they don't all deserve endless exploration. Tesla's patent application describes one way to make that search selective. First, watch what happens when we add just two more decision stages.

## 2. Why three choices grow quickly (23.63–47.73s)

Those three choices are only the first stage. Give each one three follow-up choices. Now there are nine possible sequences. Add a third stage, and there are twenty-seven. Nothing complicated happened at any one step; the combinations did the growing. These are numbers in our simplified example, not a Tesla performance measurement. To compare useful futures, we need to connect each choice to a driving goal and the interactions that follow.

## 3. Connect the decisions (47.73–76.17s)

The goal is the lane beyond the turn. Start there, then connect the possible interactions. Passing before another road user and waiting to pass behind them create different branches. A later choice depends on what happened earlier. That linked sequence is a candidate trajectory: one possible way of moving through the situation. The patent calls this a hierarchical graph. We can follow a route through it without pretending these graphics reproduce Tesla's software. But what happens to a road user outside the immediate conflict?

## 4. The cyclist stays (76.17–100.23s)

The cyclist is off to the side. Does that mean the planner can forget about them? In our illustration, no. The cyclist stays represented. What can change is their relevance to the particular interaction we are considering. That is different from deleting the person or spending zero computation on them. If the situation changes, they may matter to the next decision. We still need a way to compare the choices that remain.

## 5. A useful choice has consequences (100.23–127.13s)

A possible turn can be physically feasible and still be abrupt or uncomfortable. Compare these two illustrative motions. The application describes scoring factors including physics-based constraints, comfort, intervention likelihood, and a human-like discriminator. Those factors help evaluate candidate behavior. We're showing the kinds of considerations involved, not Tesla's actual numeric scores or weights. A score is useful because it can guide what the planner develops next. Now watch what happens to a branch that falls below a threshold.

## 6. Pay off the pruning idea (127.13–155.80s)

The patent describes comparing node scores with a threshold and removing lower-scoring nodes. This is pruning. The poor branch stops growing, while a more promising branch develops more detail. Look back at the road: the pedestrian and cyclist are still there. We have removed a candidate from the search, not a person from the world. That can avoid work on trajectories that would not be selected. The method describes a way to focus effort. It does not give us a measured percentage saving for this example.

## 7. Separate the hardware claim (155.80–187.93s)

Does more selective search make an older computer equivalent to a newer one? That does not follow from this application. Planning is one part of a system that also has perception, prediction, memory, and timing requirements. The document does not establish Hardware Three feature parity, version fourteen deployment, or an eighty-percent saving. Those need separate product evidence. Tesla describes Full Self-Driving Supervised as requiring active driver supervision, and says features vary with the vehicle's hardware and software. The useful check is to match a feature claim to an actual release for the actual vehicle.

## 8. Test and apply the lesson (187.93–207.97s)

One last check. When a branch is pruned, what must remain represented? The road user. That distinction is the lesson: organize the choices, compare their consequences, and stop developing poor branches. Our car can finish the illustrated turn once the crossing and opposing lane are clear. We can understand the planning idea while keeping a hardware-upgrade claim separate.

