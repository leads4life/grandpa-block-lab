import unittest
from explainer.media import synthesize_paced
class Voice:
 def __init__(self,responsive=True):self.calls=[];self.responsive=responsive
 def create(self,text,voice,speed,**kwargs):
  self.calls.append(speed);words=len(text.split());rate=126*speed/.8 if self.responsive else 126
  return [0.2]*round(words/rate*60*100),100
class Pacing(unittest.TestCase):
 def test_nonlinear_speed_response_converges_inside_measured_bracket(self):
  class Nonlinear(Voice):
   def create(self,text,voice,speed,**kwargs):
    self.calls.append(speed)
    rate=111+(speed-.8)*120 if speed<=1.29 else 170+(speed-1.29)*666
    return [0.2]*round(len(text.split())/rate*60*100),100
  engine=Nonlinear()
  audio,sr,speed,attempts=synthesize_paced(engine,'word '*75,'stock',.8,{})
  self.assertGreater(len(attempts),3)
  self.assertLessEqual(len(attempts),6)
  self.assertAlmostEqual(75/(len(audio)/sr)*60,179,delta=6)
  self.assertGreater(speed,1.29)
  self.assertLess(speed,1.35)
 def test_slow_take_is_resynthesized_to_reference_pace(self):
  engine=Voice();audio,sr,speed,attempts=synthesize_paced(engine,'word '*37,'stock',.8,{})
  self.assertGreater(speed,.8);self.assertLessEqual(len(attempts),3)
  self.assertAlmostEqual(37/(len(audio)/sr)*60,179,delta=6)
 def test_short_phrases_are_not_forced_to_an_artificial_rate(self):
  engine=Voice();synthesize_paced(engine,'Motion test','stock',.8,{})
  self.assertEqual(engine.calls,[.8])
 def test_unresponsive_delivery_stops_instead_of_claiming_success(self):
  engine=Voice(False)
  with self.assertRaisesRegex(ValueError,'target not reached'):
   synthesize_paced(engine,'word '*37,'stock',.8,{})
  self.assertLessEqual(len(engine.calls),3)
