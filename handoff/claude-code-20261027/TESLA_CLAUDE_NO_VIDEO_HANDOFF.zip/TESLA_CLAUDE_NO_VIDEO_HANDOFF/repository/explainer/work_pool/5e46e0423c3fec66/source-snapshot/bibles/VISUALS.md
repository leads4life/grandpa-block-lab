# Visual and mechanical bible

Use subject-specific geometry, persistent component names, real connections, and mechanically credible constraints. Reuse components across shots; do not change proportions, color meaning or component identity without a stated reason.

Realistic overview establishes the object. Simplified diagrams isolate the mechanism. Use exploded views, sections, flow arrows and highlight changes only when they clarify the narrated step. A moving part must show why its movement matters. Plan camera positions from the explanatory task, not decorative orbit motion.

Semantic roles in the initial backend: structure, active, flow, signal, context. The palette is provisional tooling, not channel branding. Always pair color with spatial context or labels. Keep labels brief and legible, with visible associations. No subtitle/caption layer. No automatic subject-name HUD, production-mode label or seed text in a viewer-facing video.

Keep explanatory parts in focus. Depth of field is opt-in after readability review. Do not use X-ray transparency as a substitute for a useful physical section. The backend supports opaque primitives, hollow tube housings, physical local-plane sections, endpoint translation/rotation for exploded views, path arrows with an animated flow marker, and camera-facing technical labels with optional leaders tracking component centers. Tube sections currently support local X/Y planes only; transverse annular caps need a further adapter. Static GLB/glTF, OBJ and STL mesh packages can now be imported with preserved proportions/materials and a uniformly scaled, centered animated root. Native CAD formats, source-animation retargeting, individual imported-part controls, arbitrary imported-mesh sections, complex constraints, graphs and transparency still need additional subject adapters. Do not claim those adapters exist yet.

Framing checks cover every frame's object bounds with a safe margin. They do not establish visibility through other geometry, correct mechanics, legible text or absence of clipping. Codex must inspect contact sheets AND motion; inspect suspect frames individually and fix the source of the problem.

## Subject-dependent backgrounds

Choose light or dark per shot for clarity. `presentation.background: auto` starts schematic/analogy shots on a light background and literal models on a dark one; this is a readability heuristic, not technical analysis. Codex inspects the result and may override with `light` or `dark` plus a recorded `reason`. Both themes provide contrasting callout ink and adapted semantic palettes. Keep color meanings consistent when switching. Preserve supplied static-image backgrounds; changing an image requires a separate reviewed edit.

## Current Tesla visual direction

The user rejected long held images and asked for dynamic 3D like the piston example. Render real changing geometry/actor/camera state through every shot; no held-plate or slideshow sections for now. Camera changes must expose the interaction being explained. Wheels, agents, routes and scene geometry should move coherently. Keep image compositing optional for a future user-directed change; technical callouts remain allowed.
