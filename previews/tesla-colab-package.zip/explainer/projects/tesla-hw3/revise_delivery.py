"""Match actual spoken pace, then edit genuine 3D shots to the new reading; no speech stretching."""
from pathlib import Path
import math,os,subprocess,hashlib
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
from kokoro_onnx import Kokoro
from PIL import Image,ImageDraw,ImageFont
from explainer.core import read,write
from explainer.media import check_video
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/dynamic-v4';OUT.mkdir(parents=True,exist_ok=True)
TEXT='Watch the left turn. The pedestrian crosses, the oncoming car passes, and now the blue car has a clear route. Planning organizes these interactions so useful choices can be developed and poor ones discarded.'
engine=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES'])
rate=1.10;target=179;attempts=[]
for attempt in range(3):
 a,sr=engine.create(TEXT,voice='am_fenrir',speed=rate,sentence_pause=.14,clause_pause=.04)
 a=np.asarray(a,dtype=np.float64);active=np.flatnonzero(np.abs(a)>np.abs(a).max()*.005)
 assert len(active) and np.isfinite(a).all()
 a=a[max(0,active[0]-round(sr*.05)):min(len(a),active[-1]+round(sr*.12))]
 spoken=len(a)/sr;wpm=len(TEXT.split())/spoken*60
 attempts.append({'synthesis_speed':rate,'spoken_seconds':spoken,'words_per_minute':wpm})
 if abs(wpm-target)<=12:break
 rate=max(.65,min(1.35,rate*target/wpm))
assert abs(wpm-target)<=18,attempts
n=math.gcd(int(sr),48000);a=resample_poly(a,48000//n,int(sr)//n);a*=.7/np.abs(a).max()
a=np.concatenate([np.zeros(7200),a,np.zeros(16800)])
seconds=math.ceil(len(a)/48000*30)/30;a=np.pad(a,(0,round(seconds*48000)-len(a)))
wavfile.write(OUT/'voice.wav',48000,(a*32767).astype(np.int16))
# Tight native-speed editorial cuts; no slow motion, held stills or accelerated recorded speech.
# These windows retain crossing -> clearance -> turn -> exit in causal order.
windows=[(0,2.8),(4.3,6.7),(8.4,12.1),(14.3,17.7)]
indices=[i for start,end in windows for i in range(round(start*30),round(end*30))]
needed=round(seconds*30)
# If narration is longer, extend the moving turn shot using native source frames.
if len(indices)<needed:
 extra=[i for i in range(round(12.1*30),round(14.3*30))]
 insert=len(range(0,round(2.8*30)))+len(range(round(4.3*30),round(6.7*30)))+len(range(round(8.4*30),round(12.1*30)))
 indices=indices[:insert]+extra[:needed-len(indices)]+indices[insert:]
assert len(indices)>=needed,(len(indices),needed)
indices=indices[:needed];frames=OUT/'frames';frames.mkdir(exist_ok=True)
source=ROOT/'build/dynamic-v3/frames'
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
for number,index in enumerate(indices):
 with Image.open(source/f'{index:06d}.png') as im:im.save(frames/f'{number:06d}.png')
# Remove only stale frames from a prior take in this generated output directory.
for p in frames.glob('*.png'):
 if int(p.stem)>=needed:p.unlink()
output=OUT/'tesla-dynamic-paced-v4.mp4';gain=0;qa_attempts=[]
for _ in range(4):
 subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-start_number','0','-i',str(frames/'%06d.png'),'-i',str(OUT/'voice.wav'),
  '-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:attack=2:release=60:level=false:latency=1,apad','-t',str(seconds),
  '-c:v','libx264','-threads','2','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-movflags','+faststart',str(output)],check=True)
 qa=check_video(output,seconds,960,540);qa_attempts.append(dict(qa))
 if qa['passed']:break
 gain+=-14-qa['lufs']
assert qa['passed'],qa
qa.update({'review':'pending','voice':'am_fenrir','script':TEXT,'synthesis_attempts':attempts,'words_per_minute':wpm,'seconds':seconds,
 'source_frame_indices':indices,'recorded_speech_time_stretched':False,'native_speed_3d_shots':True,'static_image_sections':False,'audio_attempts':qa_attempts})
write(OUT/'qa.json',qa)
sheet=Image.new('RGB',(960,540),'#091726')
for j,f in enumerate([0,needed//5,needed*2//5,needed*3//5,needed*4//5,needed-1]):
 with Image.open(frames/f'{f:06d}.png') as im:sheet.paste(im.resize((320,180)),((j%3)*320,(j//3)*270))
sheet.save(OUT/'review-sheet.jpg',quality=95)
with Image.open(frames/f'{needed//2:06d}.png') as im:im.save(OUT/'poster.jpg',quality=94)
print('PACE REVISION READY:',round(seconds,2),'seconds;',round(wpm,1),'words/min;',round(rate,3),'synthesis speed',flush=True)
