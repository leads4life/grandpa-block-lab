"""Compose a measured first-chapter review; no narration subtitles or music."""
from pathlib import Path
from functools import lru_cache
import math,subprocess,sys
from PIL import Image,ImageDraw,ImageFont
from explainer.core import read,write
from explainer.media import mix_mechanical,check_video
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/preview';W,H=960,540
INK='#eff6ff';MUTED='#a5bccd';CYAN='#67d8f2'
@lru_cache(None)
def font(size,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',size)
@lru_cache(100)
def image(path):
 with Image.open(path) as im:return im.convert('RGB').resize((W,H),Image.Resampling.LANCZOS)
@lru_cache(None)
def shade():
 im=Image.new('RGBA',(W,H));d=ImageDraw.Draw(im)
 for x in range(W):
  alpha=int(235*(1-x/W)**1.5+10)
  d.line((x,0,x,H),fill=(5,13,24,alpha))
 return im

def wrapped(d,text,xy,size,width,fill=INK,bold=True,spacing=9):
 words=text.split();lines=[];line=''
 for word in words:
  candidate=(line+' '+word).strip()
  if d.textlength(candidate,font=font(size,bold))>width and line:lines.append(line);line=word
  else:line=candidate
 if line:lines.append(line)
 for i,line in enumerate(lines):d.text((xy[0],xy[1]+i*(size+spacing)),line,font=font(size,bold),fill=fill)
 return xy[1]+len(lines)*(size+spacing)

def frame(t,timing):
 timeline=timing['timeline'];beat=sum(t>=b['start'] for b in timeline)-1;beat=max(0,min(2,beat))
 local=max(0,t-timeline[beat]['start'])
 if beat==0:
  available=sorted((OUT/'car').glob('*.png'));index=min(round(t*30),len(available)-1)
  base=image(str(available[index])).copy()
 else:base=image(str(OUT/'compute.png')).copy()
 # Neutral dark overlay improves text contrast without hiding the 3D evidence.
 base=Image.alpha_composite(base.convert('RGBA'),shade()).convert('RGB');d=ImageDraw.Draw(base)
 d.text((54,35),'TESLA  /  PLANNING PATENT',font=font(12,True),fill=CYAN)
 d.line((54,63,116,63),fill=CYAN,width=3)
 if beat==0:
  wrapped(d,'Can smarter software stretch a compute budget?',(54,116),38,475)
  d.text((56,330),'A real patent. A question worth examining.',font=font(15),fill=MUTED)
  d.rounded_rectangle((54,393,336,431),radius=8,fill='#132739',outline='#29485a')
  d.text((68,403),'Published 16 April 2026',font=font(14),fill=INK)
 else:
  if beat==1:
   wrapped(d,'Organize.\nScore. Prune.'.replace('\n',' '),(54,109),38,430)
   d.text((56,227),'Develop the useful alternatives.',font=font(15),fill=MUTED)
   stages=[('GOAL',97),('SCORE',262),('PRUNE',427)]
   active=min(2,int(local/2.4))
   for i,(label,x) in enumerate(stages):
    if i<2:d.line((x+42,340,x+123,340),fill='#4d7189',width=2)
    d.rounded_rectangle((x-40,313,x+63,367),radius=10,fill='#0b1b2a',outline=CYAN if i<=active else '#476477',width=2)
    d.text((x-26,332),label,font=font(12,True),fill=INK if i<=active else MUTED)
  else:
   wrapped(d,'What the patent supports',(54,105),37,450)
   for y,title,subtitle,color in [(247,'Planning method','Disclosed in the document',CYAN),(352,'HW3 feature parity','Not established by this document','#efc270')]:
    d.rounded_rectangle((54,y,501,y+80),radius=9,fill='#0b1b2a',outline='#2c465c')
    d.rectangle((54,y+10,58,y+70),fill=color)
    d.text((73,y+14),title,font=font(19,True),fill=INK)
    d.text((73,y+47),subtitle,font=font(13),fill=color)
 d.text((54,494),'US20260105614A1  •  Tesla patent application',font=font(11),fill=MUTED)
 d.text((700,494),'Illustrative 3D models',font=font(10),fill=MUTED)
 return base

def main():
 timing=read(OUT/'timing.json')
 if '--stills' in sys.argv:
  for i,t in enumerate([2,timing['timeline'][1]['start']+4,timing['timeline'][2]['start']+3]):frame(t,timing).save(OUT/f'layout-{i}.jpg',quality=94)
  print('Preview layout images ready');return
 if len(list((OUT/'car').glob('*.png')))!=90:raise ValueError('Wait for all 90 3D approach frames')
 video=OUT/'silent.mp4';error=OUT/'encode.log'
 with error.open('w') as log:
  process=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-r','30','-i','-',
   '-c:v','libx264','-threads','2','-preset','medium','-crf','19','-pix_fmt','yuv420p',str(video)],stdin=subprocess.PIPE,stderr=log)
  try:
   for f in range(timing['frames']):process.stdin.write(frame(f/30,timing).tobytes())
  finally:process.stdin.close();code=process.wait()
  if code:raise ValueError('Video encoding failed; see '+str(error))
 sfx=[{'kind':'click','at':timing['timeline'][1]['start']+2.4,'duration':.1,'purpose':'Highlight scoring step'},
      {'kind':'click','at':timing['timeline'][1]['start']+4.8,'duration':.1,'purpose':'Highlight pruning step'}]
 mix=mix_mechanical({'id':'tesla_first_preview','sfx':sfx},OUT/'voice.wav',OUT/'mix.wav',timing['seconds'])
 gain=0;attempts=[];output=OUT/'tesla-patent-preview.mp4'
 for _ in range(4):
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-i',str(mix),'-map','0:v','-map','1:a','-c:v','copy',
   '-af',f'volume={gain:.3f}dB,alimiter=limit=0.7:attack=2:release=60:level=false:latency=1,apad',
   '-t',str(timing['seconds']),'-c:a','aac','-ar','48000','-movflags','+faststart',str(output)],check=True)
  qa=check_video(output,timing['seconds'],W,H);attempts.append(dict(qa))
  if qa['passed']:break
  gain+=-14-qa['lufs']
 if not qa['passed']:raise ValueError(str(qa))
 qa.update({'attempts':attempts,'review':'pending','source':'https://patents.google.com/patent/US20260105614A1/en',
  'notes':'Measured chapter-one preview. Generic EV and compute module, not exact Tesla CAD. No HW3 parity or quantified performance saving asserted.'})
 write(OUT/'qa.json',qa)
 frame(3,timing).save(OUT/'poster.jpg',quality=93)
 sheet=Image.new('RGB',(960,540),'#08131d')
 for i,t in enumerate([.5,2.5,8,14,19,27]):sheet.paste(frame(t,timing).resize((320,180)),((i%3)*320,(i//3)*270))
 sheet.save(OUT/'review-sheet.jpg',quality=94)
 print('TESLA FIRST PREVIEW READY:',output)
if __name__=='__main__':main()
