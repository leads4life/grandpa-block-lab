"""Original 3D plates and a brief EV approach animation for the Tesla editorial preview."""
from pathlib import Path
import math
import bpy
from explainer.traffic_scene import sedan,intersection,cube
from explainer.visual_tools import material,line
from explainer.blender_backend import aim
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/preview';OUT.mkdir(parents=True,exist_ok=True)
W,H=960,540

def studio(world_color):
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=8;s.cycles.use_denoising=True
 s.cycles.max_bounces=4;s.cycles.diffuse_bounces=2;s.cycles.glossy_bounces=2
 s.render.threads_mode='FIXED';s.render.threads=4
 s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100;s.render.fps=30
 s.world=bpy.data.worlds.new('Studio world');s.world.use_nodes=True
 s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(*world_color,1)
 s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.6
 return s

def area(name,pos,power,size,color,target):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;d.color=color
 o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=pos;aim(o,target)

def camera(pos,target,lens=48):
 bpy.ops.object.camera_add(location=pos);c=bpy.context.object;c.data.lens=lens;bpy.context.scene.camera=c;aim(c,target);return c

def render(path):
 bpy.context.scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)

# Generic compute module. Its geometry does not claim to be Tesla HW3 or AI4 CAD.
if not (OUT/'compute.png').exists():
 bpy.ops.wm.read_factory_settings(use_empty=True);s=studio((.018,.026,.038))
 pcb=material('PCB',(.025,.11,.095,1));chip=material('Chip packages',(.035,.045,.065,1))
 metal=material('Package lid',(.35,.42,.5,1));gold=material('Conductors',(.55,.32,.075,1))
 black=material('Studio ground',(.025,.035,.05,1));white=material('Connectors',(.65,.69,.74,1))
 cube('Circuit board',(0,0,0),(5,3.7,.12),pcb,bevel=.05)
 cube('Processor',(0,0,.21),(1.65,1.65,.32),chip,bevel=.06)
 cube('Processor cap',(0,0,.39),(1.42,1.42,.06),metal,bevel=.04)
 for sign in [-1,1]:
  for i in range(14):
   a=-.72+i*.11
   cube('Contact',(sign*.88,a,.17),(.2,.045,.055),gold,bevel=.005)
   cube('Contact',(a,sign*.88,.17),(.045,.2,.055),gold,bevel=.005)
  for y in [-1.15,1.15]:cube('Memory',(sign*1.6,y,.2),(.62,.62,.26),chip,bevel=.035)
 for i in range(10):
  x=-2.2+i*.18
  cube('Passive',(x,-1.55,.12),(.10,.18,.12),metal,bevel=.01)
  line('Trace',[(x,1.55,.07),(x,.95,.07),(-.8,.95,.07)],.012,gold)
 for x in [-1.8,-.9,0,.9,1.8]:cube('Edge connector',(x,1.77,.2),(.55,.20,.3),white,bevel=.025)
 for x in [-2.2,2.2]:
  for y in [-1.55,1.55]:
   bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.09,depth=.1,location=(x,y,.11));bpy.context.object.data.materials.append(gold)
 cube('Ground',(0,0,-.3),(200,200,.2),black,bevel=0)
 area('Key',(1,-4,8),1400,5,(.8,.9,1),(0,0,0));area('Rim',(-3,4,5),1600,4,(.3,.65,1),(0,0,0))
 camera((7,-9,9),(.6,0,0),46);bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'compute.blend'));render(OUT/'compute.png')
# Three seconds of genuine 3D motion, followed by a held/slowly pushed plate in the preview.
bpy.ops.wm.read_factory_settings(use_empty=True);s=studio((.35,.45,.55));intersection();car=sedan()
area('Daylight',(-4,-7,18),3000,14,(.85,.93,1),(0,-7,0));camera((10,-21,15),(0,-7,0),48)
folder=OUT/'car';folder.mkdir(exist_ok=True)
for f in range(90):
 t=f/89;u=1-(1-t)**3
 car.location=(1.8,-12+3.5*u,0)
 assert car.location.y+2.3<-5.825, 'Vehicle enters crosswalk'
 path=folder/f'{f:06d}.png'
 if path.exists():continue
 render(path)
print('3D preview plates and 90-frame approach ready')
