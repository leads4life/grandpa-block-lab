"""Actual opening: moving 3D vehicle, exploded computer, growing/pruned spatial graph."""
from pathlib import Path
import math,sys
import bpy
from mathutils import Vector,Quaternion
from bpy_extras.object_utils import world_to_camera_view
from explainer.core import read,write,VOICE
from explainer.media import voice
from explainer.traffic_scene import sedan,cube
from explainer.compute_scene import build_compute
from explainer.visual_tools import material,line
from explainer.blender_backend import aim
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/opening-v1';OUT.mkdir(parents=True,exist_ok=True)
TEXT="Can better software help an older car's computer do more? A Tesla patent describes a way to choose useful paths, and stop exploring poor ones. Let's open up that idea, and separate the engineering from the upgrade promises."
if not (OUT/'voice.json').exists():voice({'narration':TEXT},OUT)
a=read(OUT/'voice.json');DURATION=math.ceil((a['seconds']+.55)*30)/30;NF=round(DURATION*30)
write(OUT/'timing.json',{'seconds':DURATION,'frames':NF,'narration':TEXT,'voice':a['profile'],'speech_wpm':a['measured_words_per_minute'],'position_in_film':'opening, from 00:00','width':640,'height':360})
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=6;s.cycles.use_denoising=False
s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2
s.render.threads_mode='FIXED';s.render.threads=4;s.render.resolution_x=640;s.render.resolution_y=360;s.render.resolution_percentage=100;s.render.fps=30
s.world=bpy.data.worlds.new('Opening studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.025,.04,.065,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.65
floor=material('Studio floor',(.035,.05,.07,1));floor.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=0
cube('Floor',(0,0,-.13),(200,200,.24),floor,bevel=0)
car=sedan('Opening EV');car.location=(-3.5,-.5,0)
board,core,parts=build_compute('Opening compute');board.location=(1.4,0,.15);board.scale=(.55,)*3
# Software choices are a spatial illustration above the generic compute module, not literal chip internals.
cyan=material('Retained choice',(.02,.6,.88,1),True);gray=material('Other choices',(.19,.3,.39,1),True)
root_point=Vector((1.4,0,1.8));ends=[Vector((.0,0,3.1)),Vector((1.4,0,3.4)),Vector((2.8,0,3.1))]
nodes=[];branches=[]
def sphere(name,pos,mat):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=.15,location=pos)
 o=bpy.context.object;o.name=name;o.data.materials.append(mat)
 for p in o.data.polygons:p.use_smooth=True
 return o
origin=sphere('Planning goal',root_point,cyan)
for i,end in enumerate(ends):
 node=sphere('Candidate '+str(i+1),end,cyan if i==2 else gray);nodes.append(node)
 branch=line('Candidate connection '+str(i+1),[root_point,(root_point+end)*.5+Vector((0,0,.15)),end],.026,cyan if i==2 else gray);branches.append(branch)
children=[]
for i,p in enumerate([(2.35,.2,4.0),(3.35,.2,3.95)]):
 point=Vector(p);o=sphere('Expanded choice '+str(i),point,cyan);edge=line('Expanded link '+str(i),[ends[2],point],.022,cyan);children.append((o,edge))
link=line('Vehicle compute link',[(-2.5,0,.9),(-.9,0,1.1),(.2,0,.5)],.025,gray)
for name,pos,power,size,color in [('Key',(-2,-5,9),1700,7,(.82,.91,1)),('Rim',(4,5,7),1900,5,(.45,.72,1)),('Fill',(-8,0,6),900,5,(1,.84,.68))]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.size=size;d.color=color
 o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.location=pos;aim(o,(-.3,0,1))
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.dof.use_dof=False
wheel_objects=[o for o in car.children if 'tire' in o.name or 'rim' in o.name]
for o in wheel_objects:o.rotation_mode='QUATERNION'
def ease(x):x=max(0,min(1,x));return x*x*(3-2*x)
poses={}
def apply(f):
 t=f/30;u=t/DURATION;roll=.8*ease(u/.24);car.location.y=-.5+roll
 for obj in wheel_objects:obj.rotation_quaternion=Quaternion((0,1,0),math.pi/2)@Quaternion((0,0,1),-roll/.35)
 core.location.z=1.1*ease((u-.25)/.19)
 reveal=ease((u-.43)/.18);prune=ease((u-.68)/.14)
 origin.scale=(max(.001,reveal),)*3
 for i,(node,branch) in enumerate(zip(nodes,branches)):
  growth=ease((u-.46-i*.035)/.13);retained=1 if i==2 else 1-prune
  node.scale=(max(.001,growth*retained),)*3;branch.data.bevel_factor_end=growth*retained
 for i,(node,edge) in enumerate(children):
  growth=ease((u-.77-i*.025)/.15);node.scale=(max(.001,growth),)*3;edge.data.bevel_factor_end=growth
 link.data.bevel_factor_end=ease((u-.14)/.13)
 if u<.25:
  q=u/.25;cam.location=(2-q,-8+q,5+.2*q);target=Vector((-3.4,0,.8));lens=44;important=[o for o in car.children if o.type=='MESH'];shot='vehicle_hook'
 elif u<.45:
  q=(u-.25)/.2;cam.location=(8-q,-11,8);target=Vector((.6,0,.8));lens=43;important=parts;shot='compute_reveal'
 elif u<.76:
  q=(u-.45)/.31;cam.location=(7-q,-9,6.5+.5*q);target=Vector((1.4,0,2.0));lens=46;important=[origin,*nodes];shot='grow_choices'
 else:
  q=(u-.76)/.24;cam.location=(6-q,-9+q,6.5);target=Vector((1.9,0,2.15));lens=44;important=[origin,nodes[2],*[o for o,e in children]];shot='prune_expand'
 cam.data.lens=lens;aim(cam,target);bpy.context.view_layer.update()
 for attempt in range(5):
  bad=[]
  for o in important:
   if max(o.scale)<.02:continue
   for corner in o.bound_box:
    p=world_to_camera_view(s,cam,o.matrix_world@Vector(corner))
    if p.z<=0 or not (.035<p.x<.965 and .055<p.y<.94):bad.append(o.name);break
  if not bad:break
  cam.data.lens/=1.12
 else:raise ValueError(('Opening crop',f,bad))
 poses[f]={'shot':shot,'car_y':car.location.y,'core_z':core.location.z,'visible_choices':sum(max(n.scale)>.03 for n in nodes),'expanded_choices':sum(max(n.scale)>.03 for n,e in children),'lens':cam.data.lens}
for f in range(NF):apply(f)
assert poses[round(NF*.65)]['visible_choices']==3
assert poses[round(NF*.95)]['visible_choices']==1
assert poses[round(NF*.97)]['expanded_choices']==2
write(OUT/'scene-qa.json',{'frames':NF,'position_in_film':'opening','static_image_sections':False,'choices_before_pruning':3,'choices_after_pruning':1,'new_choices_expanded':2,'camera_shots':sorted(set(v['shot'] for v in poses.values()))})
write(OUT/'poses.json',poses);bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'opening-scene.blend'))
folder=OUT/'raw';folder.mkdir(exist_ok=True)
frames=[0,round(NF*.36),round(NF*.65),round(NF*.94)] if '--stills' in sys.argv else range(NF)
for f in frames:
 p=folder/f'{f:06d}.png'
 if p.exists():continue
 apply(f);s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
print('OPENING RENDER READY',DURATION,'seconds',NF,'frames',flush=True)
