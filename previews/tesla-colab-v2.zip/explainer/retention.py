"""Check explicit hook/payoff plans. Passing is not evidence of viewer retention."""
from __future__ import annotations
import argparse,hashlib,json,math
from pathlib import Path

def _number(value):return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
def _text(value):return isinstance(value,str) and bool(value.strip())

def content_hash(plan):
    contract=dict(plan.get('retention') or {});contract.pop('review',None)
    payload={'shots':plan.get('shots',[]),'claims':plan.get('claims',{}),
             'sources':plan.get('sources',{}),'narration_lock':plan.get('narration_lock',{}),'retention':contract}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def audit(plan,require_review=False):
    errors=[];warnings=[];timeline={};end=0.
    shots=plan.get('shots',[])
    if not isinstance(shots,list):errors.append('Shots must be a list');shots=[]
    for shot in shots:
        if not isinstance(shot,dict):errors.append('Each shot must be an object');continue
        duration=shot.get('seconds',shot.get('duration'))
        if not _number(duration) or duration<=0 or not _text(shot.get('id')):
            errors.append('Timeline requires positive finite shot durations and IDs');continue
        if shot['id'] in timeline:errors.append('Duplicate shot ID: '+shot['id'])
        timeline[shot['id']]={'start':end,'duration':duration,'text':shot.get('narration','')};end+=duration
    contract=plan.get('retention')
    if not isinstance(contract,dict):
        return {'passed':False,'errors':['Missing explicit retention contract'],'warnings':[],
                'scope':'Planning validation, not audience analytics','runtime_seconds':end,'rungs':[]}
    if contract.get('version')!=1:errors.append('Unsupported retention contract version')
    policy={'hook_by_seconds':8,'value_promise_by_seconds':30,'first_reward_by_seconds':30,'max_value_gap_seconds':45,
            'max_unpaid_seconds':45,'max_open_loops':2}
    declared=contract.get('policy',{})
    if not isinstance(declared,dict):errors.append('Retention policy must be an object');declared={}
    for key,default in policy.items():
        value=declared.get(key,default)
        if not _number(value) or value<=0 or (key=='max_open_loops' and not isinstance(value,int)):errors.append('Invalid retention policy: '+key)
        else:policy[key]=value
    def point(value,label):
        if not isinstance(value,dict):errors.append(label+': requires shot, at, and exact spoken quote');return None
        sid=value.get('shot')
        shot=timeline.get(sid) if isinstance(sid,str) else None;offset=value.get('at');quote=value.get('quote')
        if shot is None:errors.append(label+': unknown shot');return None
        if not _number(offset) or not 0<=offset<shot['duration']:
            errors.append(label+': time is outside the shot');return None
        if not _text(quote) or quote not in shot['text']:
            errors.append(label+': quote is absent from the actual narration');return None
        return shot['start']+offset
    opening=contract.get('opening',{})
    if not isinstance(opening,dict):opening={}
    for key in ['viewer_value','visual_action','reason_to_care']:
        if not _text(opening.get(key)):errors.append('Opening requires '+key)
    value_at=point(opening.get('value_promise'),'Opening value promise')
    if value_at is not None and value_at>policy['value_promise_by_seconds']:errors.append('Opening value promise arrives too late')
    rungs=contract.get('rungs',[])
    if not isinstance(rungs,list) or not rungs:errors.append('Define the reward ladder rungs');rungs=[]
    ids=set();knowledge=set();results=[];events=[];rewards=[];previous=-1
    for i,rung in enumerate(rungs):
        prefix=f'Rung {i+1}'
        if not isinstance(rung,dict):errors.append(prefix+': must be an object');continue
        rid=rung.get('id')
        if not _text(rid) or rid in ids:errors.append(prefix+': needs a unique ID')
        else:ids.add(rid)
        new=rung.get('new_knowledge')
        if not _text(new):errors.append(prefix+': state the knowledge reward')
        elif new.strip().casefold() in knowledge:errors.append(prefix+': repeats an earlier reward')
        else:knowledge.add(new.strip().casefold())
        for field in ['visual_payoff','audio_direction','viewer_question']:
            if not _text(rung.get(field)):errors.append(prefix+': requires '+field)
        prompt=point(rung.get('prompt'),prefix+' prompt');payoff=point(rung.get('payoff'),prefix+' payoff')
        if prompt is not None:
            if prompt<previous:errors.append(prefix+': ladder prompts must be in chronological order')
            previous=prompt
        if prompt is not None and payoff is not None:
            if payoff<=prompt:errors.append(prefix+': payoff must follow its prompt')
            if payoff-prompt>policy['max_unpaid_seconds']:errors.append(prefix+': promise stays unpaid too long')
            rewards.append(payoff);events.extend([(prompt,1),(payoff,-1)])
            results.append({'id':rid,'prompt_seconds':prompt,'payoff_seconds':payoff,'wait_seconds':payoff-prompt,'new_knowledge':new})
        claims=rung.get('claim_ids')
        if not isinstance(claims,list) or not claims:errors.append(prefix+': link supporting claim IDs')
        else:
            for cid in claims:
                claim=plan.get('claims',{}).get(cid,{}) if isinstance(cid,str) else {}
                if claim.get('status')!='verified' or not claim.get('sources'):errors.append(prefix+': unverified or missing claim '+str(cid))
                elif any(sid not in plan.get('sources',{}) for sid in claim['sources']):errors.append(prefix+': source reference does not exist')
        if rung.get('music',False):errors.append(prefix+': music conflicts with channel direction')
        if rung.get('audio_kind','narration') not in ['narration','pause','mechanical']:
            errors.append(prefix+': unsupported audio direction')
    for rung in rungs:
        if isinstance(rung,dict) and rung.get('next_rung'):
            following=rung['next_rung']
            if not isinstance(following,str) or following not in ids:errors.append('Dangling next-rung reference: '+str(rung.get('id')))
            else:
                times={r['id']:r['prompt_seconds'] for r in results}
                if following in times and rung.get('id') in times and times[following]<=times[rung['id']]:errors.append('Next rung must move the ladder forward')
    if results and results[0]['prompt_seconds']>policy['hook_by_seconds']:errors.append('First hook arrives too late')
    if rewards and min(rewards)>policy['first_reward_by_seconds']:errors.append('First concrete reward arrives too late')
    checkpoints=[0.,*sorted(rewards),end]
    gaps=[b-a for a,b in zip(checkpoints,checkpoints[1:])]
    if gaps and max(gaps)>policy['max_value_gap_seconds']:errors.append('Long stretch without a declared new-value payoff')
    opened=maximum=0
    for _,change in sorted(events):opened+=change;maximum=max(maximum,opened)
    if maximum>policy['max_open_loops']:errors.append('Too many simultaneous unanswered promises')
    timing=contract.get('timing_basis')
    if timing not in ['estimated','measured']:errors.append('Declare estimated or measured timing')
    if timing=='estimated':warnings.append('Draft timing only: measure and review the narration before production')
    if require_review:
        if timing!='measured':errors.append('Production requires measured narration timing')
        locks=plan.get('narration_lock',{})
        for sid,shot in timeline.items():
            lock=locks.get(sid,{})
            if (lock.get('text')!=shot['text'] or not isinstance(lock.get('sha256'),str) or len(lock['sha256'])!=64
                or not _number(lock.get('seconds')) or not 0<lock['seconds']<=shot['duration']):
                errors.append('Measured frozen narration is missing or stale: '+sid)
        review=contract.get('review',{})
        if not isinstance(review,dict) or review.get('status')!='passed' or review.get('content_sha256')!=content_hash(plan):
            errors.append('Current editorial retention review is required')
        if not isinstance(review,dict) or not all(_text(review.get(k)) for k in ['script_notes','visual_notes','audio_notes']):
            errors.append('Editorial review must document script, visual and audio checks')
    return {'passed':not errors,'errors':errors,'warnings':warnings,'runtime_seconds':end,
            'timing_basis':timing,'rungs':results,'maximum_open_loops':maximum,
            'longest_value_gap_seconds':max(gaps,default=0),'content_sha256':content_hash(plan),
            'scope':'Structural/editorial planning validation; no measured audience retention or guarantee of engagement'}

def require(plan,review=False):
    report=audit(plan,require_review=review)
    if not report['passed']:raise ValueError('Retention gate: '+'; '.join(report['errors']))
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('plan');parser.add_argument('--require-review',action='store_true');parser.add_argument('--out');args=parser.parse_args()
    result=audit(json.loads(Path(args.plan).read_text()),args.require_review)
    text=json.dumps(result,indent=2)+'\n'
    if args.out:Path(args.out).write_text(text)
    print(text,end='')
    raise SystemExit(0 if result['passed'] else 1)
