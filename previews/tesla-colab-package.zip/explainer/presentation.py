"""Subject-dependent defaults; explicit shot choices remain part of storyboard approval."""
THEMES = {
    'dark': {'background': (.025, .03, .04, 1), 'ink': (.92, .95, 1, 1),
             'structure': (.3, .34, .4, 1), 'active': (.9, .25, .08, 1),
             'flow': (.04, .45, .95, 1), 'signal': (1, .7, .08, 1),
             'context': (.43, .46, .52, 1), 'section': (.55, .59, .64, 1)},
    'light': {'background': (.85, .88, .92, 1), 'ink': (.015, .025, .04, 1),
              'structure': (.12, .16, .22, 1), 'active': (.65, .09, .025, 1),
              'flow': (.015, .16, .5, 1), 'signal': (.38, .19, .015, 1),
              'context': (.28, .32, .38, 1), 'section': (.48, .52, .58, 1)}}


def resolve_theme(shot):
    selected = shot.get('presentation', {}).get('background', 'auto')
    if selected == 'auto':
        # Readability starting points, not an assertion that shot accuracy predicts best art direction.
        selected = 'dark' if shot.get('accuracy') == 'literal' else 'light'
    if selected not in THEMES:
        raise ValueError(f'Unknown background {selected}')
    return selected, dict(THEMES[selected])
