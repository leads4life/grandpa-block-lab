from copy import deepcopy
import json
from pathlib import Path
import struct
import tempfile
import unittest
from explainer.assets import credits, dependencies, model_errors, register_model, rights_errors
from explainer.core import fingerprint, read, validate, write


def rights(license='CC0-1.0'):
    return {'title':'Synthetic test model', 'creator':'Test fixture author', 'source_url':'https://example.org/model',
            'license':license, 'license_url':'https://creativecommons.org/publicdomain/zero/1.0/',
            'accessed':'2026-10-25', 'price':0, 'commercial_use':True, 'modification_allowed':True,
            'rights_review':'approved', 'review_notes':'Synthetic unit fixture, not third-party evidence.',
            'additional_restrictions':[]}


class Assets(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.source = self.base/'source'; self.source.mkdir()
        self.root = self.base/'project'; self.root.mkdir()
        self.plan = read(Path(__file__).parents[1]/'examples/contract-fixture.json')
        write(self.root/'plan.json',self.plan)
        self.model = self.source/'model.gltf'
        self.model.write_text(json.dumps({'asset':{'version':'2.0'},'buffers':[{'uri':'mesh.bin'}],
                                         'images':[{'uri':'texture.png'}]}))
        (self.source/'mesh.bin').write_bytes(b'buffer')
        (self.source/'texture.png').write_bytes(b'pixels')
        self.evidence = self.base/'license.txt';self.evidence.write_text('Synthetic fixture license evidence')

    def register(self, **kwargs):
        return register_model(self.root,'sample',self.model,kwargs.get('rights',rights()),self.evidence,1,'Unit fixture in meters')

    def test_cli_registration_and_credit_export(self):
        from explainer.__main__ import main
        from contextlib import redirect_stdout
        from io import StringIO
        metadata=self.base/'rights.json';write(metadata,rights())
        with redirect_stdout(StringIO()):
            main(['register-model',str(self.root),'cli_asset',str(self.model),
                  '--rights',str(metadata),'--evidence',str(self.evidence),
                  '--meters-per-unit','1','--units-notes','Original test units'])
            main(['credits',str(self.root)])
        self.assertEqual(read(self.root/'plan.json')['assets']['cli_asset']['review'],'pending')
        self.assertIn('CC0-1.0',(self.root/'CREDITS.md').read_text())

    def test_mismatched_reviewed_download_checksum_is_rejected(self):
        r=rights();r['download_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'source checksum'):self.register(rights=r)
        self.assertEqual(read(self.root/'plan.json')['assets'],{})

    def test_license_evidence_changes_invalidate_fingerprint(self):
        a=self.register();p=read(self.root/'plan.json');before=fingerprint(p,self.root)
        (self.root/a['license_evidence']).write_text('different terms')
        self.assertNotEqual(before,fingerprint(p,self.root))
        self.assertTrue(model_errors(a,self.root))

    def test_allowed_licenses_and_required_credits(self):
        self.assertEqual(rights_errors(rights()),[])
        r=rights('CC-BY-4.0');r['license_url']='https://creativecommons.org/licenses/by/4.0/'
        self.assertTrue(any('attribution' in x for x in rights_errors(r)))
        r['attribution']='Model by Author, CC BY 4.0.'
        r['changes']='No geometry changes; positioned for rendering.'
        self.assertEqual(rights_errors(r),[])
        self.assertIn(r['attribution'],credits({'assets':{'m':{'kind':'model','rights':r}}}))

    def test_noncommercial_noderivatives_editorial_unknown_are_blocked(self):
        for license in ['CC-BY-NC-4.0','CC-BY-ND-4.0','Editorial','Unknown','CC-BY-SA-4.0']:
            self.assertTrue(rights_errors(rights(license)))

    def test_paid_and_nonmodifiable_are_blocked(self):
        for field,value in [('price',1),('price',True),('commercial_use',False),('modification_allowed',False),
                            ('additional_restrictions',['editorial only'])]:
            r=rights();r[field]=value;self.assertTrue(rights_errors(r))

    def test_mislabeled_license_url_and_unexplained_public_domain_blocked(self):
        r=rights();r['license_url']='https://example.org/noncommercial';self.assertTrue(rights_errors(r))
        r=rights('LicenseRef-Public-Domain');self.assertTrue(rights_errors(r))

    def test_register_copies_complete_package_but_keeps_visual_review_pending(self):
        a=self.register();self.assertEqual(a['review'],'pending')
        self.assertEqual(len(a['files']),4)
        self.assertEqual(model_errors(a,self.root),[])
        self.assertTrue((self.root/a['license_evidence']).exists())
        self.assertTrue(any('accuracy/provenance' in x for x in validate(read(self.root/'plan.json'),self.root)))

    def test_changed_texture_invalidates_approval_fingerprint_and_manifest(self):
        a=self.register();p=read(self.root/'plan.json');before=fingerprint(p,self.root)
        (self.root/'assets/sample/source/texture.png').write_bytes(b'new pixels')
        self.assertNotEqual(before,fingerprint(p,self.root))
        self.assertTrue(any('bytes changed' in x for x in model_errors(a,self.root)))

    def test_missing_dependency_and_manifest_omissions_are_blocked(self):
        a=self.register();a['files'].pop('assets/sample/source/texture.png')
        self.assertTrue(any('exactly match' in x for x in model_errors(a,self.root)))
        (self.source/'mesh.bin').unlink()
        with self.assertRaisesRegex(ValueError,'Missing'):dependencies(self.model)

    def test_external_and_encoded_escaping_uris_are_blocked(self):
        for uri in ['https://example.org/file.bin','../outside.bin','%2e%2e/outside.bin','file:///etc/passwd','/tmp/a.bin','C:\\file.bin']:
            self.model.write_text(json.dumps({'buffers':[{'uri':uri}]}))
            with self.assertRaises(ValueError):dependencies(self.model)

    def test_symlink_escape_is_blocked(self):
        (self.source/'escape.bin').symlink_to(self.evidence)
        self.model.write_text(json.dumps({'buffers':[{'uri':'escape.bin'}]}))
        with self.assertRaisesRegex(ValueError,'escapes'):dependencies(self.model)

    def test_glb_embedded_resources_and_header_validation(self):
        path=self.source/'test.glb';doc=json.dumps({'asset':{'version':'2.0'},'buffers':[{'uri':'data:application/octet-stream;base64,AA=='}]}).encode()
        doc+=b' '*((-len(doc))%4)
        path.write_bytes(struct.pack('<4sIIII',b'glTF',2,20+len(doc),len(doc),0x4e4f534a)+doc)
        self.assertEqual(dependencies(path),[path.resolve()])
        path.write_bytes(b'invalid')
        with self.assertRaisesRegex(ValueError,'Truncated'):dependencies(path)

    def test_obj_material_and_texture_dependencies_are_preserved(self):
        path=self.source/'model.obj';path.write_text('mtllib material.mtl\nv 0 0 0\n')
        (self.source/'material.mtl').write_text('newmtl test\nmap_Kd texture.png\n')
        self.assertEqual(len(dependencies(path)),3)
        (self.source/'material.mtl').write_text('map_Kd -s 1 1 1 texture.png\n')
        with self.assertRaisesRegex(ValueError,'texture options'):dependencies(path)

    def test_duplicate_registration_does_not_overwrite(self):
        self.register();before=(self.root/'plan.json').read_bytes()
        with self.assertRaisesRegex(ValueError,'overwrite'):self.register()
        self.assertEqual(before,(self.root/'plan.json').read_bytes())

    def test_invalid_units_leave_no_registered_asset(self):
        with self.assertRaisesRegex(ValueError,'meters_per_unit'):
            register_model(self.root,'bad',self.model,rights(),self.evidence,float('nan'),'unknown')
        self.assertFalse((self.root/'assets/bad').exists())
        self.assertEqual(read(self.root/'plan.json')['assets'],{})

    def test_valid_model_component_and_unsupported_model_cut_are_checked(self):
        a=self.register();p=read(self.root/'plan.json');p['assets']['sample']['review']='approved'
        s=p['shots'][0];s['components']=[{'id':'imported','shape':'model','asset_id':'sample','role':'structure','position':[0,0,0],'scale':1}]
        s['asset_ids']=['sample']
        self.assertEqual(validate(p,self.root),[])
        s['components'][0]['section']={'axis':'x','keep':'positive'}
        self.assertTrue(any('model sections' in x for x in validate(p,self.root)))
