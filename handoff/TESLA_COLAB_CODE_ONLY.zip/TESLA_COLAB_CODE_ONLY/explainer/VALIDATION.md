# Validation evidence — 2026-10-25

- Standard-library contract/approval suite: **52 tests passed**.
- Supplied Markdown example parsed into **13 unverified draft shots / 295 seconds**. No episode project was produced from it.
- Blender 5.2.3 / Python 3.13: rendered **45 frames at 640×360 / 30 fps** of a synthetic assembly; Kokoro `am_michael` generated measured narration; a timed quiet synthetic mechanical click was mixed and ducked beneath speech. No music.
- H.264 / yuv420p, AAC / 48 kHz, duration, frame count, no subtitle stream, loudness and peak checks all passed. Last calibration: **-15.3 LUFS**, **-2.9 dBFS**. The gain/limiter correction loop needed **3 attempts** and retained their results.
- Two calibration clips assembled and passed media checks; exact shot windows avoid accumulated AAC padding drift.
- A deliberately cropped scene passed real all-frame bounding-box checks after **three** automatic lens adjustments.
- Static-image adapter produced an encoded, measured-narration clip from a reviewed synthetic pixel-chart asset and passed media QA.
- Diagnostic assembly contact sheet inspected: stable base, separated moving cylinder, consistent framing. This is internal tooling evidence, not a user-facing creative preview or a complete scientific/motion/audio review.
- Repository diff whitespace checks and Python compilation passed. Grandpa's engine, bibles, stories, frozen voices and queue were not changed.

Current calibration artifacts: `build/selftest/build/87a6cff3a974c5e7/preview/calibration/`.
No real storyboard/preview approvals were recorded. No full-resolution episode, publishing, new subject research or complex mechanical model was attempted. Native CAD import, general imported-model cutaways/transverse tube sections, complex mechanisms and recorded SFX remain future subject/production adapters; fact checking and visual/technical inspection remain Codex responsibilities, not software-certified truth.

## Subject-dependent visual toolkit checks

- Real Blender smoke rendered three diagnostic frames per theme, light and dark; both passed framing checks. Artifacts: `build/visual-selftest/e99f042e5a74ff07/`.
- A longitudinal section of a hollow tube retained a watertight mesh, the correct removed half, the original scale and an open bore. This verifies the tested primitive section, not arbitrary CAD models.
- Flow-marker start/end positions matched the path. Moving-component leader endpoints matched the component center at all three test frames.
- Both rendered contact sheets inspected. Weak light-theme technical ink was corrected by removing studio reflections from text/overlay materials; renders then rechecked.
- Automatic theme selection, explicit overrides/reasons, palette contrast, invalid cut planes/walls, nonexistent leader targets, degenerate arrows and ignored image overlays are covered by contract tests.
- Existing narration, mechanical sound, media encoding, two-clip assembly, static-image and framing-repair smoke checks also passed after the renderer update.
- These are synthetic internal diagnostics. No actual episode or user approval has been manufactured.

## Free commercial model importing

- **52 unit/contract tests passed**, including registration/credits CLI, NC/ND/editorial/unknown/paid rejection, source checksum matching, CC BY attribution/change requirements, copied resource manifests, missing/remote/escaping resources, texture/license changes and duplicate protection.
- Actual Blender import/render smoke passed for **GLB, glTF, OBJ and STL**. The GLB specimen is Khronos's Avocado with model-specific CC0 evidence; the remaining formats use an original textured calibration cube.
- Source commit: `8f492390ddc7a2ae221a1369ef560589cf8c70fb`. Upstream license evidence and download URL/hash are retained under `examples/licenses/`. No inference was made from a collection-wide license.
- Imported GLB textures were present and packed; glTF and OBJ textures survived the round trip. STL was verified as geometry-only. The test retained uniform proportions, moved the imported instance and attached a tracking callout. Four rendered diagnostic contact sheets inspected.
- A complete low-resolution GLB test clip passed narration, restrained SFX, video/audio format, duration, frame-count, loudness and clipping checks through the actual production media path. This was a calibration test, not a user-approved episode.
- Registration records remain `pending` for visual/accuracy review. Only isolated diagnostic copies simulated review to exercise the importer. No real storyboard/preview approvals were created.
- Existing media/assembly/static-image/framing and section/flow/theme regression smoke suites passed after the integration.
- Limits: static geometry/material imports and whole-instance motion; native CAD, source animation/retargeting, per-imported-part controls and arbitrary imported-mesh sections remain future adapters. Records require actual source review; software does not certify ownership or license assertions.

Importer test artifact index: `build/model-selftest/import-results.json`.
