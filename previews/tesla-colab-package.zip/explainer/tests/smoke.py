"""Real media/Blender smoke; synthetic fixture only, no user approval records."""
from pathlib import Path
from explainer.core import read, write
from explainer.__main__ import produce, require_valid


def main():
    root = Path(__file__).resolve().parents[1] / 'build/selftest'
    root.mkdir(parents=True, exist_ok=True)
    plan = read(Path(__file__).resolve().parents[1] / 'examples/contract-fixture.json')
    write(root / 'plan.json', plan)
    require_valid(plan, root)
    out = produce(root, plan, plan['shots'][0], 'preview')
    assert read(out / 'qa.json')['passed']
    assert (out / 'contact-sheet.png').stat().st_size > 1000
    from explainer.media import assemble, check_video
    assembled = out / 'assembly-test.mp4'
    assemble([out / 'video.mp4'] * 2, [plan['shots'][0]['duration']] * 2, assembled)
    assert check_video(assembled, plan['shots'][0]['duration'] * 2, 640, 360)['passed']
    assert not (root / 'approvals').exists()
    # Exercise actual safe camera correction without running a second animation render.
    from copy import deepcopy
    from explainer.blender_backend import build, framing
    cropped = deepcopy(plan['shots'][0])
    cropped['camera']['lens'] = 110
    scene, objects = build(cropped, 320, 180, 30, 3)
    assert framing(scene, objects, 3)
    repairs = 0
    while framing(scene, objects, 3) and repairs < 3:
        scene.camera.data.lens /= 1.25
        repairs += 1
    assert not framing(scene, objects, 3)
    write(root / 'framing-test.json', {'passed': True, 'repairs': repairs})
    # A synthetic static pixel chart verifies the image adapter, not image generation quality.
    import hashlib
    from PIL import Image, ImageDraw
    image_root = root.parent / 'image-selftest'
    image_root.mkdir(exist_ok=True)
    image = Image.new('RGB', (320, 180), '#243446')
    ImageDraw.Draw(image).rectangle((80, 60, 240, 120), fill='#ca9850')
    image.save(image_root / 'chart.png')
    image_plan = deepcopy(plan)
    image_plan['assets'] = {'chart': {'kind': 'image', 'path': 'chart.png', 'review': 'approved',
        'provenance': 'Synthetic calibration chart, not an educational image',
        'sha256': hashlib.sha256((image_root / 'chart.png').read_bytes()).hexdigest()}}
    image_shot = image_plan['shots'][0]
    image_shot.update({'visual_type': 'image', 'components': [], 'asset_ids': ['chart']})
    write(image_root / 'plan.json', image_plan)
    require_valid(image_plan, image_root)
    image_out = produce(image_root, image_plan, image_shot, 'preview')
    assert read(image_out / 'qa.json')['passed']
    print('SYNTHETIC SMOKE PASSED:', out)
    print('STATIC IMAGE SMOKE PASSED:', image_out)
    print('FRAMING REPAIR PASSED:', repairs, 'adjustments')


if __name__ == '__main__': main()
