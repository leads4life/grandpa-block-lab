"""Original generic EV prop; +Y forward, Z=0 ground, metres; no OEM CAD claims.

``build_vehicle`` returns a parent empty. Wheel rig children have
``vehicle_part='wheel'`` and ``roll_axis='X'``; rotate local X by distance/.34.
Roof and glazing are separate named children for deliberate technical cutaways.
"""
import math
import bpy
from .traffic_scene import cube
from .visual_tools import material, line


def build_vehicle(name='EV', paint_color=(.025,.19,.38,1)):
    root=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(root)
    paint=material(name+' metallic paint',paint_color)
    sh=paint.node_tree.nodes['Principled BSDF'];sh.inputs['Metallic'].default_value=.68;sh.inputs['Roughness'].default_value=.32
    glass=material(name+' smoked glazing',(.015,.035,.052,1));glass.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.24;glass.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=0;glass.node_tree.nodes['Principled BSDF'].inputs['Specular IOR Level'].default_value=.22
    rubber=material(name+' rubber',(.012,.016,.021,1));rubber.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=0
    alloy=material(name+' machined alloy',(.42,.49,.57,1));alloy.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=.85
    dark=material(name+' dark trim',(.02,.026,.032,1));dark.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=.15
    lamp=material(name+' LED',(.72,.88,1,1),True);red=material(name+' rear LED',(.7,.025,.02,1),True)
    def mesh(label,verts,faces,mat,parent=root):
        data=bpy.data.meshes.new(name+' '+label);data.from_pydata(verts,[],faces);data.update()
        obj=bpy.data.objects.new(name+' '+label,data);bpy.context.collection.objects.link(obj);obj.parent=parent;obj.data.materials.append(mat)
        for p in data.polygons:p.use_smooth=True
        return obj
    # Rounded, tapered multi-section lower shell; smaller end sections give real overhang/bumper curvature.
    stations=[(-2.32,.66,.35,.81),(-2.22,.82,.31,.91),(-1.95,.89,.29,.98),(-1.55,.93,.28,1.00),(-.9,.935,.28,1.02),
              (0,.93,.28,1.01),(.7,.92,.28,.99),(1.25,.91,.29,.94),(1.8,.87,.31,.84),(2.15,.79,.35,.75),(2.32,.61,.40,.66)]
    vertices=[]
    for y,w,z,top in stations:
        vertices.extend([(-w*.76,y,z),(-w,y,z+.14),(-w,y,top-.16),(-w*.87,y,top),
                         (w*.87,y,top),(w,y,top-.16),(w,y,z+.14),(w*.76,y,z)])
    n=8;faces=[]
    for j in range(len(stations)-1):
        for k in range(n):faces.append((j*n+k,j*n+(k+1)%n,(j+1)*n+(k+1)%n,(j+1)*n+k))
    faces.extend([tuple(reversed(range(n))),tuple((len(stations)-1)*n+k for k in range(n))])
    body=mesh('lower shell',vertices,faces,paint)
    # Broad rounding first, then real wheel cavities through the solid shell.
    mod=body.modifiers.new('Panel radii','BEVEL');mod.width=.09;mod.segments=3
    bpy.context.view_layer.objects.active=body;bpy.ops.object.modifier_apply(modifier=mod.name)
    for x in [-.91,.91]:
        for y in [-1.42,1.42]:
            bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.385,depth=.95,location=(x,y,.34),rotation=(0,math.pi/2,0))
            cutter=bpy.context.object;bpy.context.view_layer.objects.active=body
            mod=body.modifiers.new('Wheel well','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter
            bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cutter,do_unlink=True)
    mod=body.modifiers.new('Arch edge radii','BEVEL');mod.width=.012;mod.segments=2
    body.modifiers.new('Panel normals','WEIGHTED_NORMAL')
    # Continuous sloped glazed cabin: rising rear screen, crown, then sloping windshield.
    stations=[(-1.42,.72,1.005),(-1.17,.72,1.22),(-.75,.69,1.46),(-.30,.68,1.53),(.25,.67,1.49),(.65,.70,1.29),(1.02,.75,1.00)]
    vv=[]
    for y,w,top in stations:
        vv.extend([(-.82,y,.98),(-w,y,top-.035),(0,y,top+.025),(w,y,top-.035),(.82,y,.98)])
    ff=[]
    for j in range(len(stations)-1):
        for k in range(4):ff.append((j*5+k,(j+1)*5+k,(j+1)*5+k+1,j*5+k+1))
    ff.extend([tuple(reversed(range(5))),tuple((len(stations)-1)*5+k for k in range(5)),(0,4,34,30)])
    glazing=mesh('glazing',vv,ff,glass);glazing['vehicle_part']='glazing'
    # A slim painted roof cap, leaving distinct front and rear screens.
    roof=mesh('roof',[(-.67,-.76,1.475),(.67,-.76,1.475),(.665,.22,1.505),(-.665,.22,1.505),
                      (-.55,-.76,1.54),(.55,-.76,1.54),(.55,.22,1.56),(-.55,.22,1.56)],
                     [(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7),(3,2,1,0)],paint)
    roof['vehicle_part']='roof';m=roof.modifiers.new('Roof radii','BEVEL');m.width=.04;m.segments=3;roof.modifiers.new('Roof normals','WEIGHTED_NORMAL')
    for sign in [-1,1]:
        # Beltline and pillars delineate windows; minor trim sits outside glazing.
        for label,points in [('window sill',[(sign*.84,-1.32,1.015),(sign*.84,.96,1.015)]),
                             ('B pillar',[(sign*.835,-.26,1.025),(sign*.695,-.26,1.50)]),
                             ('A pillar',[(sign*.80,.98,1.015),(sign*.68,.25,1.49)]),
                             ('rear pillar',[(sign*.81,-1.36,1.015),(sign*.70,-.75,1.46)])]:
            ob=line(name+' '+label,points,.022,paint if label!='B pillar' else dark);ob.parent=root
        for y in [-.63,.47]:cube(name+' flush handle',(sign*.935,y,.94),(.018,.19,.027),dark,root,.01)
        mirror=cube(name+' mirror',(sign*1.0,.65,1.03),(.22,.22,.11),paint,root,.06)
        cube(name+' rocker',(sign*.895,0,.32),(.08,1.9,.09),dark,root,.035)
        for y,label,mat in [(2.24,'headlamp',lamp),(-2.24,'tail lamp',red)]:
            obj=cube(name+' '+label,(sign*.50,y,.735 if y>0 else .86),(.47,.035,.055),mat,root,.022)
        # Mesh cylinders oriented X; wheel parent rotates about its local X, with clear spoke motion.
        for y in [-1.42,1.42]:
            rig=bpy.data.objects.new(name+' wheel '+str(sign)+' '+str(y),None);bpy.context.collection.objects.link(rig)
            rig.parent=root;rig.location=(sign*.91,y,.34);rig['vehicle_part']='wheel';rig['roll_axis']='X';rig['radius']=.34
            def cylinder(label,radius,depth,mat,x=0):
                bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=radius,depth=depth,location=(x,0,0),rotation=(0,math.pi/2,0))
                obj=bpy.context.object;obj.name=name+' '+label;obj.parent=rig;obj.data.materials.append(mat)
                bevel=obj.modifiers.new('Edge rounding','BEVEL');bevel.width=.015;bevel.segments=2;obj.modifiers.new('Normals','WEIGHTED_NORMAL')
                for p in obj.data.polygons:p.use_smooth=True
                return obj
            cylinder('tire',.34,.20,rubber);cylinder('rim recess',.252,.207,dark)
            cylinder('hub',.074,.235,alloy)
            # Rim ring by torus; axisX, entirely inside tire envelope.
            bpy.ops.mesh.primitive_torus_add(major_radius=.229,minor_radius=.018,major_segments=48,minor_segments=8,location=(sign*.108,0,0),rotation=(0,math.pi/2,0))
            tor=bpy.context.object;tor.name=name+' rim ring';tor.parent=rig;tor.data.materials.append(alloy)
            for k in range(5):
                a=2*math.pi*k/5
                spoke=cube(name+' spoke',(sign*.115,math.sin(a)*.142,math.cos(a)*.142),(.035,.034,.20),alloy,rig,.012)
                spoke.rotation_euler.x=-a
    cube(name+' lower intake',(0,2.24,.52),(.94,.055,.10),dark,root,.04)
    cube(name+' rear valance',(0,-2.25,.47),(1.2,.055,.10),dark,root,.04)
    root['provenance']='Original procedural project geometry; no downloaded/OEM asset'
    root['accuracy']='Generic illustrative 4.6 m EV; not Tesla CAD or hardware location evidence'
    return root
