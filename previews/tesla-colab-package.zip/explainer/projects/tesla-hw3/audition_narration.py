"""Short controlled narration audition. Does not alter the production voice or plan."""
from pathlib import Path
import math,os,json,subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
from PIL import Image,ImageDraw,ImageFont
from kokoro_onnx import Kokoro
from explainer.core import write
from explainer.media import check_video
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/voice-audition';OUT.mkdir(parents=True,exist_ok=True)
TEXT="Can smarter software help an older driving computer do more? A Tesla patent, published in April twenty twenty-six, describes one way to approach that problem. The idea is to organize the possible decisions, score them, and stop exploring the poor choices. That could make planning more efficient. But there's an important distinction: this patent doesn't promise that Hardware Three gets every feature of a newer car. Let's look at how the method works."
engine=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES'])
available=engine.get_voices()
assert 'am_michael' in available and 'am_fenrir' in available
fontdir=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False):return ImageFont.truetype(str(fontdir/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
results={}
cache=json.loads((OUT/'comparison.json').read_text()) if (OUT/'comparison.json').exists() else {}
for key,voice,title,subtitle in [('A','am_michael','Same narrator','Conversational phrasing and revised punctuation'),('B','am_fenrir','Alternative narrator','Same script; adjusted speaking pace')]:
 speed=1.0 if key=='A' else .80
 cached=cache.get('auditions',{}).get(key,{})
 if cache.get('script')==TEXT and cached.get('speed',1.0)==speed and (OUT/f'narration-{key}.mp4').exists():
  results[key]=dict(cached,speed=speed);print('Reusing unchanged audition',key,flush=True);continue
 samples,sr,timed=engine.create_timed(TEXT,voice=voice,speed=speed,sentence_pause=.18,clause_pause=.06,continuous=False)
 samples=np.asarray(samples,dtype=np.float64);assert np.isfinite(samples).all() and np.abs(samples).max()>.01
 divisor=math.gcd(int(sr),48000);samples=resample_poly(samples,48000//divisor,int(sr)//divisor)
 samples*=.7/np.abs(samples).max();samples=np.concatenate([np.zeros(12000),samples,np.zeros(24000)])
 seconds=math.ceil(len(samples)/48000*30)/30
 samples=np.pad(samples,(0,round(seconds*48000)-len(samples)))
 wavfile.write(OUT/f'voice-{key}.wav',48000,(samples*32767).astype(np.int16))
 card=Image.new('RGB',(960,540),'#0b1825');draw=ImageDraw.Draw(card)
 draw.text((62,65),'NARRATION AUDITION',font=font(14,True),fill='#6ddcf5')
 draw.text((60,140),key+'  /  '+title,font=font(39,True),fill='#edf6ff')
 draw.text((64,210),subtitle,font=font(22),fill='#b4cadb')
 draw.line((64,278,896,278),fill='#2d536b',width=2)
 draw.text((64,321),'Listen for ease, rhythm, and clarity.',font=font(24),fill='#edf6ff')
 draw.text((64,370),'No change to the production voice until you choose.',font=font(17),fill='#9eb8cc')
 draw.text((64,467),'Same facts  •  No music  •  No time-stretching',font=font(15),fill='#8db1c8')
 card.save(OUT/f'card-{key}.png')
 gain=0
 for attempt in range(4):
  video=OUT/f'narration-{key}.mp4'
  subprocess.run(['ffmpeg','-v','error','-y','-loop','1','-i',str(OUT/f'card-{key}.png'),'-i',str(OUT/f'voice-{key}.wav'),
   '-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:attack=2:release=60:level=false:latency=1,apad',
   '-t',str(seconds),'-r','30','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-movflags','+faststart',str(video)],check=True)
  qa=check_video(video,seconds,960,540)
  if qa['passed']:break
  gain+=-14-qa['lufs']
 assert qa['passed'],qa
 results[key]={'voice':voice,'speed':speed,'seconds':seconds,'words':len(TEXT.split()),'words_per_minute':round(len(TEXT.split())/(seconds-.75)*60,1),'continuous':False,'sentence_pause':.18,'clause_pause':.06,'qa':qa,'phoneme_timing_count':len(timed),'title':title}
 print('Audition',key,'ready:',round(seconds,2),'seconds',flush=True)
write(OUT/'comparison.json',{'script':TEXT,'production_voice_changed':False,'auditions':results})
(OUT/'script.txt').write_text(TEXT+'\n')
print('NARRATION AUDITIONS READY')
