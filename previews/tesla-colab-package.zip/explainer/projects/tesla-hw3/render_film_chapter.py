"""Subject-specific continuous 3D chapters, original geometry and resumable native frames."""
from pathlib import Path
import argparse, hashlib, math, sys
import bpy
from mathutils import Vector,Quaternion
from bpy_extras.object_utils import world_to_camera_view
from explainer.core import read,write
from explainer.vehicle_prop import build_vehicle
from explainer.compute_scene import build_compute
from explainer.traffic_scene import cube,intersection
from explainer.visual_tools import material,line
from explainer.blender_backend import aim
from explainer.turn_motion import pose,rectangles_overlap,circle_clearance,smooth

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v1'
a=argparse.ArgumentParser();a.add_argument('--index',type=int,required=True);a.add_argument('--stills',action='store_true');args=a.parse_args()
m=read(OUT/'manifest.json');shot=m['shots'][args.index];folder=OUT/shot['id'];folder.mkdir(exist_ok=True)
NF=shot['frames'];D=shot['seconds'];mode=shot['mode']
bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene
s.render.engine='CYCLES';s.cycles.samples=m['render_samples'];s.cycles.use_denoising=False;s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2;s.render.use_persistent_data=False
s.render.threads_mode='FIXED';s.render.threads=4;s.render.resolution_x=m['width'];s.render.resolution_y=m['height'];s.render.resolution_percentage=100;s.render.fps=30
s.world=bpy.data.worlds.new('Studio sky');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.25,.34,.46,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.65
def mat(name,color):
 x=material(name,(*color,1));x.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=0;return x
dark=mat('Stage',(.025,.045,.065));white=mat('Light surfaces',(.65,.72,.77));steel=mat('Structure',(.14,.21,.27));grass=mat('Planting',(.07,.19,.15));orange=mat('Pedestrian jacket',(.8,.34,.045));skin=mat('Skin',(.56,.34,.20))
cyan=material('Promising',(.02,.68,.86,1),True);red=material('Poor branch',(.9,.14,.07,1),True);gray=material('Candidate',(.34,.43,.5,1),True);gold=material('Relevant agent',(.95,.56,.12,1),True)
cube('Studio ground',(0,0,-.5),(200,200,.7),dark,bevel=0)
for name,pos,power,size in [('Key',(-12,-16,32),21000,24),('Rim',(20,18,30),17000,20)]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.size=size;o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.location=pos;aim(o,(0,0,0))
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.clip_end=400;cam.data.dof.use_dof=False
labels=[];important=[];nodes=[];edges=[];bars=[];tasks=[];mini_context=[]
def visible(root,value):
 for o in [root,*root.children_recursive]:o.hide_render=not value
def label(text,target):labels.append((text,target))
def sphere(name,location,radius,material,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=radius,location=location);o=bpy.context.object;o.name=name;o.data.materials.append(material);o.parent=parent
 for p in o.data.polygons:p.use_smooth=True
 return o
def person(name,parent=None):
 root=bpy.data.objects.new(name,None);s.collection.objects.link(root);root.parent=parent
 cube(name+' coat',(0,0,1.18),(.43,.26,.57),orange,root,.065);sphere(name+' head',(0,0,1.62),.16,skin,root)
 limbs=[]
 for sign in [-1,1]:
  leg=cube(name+' leg',(sign*.12,0,.51),(.15,.17,.78),steel,root,.05)
  foot=cube(name+' shoe',(sign*.12,.02,.10),(.18,.32,.17),steel,root,.035)
  arm=cube(name+' arm',(sign*.28,0,1.11),(.12,.16,.55),orange,root,.04);limbs.append((sign,leg,foot,arm))
 return root,limbs
def walking(limbs,dist):
 for sign,leg,foot,arm in limbs:
  q=dist*math.tau/1.2+(0 if sign<0 else math.pi);leg.rotation_euler.x=.28*math.sin(q);arm.rotation_euler.x=-.3*math.sin(q);foot.location.y=.2*math.sin(q);foot.location.z=.10+max(0,math.cos(q))*.06

traffic=mode in ['traffic','attention','latency']
if traffic:
 intersection()
 # Extend the streets into a neighborhood so low cameras see a setting rather
 # than the edge of a miniature base.
 bpy.data.objects['Ground'].dimensions=(180,180,.25)
 bpy.data.objects['North south road'].dimensions=(8,180,.05)
 bpy.data.objects['East west road'].dimensions=(180,8,.05)
 for axis in [0,1]:
  for sign in [-1,1]:
   for distance in range(28,85,6):
    pos=[0,0,.025];pos[axis]=sign*distance
    dims=[.1,2.5,.015] if axis==1 else [2.5,.1,.015]
    cube('Distant lane marking',pos,dims,gold,bevel=0)
   for distance in [29,41,55,70]:
    for side in [-1,1]:
     x,y=(side*13.5,sign*distance) if axis==1 else (sign*distance,side*13.5)
     h=3.4+(distance%4)*.65
     cube('Background neighborhood',(x,y,h/2),(6,6,h),white,bevel=.10)
     cube('Building cornice',(x,y,h+.1),(6.2,6.2,.2),steel)
     for window in [-1.8,0,1.8]:
      cube('Background window',(x+window,y-3.02,2),(.9,.035,1.4),steel,bevel=.02)
 # Low buildings and planted verges add context while leaving interactions unobstructed.
 for sign in [-1,1]:
  for y in [-17,-10,10,17]:
   x=sign*13.5;h=2.2+(abs(y)%3)*.4
   cube('Neighborhood building',(x,y,h/2),(5,4,h),white,bevel=.12)
   cube('Roof',(x,y,h+.1),(5.25,4.2,.22),steel,bevel=.05)
   for n in [-1,0,1]:cube('Window',(x+n*1.15,y-2.02,1.4),(.7,.035,.8),steel,bevel=.01)
   cube('Planting bed',(sign*8.4,y,.1),(3,3,.2),grass,bevel=.2)
   cube('Tree trunk',(sign*8.4,y,1),(.18,.18,1.9),steel)
   sphere('Tree canopy',(sign*8.4,y,2.4),1.1,grass)
  for y in [-12,12]:
   cube('Streetlamp pole',(sign*5.1,y,2.4),(.12,.12,4.8),steel)
   cube('Streetlamp head',(sign*4.7,y,4.8),(1,.35,.18),white)
 ev=build_vehicle('Main blue vehicle');other=build_vehicle('Opposing vehicle',(.48,.06,.035,1))
 front_wheel=next(o for o in ev.children if o.get('vehicle_part')=='wheel' and o.location.x>0 and o.location.y>0)
 ped,limbs=person('Crossing pedestrian')
 cyclist=bpy.data.objects.new('Cyclist',None);s.collection.objects.link(cyclist)
 bike_mat=mat('Bicycle',(.82,.49,.035));wheels=[]
 for y in [-.65,.65]:
  bpy.ops.mesh.primitive_torus_add(major_radius=.32,minor_radius=.045,major_segments=24,minor_segments=8,location=(0,y,.37),rotation=(0,math.pi/2,0));o=bpy.context.object;o.parent=cyclist;o.data.materials.append(steel);wheels.append(o)
 for p,q in [((0,-.65,.37),(0,0,1)),((0,0,1),(0,.65,.37)),((0,-.65,.37),(0,.20,.42)),((0,.20,.42),(0,0,1)),((0,.20,.42),(0,.65,.37))]:
  o=line('Bicycle frame',[p,q],.035,bike_mat);o.parent=cyclist
 rider,rider_limbs=person('Rider',cyclist);rider.location=(0,-.10,.3);rider.scale=(.75,)*3;rider.rotation_euler.x=.2
 route=[]
 for i in range(121):
  p=pose(6.7+(D-.35-6.7)*i/120,D)['ev'];route.append((*p[:2],.08))
 road_route=line('Goal route',route,.06,cyan)
 label('Goal lane',Vector((-9,1.8,.4)))
 if mode=='attention':label('Cyclist remains detected',cyclist)
 if mode=='attention':
  bpy.ops.mesh.primitive_torus_add(major_radius=1.15,minor_radius=.055,major_segments=32,minor_segments=8)
  halo=bpy.context.object;halo.name='Explanatory relevance highlight';halo.data.materials.append(gold)
  # Keep road users unobstructed in low views; other street chapters retain trees.
  for obj in s.objects:
   if obj.name.startswith(('Tree canopy','Tree trunk')):obj.hide_render=True
 if shot['index']==7:
  earlier=line('Earlier candidate',[(1.8,-9.5,.13),(1.8,-7,.13),(1.8,-4.8,.13)],.075,red)
  earlier_marker=sphere('Earlier candidate marker',(1.8,-9.5,.35),.20,red)
 if mode!='latency':label('Crossing pedestrian',ped)
 if mode=='latency':
  road_route.hide_render=True
  label('45 mph = 66 ft / s',Vector((1.8,3,1.1)))
  for y in [-8.5,-2.465,11.617]:cube('Distance marker',(1.8,y,.09),(3.6,.10,.03),gold,bevel=0)
  label('0.3 s ≈ 19.8 ft',Vector((5,-4.5,1)))
 important=[ev,cyclist] if mode=='attention' else [ev]
else:
 if mode=='compute':
  board,core,parts=build_compute('Generic compute module');board.scale=(1.3,)*3;board.location=(0,-1,.3)
  important=[board]
  for i,text in enumerate(['Perception','Prediction','Planning','Memory / timing']):
   bar=cube(text,(-4.5+i*3,4,.6),(1.9,1.1,.35),steel);bars.append(bar);label(text,Vector((-4.5+i*3,4,3.4)))
   for j in range(4):tasks.append((cube(text+' workload',(-4.5+i*3,3,.6+j*.45),(1.4,.75,.27),cyan),i,j))
  important.extend(bars)
  important.extend(o for o,i,j in tasks)
 elif mode=='scores':
  for i,text in enumerate(['Physics constraints','Comfort','Intervention likelihood','Human-like behavior']):
   x=-7.5+i*5;cube('Score plinth',(x,0,0),(3.8,4,.3),steel)
   b=cube(text,(x,0,1),(2.3,2.3,2),cyan);bars.append(b);label(text,Vector((x,-2.5,.5)))
  label('Illustrative factors · no Tesla numeric scores',Vector((0,3,4)))
  important=bars
  for x in [-7.5,-2.5,2.5,7.5]:
   cube('Factor display frame',(x,1.6,3),(3.7,.16,6),steel,bevel=.08)
   cube('Factor display cap',(x,1.6,6.05),(3.9,.35,.18),white)
 elif mode=='evidence':
  doc=cube('Published application',(0,0,3.5),(7,.22,8),white,bevel=.08);important=[doc]
  label('US20260105614A1',Vector((0,-.4,6.6)));label('Published: 16 April 2026',Vector((0,-.4,5.4)))
  for z in [1.5,2.1,2.7,3.3,3.9]:cube('Document typesetting',(0,-.15,z),(5.1,.035,.06),steel,bevel=0)
  for i,text in enumerate(['Application','Product release','Vehicle eligibility']):
   o=cube(text,(-7+i*7,5,1),(4.8,2,1.7),steel);bars.append(o);label(text,Vector((-7+i*7,5,3)))
  label('Active driver supervision required',Vector((0,-3,.4)))
  important.extend(bars)
  for i,b in enumerate(bars):
   cube('Evidence folder tab',(b.location.x,4.95,2),(1.3,.4,.3),cyan if i==0 else gray)
   for row in range(3):cube('Folder spine rule',(b.location.x,3.97,.7+row*.25),(3.4,.035,.05),white,bevel=0)
 else:
  # Spatial layers are choices, not processor execution order. Branch counts are
  # exactly 3,9,27 in the explicitly simplified growth/pruning example.
  depth=3 if mode in ['growth','pruning'] else 2
  root=sphere('Goal',(0,-9,.6),.65,cyan);nodes.append((root,0,0,None));label('Driving goal',Vector((0,-10,1)))
  prior=[(root,0)]
  for level in range(1,depth+1):
   current=[];count=3**level
   for k in range(count):
    x=(k-(count-1)/2)*(20/(count-1));y=-9+level*7
    z=2.4*level
    n=sphere('Interaction choice',(x,y,z),.46 if level<3 else .27,cyan if k==count-1 else gray)
    parent=prior[k//3][0];e=line('Dependency',[tuple(parent.location),(x,y,z)],.065,cyan if k==count-1 else gray)
    nodes.append((n,level,k,e));edges.append(e);current.append((n,k))
    if level==1:
     context=bpy.data.objects.new('Candidate world',None);s.collection.objects.link(context);context.location=(x,y,1.15)
     tile=cube('Candidate road state',(0,0,-.1),(3.8,3.2,.15),steel,context)
     cube('Mini road',(0,0,.02),(1.2,3.1,.08),white,context)
     mini=build_vehicle('Candidate vehicle '+str(k));mini.parent=context;mini.location=(0,0,.1);mini.scale=(.37,)*3
     mini_context.append((context,n));tasks.append((mini,k,0));label(['Turn early','Creep','Wait'][k],context)
   prior=current
  label('3 → 9 → 27 sequences' if depth==3 else 'Goal → interactions → candidate paths',Vector((0,14 if depth==3 else 7,2)))
  important=[n for n,l,k,e in nodes]

# Hardware has a physical workbench; abstract planning views retain a clean
# technical setting. These props are generic, not a Tesla lab reconstruction.
scene_offset=Vector((0,0,0))
if mode=='compute':
 scene_offset=Vector((0,0,2.5))
 group=bpy.data.objects.new('Workbench assembly',None);s.collection.objects.link(group);group.location=scene_offset
 for obj in list(s.objects):
  if obj!=group and obj.parent is None and obj.type in ['MESH','CURVE','EMPTY'] and obj.name!='Studio ground':obj.parent=group
 cube('Workbench top',(0,1,2.23),(15,11,.34),white,bevel=.12)
 for x in [-6.4,6.4]:
  for y in [-3.6,5.6]:cube('Bench leg',(x,y,1.05),(.3,.3,2.35),steel)
 cube('Workbench backboard',(0,7,4.6),(15,.25,4.6),steel,bevel=.1)
 for x in [-5,0,5]:
  cube('Bench instrument',(x,6.7,4.3),(3,.4,1.8),white)
  cube('Instrument face',(x,6.45,4.3),(2.6,.06,1.35),dark)

def descendants(root):return [o for o in root.children_recursive if o.type=='MESH'] if root.type=='EMPTY' else [root]
poses={};lens_scale={0:1.,1:1.,2:1.,3:1.}
def apply(f):
 global important
 u=f/max(1,NF-1);t=f/30;beat=min(3,int(u*4));q=u*4-beat
 if traffic:
  p=pose(t,D)
  ev.location=(*p['ev'][:2],.015);ev.rotation_euler.z=p['ev'][2]
  if t<6.7:ev.location.y=-9.8+1.3*smooth(t/6.7)
  other.location=(*p['other'][:2],.015);other.rotation_euler.z=math.pi;visible(other,p['other'][1]>=-22)
  travel=p['ev_distance']+1.3 if t>=6.7 else 1.3*smooth(t/6.7)
  for vehicle,distance in [(ev,travel),(other,4*t)]:
   for wheel in vehicle.children:
    if wheel.get('vehicle_part')=='wheel':wheel.rotation_euler.x=-distance/.34;wheel.rotation_euler.z=p['steer'] if vehicle==ev and wheel.location.y>0 else 0
  ped_z=-.05+.045*smooth((4.8-abs(p['pedestrian'][0]))/.8)
  ped.location=(*p['pedestrian'][:2],ped_z);ped.rotation_euler.z=math.pi/2;walking(limbs,p['walk_distance'])
  cycle_y=-7+u*14;cycle_z=-.03+.05*smooth((6-abs(cycle_y))/2)
  cyclist.location=(6.5,cycle_y,cycle_z)
  for wheel in wheels:wheel.rotation_mode='QUATERNION';wheel.rotation_quaternion=Quaternion((0,1,0),math.pi/2)@Quaternion((0,0,1),-u*14/.32)
  if mode=='attention':halo.location=cyclist.location+Vector((0,0,.05))
  if shot['index']==7:
   grow=smooth(u/.15)*(1-smooth((u-.4)/.12));earlier.data.bevel_factor_end=grow
   earlier_marker.location=(1.8,-9.5+4.7*min(1,u/.3),.35);earlier_marker.scale=(max(.0001,grow),)*3
  if mode=='latency':
   # A measured 0.3-second distance appears as annotated geometry. The full chapter
   # uses a slower illustrative demonstration, never labels its playback real time.
   ev.location=(1.8,-8.5+20.1168*u,.015);ev.rotation_euler.z=0
   for wheel in ev.children:
    if wheel.get('vehicle_part')=='wheel':wheel.rotation_euler.x=-20.1168*u/.34;wheel.rotation_euler.z=0
   visible(other,False);visible(ped,False);visible(cyclist,False)
  else:
   actual=(ev.location.x,ev.location.y,ev.rotation_euler.z)
   assert not rectangles_overlap(actual,p['other'])
   assert circle_clearance(actual,p['pedestrian'],.38)>.1
  x,y=ev.location[:2]
  forward=Vector((-math.sin(ev.rotation_euler.z),math.cos(ev.rotation_euler.z),0))
  right=Vector((math.cos(ev.rotation_euler.z),math.sin(ev.rotation_euler.z),0))
  important=[ev]
  offsets=[(5,9,2.1),(22,-13,25),(6,-8,2.6),(5,-9,2.0)]
  cam.location=Vector((x,y,0))+Vector(offsets[beat])+Vector((-q,q,.3*q));target=Vector((x,y,.65))
  if beat==1:cam.location=(20-q,-14+q,27);target=Vector((0,-1,0))
  if mode=='attention':
   important=[ev,cyclist];target=(ev.location+cyclist.location)*.5+Vector((0,0,.7))
   if beat==1:cam.location=target+Vector((20-q,-23,26))
   else:cam.location=Vector(([-1,0,1.5,0][beat],target.y-24,target.z+[2.4,0,3.5,2.4][beat]))
  elif beat>=2:
   cam.location=ev.location-forward*(7+q)+right*4+Vector((0,0,2.3));target=ev.location+forward+Vector((0,0,.75))
   if shot['index']==7 and beat==2:
    wheel_pos=ev.location+right*.91+forward*1.42+Vector((0,0,.34))
    cam.location=wheel_pos+right*2.3-forward*.4+Vector((0,0,.5));target=wheel_pos;important=[front_wheel]
  lens=43
 else:
  if mode=='compute':
   core.location.z=.8+.45*math.sin(u*math.pi);target=Vector((0,1,1))
   for o,i,j in tasks:o.location.y=3.6+((u*5+j*.23)%1)*1.7;o.location.z=.7+j*.43
  elif mode=='scores':
   for i,b in enumerate(bars):
    h=1.2+1.3*(.5+.5*math.sin(u*math.tau+i));b.scale.z=h;b.location.z=h
   target=Vector((0,0,2))
  elif mode=='evidence':
   doc.rotation_euler.z=.08*math.sin(u*math.pi);target=Vector((0,0,3))
   for i,b in enumerate(bars):b.location.z=1+.16*math.sin(u*math.tau+i)
  else:
   for n,level,k,e in nodes:
    grow=1 if level<=1 or mode=='pruning' else smooth((u-(level-2)*.2)/.25)
    keep=1
    if mode=='pruning' and level and k!=3**level-1:keep=1-smooth((u-.32-level*.025)/.18)
    n.scale=(max(.0001,grow*keep),)*3
    if e:e.data.bevel_factor_end=grow*keep
   for context,n in mini_context:context.scale=tuple(n.scale)
   for o,k,j in tasks:o.location.y=.45*math.sin(u*math.tau+k)
   target=Vector((0,1.8 if mode in ['growth','pruning'] else -1,3.8))
  target+=scene_offset
  offsets=[(19,-32,6),(-17,-28,8),(6,-30,4),(15,-28,9)]
  if mode=='compute':offsets=[(10,-15,6),(-11,-14,5),(7,-13,4),(9,-15,7)]
  elif mode=='scores':offsets=[(4,-29,4),(-7,-28,5),(6,-27,3),(-4,-30,4)]
  elif mode=='evidence':offsets=[(4,-26,3),(-6,-27,4),(7,-28,2),(3,-26,5)]
  cam.location=target+Vector(offsets[beat])+Vector((q,-q,.2*q));lens=40 if mode not in ['growth','pruning'] else 35
 cam.data.lens=lens*lens_scale[beat];aim(cam,target);bpy.context.view_layer.update()
 ratio=1.
 for obj in important:
  if max(obj.scale)<.03:continue
  if obj.type=='EMPTY':
   # Conservative rig envelopes keep every wheel/mirror or lifted processor
   # inside the check without projecting hundreds of child vertices per frame.
   sx,sy,sz=(4,2.8,3) if mode=='compute' else (1.15,2.4,1.8)
   low=0
   if obj.get('vehicle_part')=='wheel':sx,sy,sz=.2,.38,.38;low=-.38
   corners=[(x,y,z) for x in [-sx,sx] for y in [-sy,sy] for z in [low,sz]]
  else:corners=obj.bound_box
  for corner in corners:
   p=world_to_camera_view(s,cam,obj.matrix_world@Vector(corner));assert p.z>0
   ratio=min(ratio,.45/max(abs(p.x-.5),1e-9),.42/max(abs(p.y-.5),1e-9))
 projected=[]
 for text,obj in labels:
  if isinstance(obj,Vector):pos=obj+scene_offset
  else:
   if max(obj.scale)<.03 or obj.hide_render:continue
   pos=obj.matrix_world.translation+Vector((0,0,1.7))
  v=world_to_camera_view(s,cam,pos)
  if v.z>0:projected.append([text,v.x,1-v.y])
 poses[f]={'beat':beat,'focal_ratio':ratio,'labels':projected}
 return ratio

for attempt in range(3):
 for f in range(NF):apply(f)
 bad=[p for p in poses.values() if p['focal_ratio']<.999]
 if not bad:break
 for beat in lens_scale:
  ratio=min(p['focal_ratio'] for p in poses.values() if p['beat']==beat)
  if ratio<1:lens_scale[beat]*=ratio*.97
assert not bad,'Framing preflight failed'
write(folder/'poses.json',poses);write(folder/'scene-qa.json',{'passed':True,'frames':NF,'all_frame_primary_bounds':True,'lens_scale':lens_scale,'mode':mode,'accuracy':'Schematic; rankings, timing, score animation and compute loads are illustrative, not product measurements.'})
raw=folder/'raw';raw.mkdir(exist_ok=True)
engine=ROOT.parents[1]
deps=[Path(__file__),ROOT/'plan.json',*engine.glob('*.py'),*engine.glob('bibles/*.md')]
stamp={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in deps};stamp['voice']=shot['voice_sha256'];stamp['shot']=hashlib.sha256(str(shot).encode()).hexdigest()
stamp['render_config']={key:m[key] for key in ['width','height','fps','render_samples']}
if any(raw.glob('*.png')):assert read(folder/'render-source.json')==stamp,'Source changed; do not mix frame versions'
write(folder/'render-source.json',stamp)
frames=[0,NF//4,NF//2,3*NF//4,NF-1] if args.stills else range(NF)
for f in frames:
 path=raw/f'{f:06d}.png'
 if path.exists():continue
 apply(f);s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
print('CHAPTER READY',shot['id'],'diagnostics' if args.stills else 'all frames',flush=True)
