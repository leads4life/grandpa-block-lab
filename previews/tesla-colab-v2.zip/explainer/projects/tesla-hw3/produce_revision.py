"""Resume checked v2 native frames, assemble media, leave final inspection explicit."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,os,subprocess,sys,time
from PIL import Image,ImageDraw,ImageFont
from explainer.core import read,write
from explainer.media import mix_mechanical,check_video,assemble
from explainer.retention import require,content_hash

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v2'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_files():
    engine=ROOT.parents[1]
    return [*sorted(ROOT.glob('*revision*.py')),ROOT/'rich_scene.py',
            engine/'colab/runtime.py',*sorted(engine.glob('*.py')),*sorted((engine/'bibles').glob('*.md'))]


def verify_preflight():
    plan=read(OUT/'plan.json');require(plan,review=True)
    auth=read(OUT/'authorization.json');assert auth['user_full_production_authorized']
    assert auth['user_evidence']=="yes closer do a once more audit add more where you can and go to production'"
    review=read(OUT/'preflight-review.json');assert review['passed']
    assert review['plan_sha256']==sha(OUT/'plan.json') and review['manifest_sha256']==sha(OUT/'manifest.json')
    repo=ROOT.parents[2]
    for name,expected in review['source_hashes'].items():assert sha(repo/name)==expected,('Changed reviewed source',name)
    for shot in plan['shots']:
        folder=OUT/shot['id'];assert sha(folder/'voice.wav')==shot['voice_sha256']
        assert read(folder/'scene-qa.json')['passed']
    return plan


def decorate(im,p,mode):
    im=im.convert('RGB').resize((960,540),Image.Resampling.LANCZOS);d=ImageDraw.Draw(im)
    bold=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',21)
    regular=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
    small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
    occupied=[]
    for i,text in enumerate(p['badges']):
        text={'Physics constraints':'Physics: collision / feasibility checks',
              'Comfort':'Comfort: how abrupt the motion feels',
              'Intervention likelihood':'Intervention: likelihood of human takeover',
              'Human-like behavior':'Human-like: would a driver choose this?'}.get(text,text)
        font=bold
        if d.textlength(text,font=font)>900:font=regular
        width=d.textlength(text,font=font)+24;y=18+i*38
        d.rounded_rectangle((18,y,18+width,y+31),radius=7,fill='#0a2432',outline='#48ceef')
        d.text((30,y+15),text,font=font,fill='#e1faff',anchor='lm');occupied.append((14,y-3,22+width,y+35))
    job=p['camera_job'];names=set()
    if mode=='hardware':names={'Perception','Prediction','Planning','Memory / timing','Application','Release evidence'}
    elif mode=='comparison':names={'Abrupt speed change','Gradual speed change'}
    elif 'future' in job or 'connected_interactions' in job or 'candidate' in job:names={'Turn candidate','Creep candidate','Wait candidate'}
    elif 'goal' in job or job=='resolved_turn':names={'Goal lane'}
    elif 'cyclist' in job or 'road_user' in job or job=='retrieval_answer':names={'Cyclist stays represented','Pedestrian'}
    for text,x,y in p['labels']:
        if text not in names:continue
        px,py=x*960,y*540;w=d.textlength(text,font=regular)+14
        lx=max(8,min(952-w,px-w/2));ly=max(112,min(478,py-34));box=(lx,ly,lx+w,ly+24)
        if any(box[0]<b[2]+4 and box[2]>b[0]-4 and box[1]<b[3]+4 and box[3]>b[1]-4 for b in occupied):continue
        d.line((px,py,max(box[0],min(box[2],px)),box[3]),fill='#6ec4da',width=1)
        d.rounded_rectangle(box,radius=4,fill='#0b202c');d.text((lx+7,ly+12),text,font=regular,fill='#e3f4fa',anchor='lm');occupied.append(box)
    qualifier='Original schematic 3D · illustrative motion / search · not Tesla measurements'
    d.rectangle((0,512,960,540),fill='#091620');d.text((14,526),qualifier,font=small,fill='#c3d5df',anchor='lm')
    return im


def encode(shot):
    folder=OUT/shot['id'];video=folder/'chapter.mp4';cfg={'producer_sha256':sha(__file__),'render_source_sha256':sha(folder/'render-source.json'),'voice_sha256':shot['voice_sha256']}
    if (folder/'qa.json').exists() and video.exists():
        prior=read(folder/'qa.json')
        if prior['passed'] and prior['encode_config']==cfg and prior['video_sha256']==sha(video):return video
    assert {x.name for x in (folder/'raw').glob('*.png')}=={f'{f:06d}.png' for f in range(shot['frames'])}
    cues=[]
    if shot['mode']=='decision':
        start=next(g['start'] for g in shot['thought_groups'] if 'A pedestrian' in g['text'])
        cues=[{'kind':'motor','at':start,'duration':6.,'purpose':'Quiet synthetic roll linked to opposing traffic; not an authentic vehicle recording.'}]
    elif shot['mode']=='resolve':cues=[{'kind':'motor','at':6.7,'duration':shot['seconds']-7,'purpose':'Quiet illustrative rolling cue tied to the completed turn.'}]
    audio=mix_mechanical({'id':shot['id'],'sfx':cues},folder/'voice.wav',folder/'mix.wav',shot['seconds'])
    poses=read(folder/'poses.json');gain=1.
    for attempt in range(4):
        command=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-framerate','30','-i','pipe:0','-i',str(audio),'-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:level=false:latency=1,apad','-t',str(shot['seconds']),'-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-movflags','+faststart',str(video)]
        log=folder/f'encode-{attempt}.log'
        with log.open('wb') as err:
            process=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=err)
            try:
                for f in range(shot['frames']):
                    with Image.open(folder/'raw'/f'{f:06d}.png') as src:im=decorate(src,poses[str(f)],shot['mode'])
                    process.stdin.write(im.tobytes())
                process.stdin.close();assert process.wait()==0,log.read_text()
            except BaseException:
                process.kill();process.wait();raise
        qa=check_video(video,shot['seconds'],960,540)
        if qa['passed']:break
        gain+=-14-qa['lufs']
    assert qa['passed'],qa
    qa.update(review='pending_decoded_sequence_inspection',encode_config=cfg,video_sha256=sha(video),native_width=768,native_height=432,native_fps=30,scene=read(folder/'scene-qa.json'))
    write(folder/'qa.json',qa)
    return video


def review_sheets(shot):
    folder=OUT/shot['id'];review=folder/'decoded-review';review.mkdir(exist_ok=True)
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(folder/'chapter.mp4'),'-vf',"select='not(mod(n,60))',scale=480:270",'-fps_mode','vfr','-start_number','0',str(review/'%04d.jpg')],check=True)
    images=sorted(review.glob('*.jpg'));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
    for start in range(0,len(images),12):
        selected=images[start:start+12];sheet=Image.new('RGB',(1440,300*math_ceil_div(len(selected),3)),'#081420');d=ImageDraw.Draw(sheet)
        for i,path in enumerate(selected):
            x=i%3*480;y=i//3*300
            with Image.open(path) as im:sheet.paste(im,(x,y))
            d.text((x+8,y+278),f"{shot['id']} · {(start+i)*2:.1f}s",font=font,fill='white')
        sheet.save(folder/f'review-{start//12:02d}.jpg',quality=92)


def math_ceil_div(a,b):return (a+b-1)//b


def run():
    verify_preflight();manifest=read(OUT/'manifest.json');videos=[]
    try:
        for shot in manifest['shots']:
            folder=OUT/shot['id'];ready=False
            if (folder/'qa.json').exists() and (folder/'chapter.mp4').exists() and (folder/'render-source.json').exists():
                prior=read(folder/'qa.json')
                expected={'producer_sha256':sha(__file__),'render_source_sha256':sha(folder/'render-source.json'),'voice_sha256':shot['voice_sha256']}
                ready=prior.get('passed') and prior.get('encode_config')==expected and prior.get('video_sha256')==sha(folder/'chapter.mp4')
            if ready:
                videos.append(folder/'chapter.mp4');print('REUSE CHECKED V2 CLIP',shot['id'],flush=True);continue
            write(OUT/'pipeline-state.json',{'stage':'rendering','chapter':shot['index']+1,'chapter_id':shot['id'],'title':shot['title'],'total_chapters':8,'frames':shot['frames'],'started_utc':datetime.now(timezone.utc).isoformat(),'full_production_authorized':True})
            adapter='explainer.projects.tesla-hw3.revision_colab' if os.environ.get('EXPLAINER_V2_COLAB')=='1' else 'explainer.projects.tesla-hw3.render_revision'
            arguments=['render','--index',str(shot['index'])] if os.environ.get('EXPLAINER_V2_COLAB')=='1' else ['--index',str(shot['index'])]
            subprocess.run([sys.executable,'-m',adapter,*arguments],check=True)
            write(OUT/'pipeline-state.json',{'stage':'encoding','chapter':shot['index']+1,'chapter_id':shot['id'],'total_chapters':8})
            videos.append(encode(shot));review_sheets(shot)
        video=OUT/'tesla-planning-v2.mp4';assemble(videos,[x['seconds'] for x in manifest['shots']],video)
        qa=check_video(video,manifest['seconds'],960,540);assert qa['passed'],qa
        qa.update(review='pending_complete_decoded_sequence_inspection',video_sha256=sha(video),chapters=8,retention=read(OUT/'retention-check.json'),native_width=768,native_height=432,native_fps=30)
        write(OUT/'final-qa.json',qa);write(OUT/'pipeline-state.json',{'stage':'awaiting_final_inspection','movie':video.name,'seconds':manifest['seconds'],'final_review':'pending','youtube_uploaded':False})
        print('V2 COMPLETE MEDIA; ACTUAL FINAL INSPECTION STILL REQUIRED',flush=True)
    except BaseException as e:
        write(OUT/'pipeline-error.json',{'type':type(e).__name__,'message':str(e),'utc':datetime.now(timezone.utc).isoformat()});raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');parser.add_argument('--encode-index',type=int);args=parser.parse_args()
    if args.run:run()
    elif args.encode_index is not None:encode(read(OUT/'manifest.json')['shots'][args.encode_index])
