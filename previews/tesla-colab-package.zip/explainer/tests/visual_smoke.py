"""Actual Blender checks for themes, watertight cuts, flow and moving callout tracking."""
from copy import deepcopy
from pathlib import Path
import bpy
import bmesh
from mathutils import Vector
from explainer.core import read, validate, write, fingerprint
from explainer.blender_backend import render
from explainer.__main__ import contact_sheet


def main():
    plan = read(Path(__file__).parents[1] / 'examples/toolkit-fixture.json')
    assert not validate(plan)
    root = Path(__file__).parents[1].resolve() / 'build/visual-selftest'
    output = root / fingerprint(plan, root)[:16]
    results = {}
    for theme in ['light', 'dark']:
        shot = deepcopy(plan['shots'][0])
        shot['presentation'] = {'background': theme, 'reason': 'Internal contrast and geometry test'}
        out = output / theme
        render(shot, out, 640, 360, 30, 3, samples=8)
        housing = bpy.data.objects['housing']
        mesh = bmesh.new()
        try:
            mesh.from_mesh(housing.data)
            assert all(e.is_manifold for e in mesh.edges), 'Cut must be watertight'
            assert min(v.co.y for v in mesh.verts) >= -1e-5, 'Removed half remains'
            # No cap should span the hollow center of the longitudinally sectioned tube.
            assert not any(abs(f.calc_center_median().x)<.1 and abs(f.calc_center_median().y)<.1
                           and abs(f.calc_center_median().z)<.1 for f in mesh.faces), 'Bore was incorrectly filled'
            assert abs(housing.scale.x-2)<1e-5, 'A half housing must retain its original scale'
        finally:
            mesh.free()
        leader = bpy.data.objects['Leader_Moving core']
        core = bpy.data.objects['core']
        marker = bpy.data.objects['flow_test_packet']
        positions = []
        for frame in range(3):
            bpy.context.scene.frame_set(frame)
            target = Vector(leader.data.splines[0].points[1].co[:3])
            assert (target-core.matrix_world.translation).length < 1e-5, 'Leader slipped from component'
            positions.append(tuple(marker.location))
        assert positions[0] != positions[-1]
        assert (Vector(positions[0])-Vector(shot['flows'][0]['path'][0])).length < 1e-5
        assert (Vector(positions[-1])-Vector(shot['flows'][0]['path'][-1])).length < 1e-5
        contact_sheet(out / 'frames', out / 'contact-sheet.png')
        results[theme] = {'passed': True, 'frames': 3, 'directory': str(out)}
    write(output / 'results.json', results)
    print('VISUAL TOOLKIT SMOKE PASSED:', output)


if __name__ == '__main__': main()
