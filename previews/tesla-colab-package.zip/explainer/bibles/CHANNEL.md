# Technical explainer channel bible

## Confirmed direction
- Full-length widescreen YouTube videos. Length follows the subject; no arbitrary runtime ceiling.
- Technical subjects: show how something works, for curious beginners AND knowledgeable viewers.
- Backgrounds are selected by Codex for the subject and shot: use light or dark according to explanatory clarity, with consistent meaning and readable graphics. The user delegated this choice.
- Combine realistic subject models with simplified technical views. Every simplification must preserve the explanation's causal truth.
- Narrator only. No Grandpa, presenter, or livestream framing in the explainer output.
- Narration with restrained mechanical sound effects; no music. Cues must explain a visible action, not decorate every transition.
- No burned-in narration captions. YouTube handles captions. Technical labels, dimensions, graphs and legends remain useful visual tools.
- Imported assets must cost nothing to obtain and permit commercial use and modification for monetized videos. Prefer CC0/public domain; CC BY is acceptable with practical attribution. Exclude noncommercial, no-derivatives and editorial-only assets.
- For now use continuously animated 3D explanation, as in the accepted piston test. Static-image sections and held-render presentations are parked at the user’s request. Technical labels may support moving scenes.
- ChatGPT Image support remains available for a later direction change, but do not use static-image sections in the current Tesla film. It is not the source of technical truth. Do not assume its ability to create accurate mechanical geometry or animations.
- Codex completes missing research, scripts, assets, shot design and production work. Ask about creative direction/options one question at a time; resolve routine architectural and implementation decisions independently.
- User approves the storyboard and a representative short preview before full production.
- Before presenting a preview, Codex inspects the actual output, repairs obvious problems and checks again. A successful render is insufficient.

## Editorial identity
Lead with a concrete question, show the mechanism, build a causal explanation, show limits and finish with a useful takeaway. Explain unfamiliar terms at first use. Offer precise details once the physical intuition is clear. Avoid false drama, unsupported numbers, guaranteed outcomes, or imitation of a reference channel's branding.

The channel name, branding and recurring creative treatments are undecided. Ask before choosing them. Default implementation colors and test objects are engineering fixtures, not locked branding.
