"""Compact technical labels with bounded collision repair and visible associations."""
from pathlib import Path
from PIL import ImageDraw,ImageFont

def decorate(im,pose):
    d=ImageDraw.Draw(im);boxes=[]
    path=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    font=ImageFont.truetype(str(path),17)
    for text,x,y in pose['labels']:
        if not (.04<x<.96 and .09<y<.88):continue
        cx,anchor=x*960,y*540;width=d.textlength(text,font=font)+16
        for dy in [0,-30,30,-60,60,-90,90]:
            cy=anchor+dy;box=(cx-width/2,cy-12,cx+width/2,cy+13)
            if box[0]<8 or box[2]>952 or box[1]<8 or box[3]>505:continue
            if any(box[0]<b[2]+4 and box[2]>b[0]-4 and box[1]<b[3]+4 and box[3]>b[1]-4 for b in boxes):continue
            if dy:d.line([(cx,anchor),(cx,cy)],fill='#b3d6e4',width=1)
            d.rounded_rectangle(box,radius=4,fill='#10212e')
            d.text((cx,cy),text,font=font,fill='#e1f4fb',anchor='mm');boxes.append(box)
            break
    d.text((16,521),'Schematic explanation · illustrative choices and timing',font=ImageFont.truetype(str(path),12),fill='#cedbe4',stroke_width=1,stroke_fill='#0a1824')
    return im
