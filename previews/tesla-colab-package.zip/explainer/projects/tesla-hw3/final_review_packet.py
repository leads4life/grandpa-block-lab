"""Prepare whole-film inspection artifacts after encoding; never grants review approval."""
from pathlib import Path
import subprocess
from PIL import Image,ImageDraw,ImageFont
from explainer.core import read,write

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v1'
def main():
    m=read(OUT/'manifest.json');qa=read(OUT/'final-qa.json');assert qa['passed']
    movie=OUT/'tesla-planning-complete.mp4'
    frames=OUT/'final-inspection/frames';frames.mkdir(parents=True,exist_ok=True)
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(movie),'-vf','fps=1,scale=480:270',str(frames/'%04d.jpg')],check=True)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
    files=sorted(frames.glob('*.jpg'));sheets=[]
    for start in range(0,len(files),12):
        sheet=Image.new('RGB',(1440,1120),'#0b1925');d=ImageDraw.Draw(sheet)
        for j,p in enumerate(files[start:start+12]):
            x=(j%3)*480;y=(j//3)*280
            with Image.open(p) as im:sheet.paste(im,(x,y))
            d.text((x+5,y+265),f'{start+j:03d} seconds',font=font,fill='white')
        path=OUT/'final-inspection'/f'sequence-{start:04d}.jpg';sheet.save(path,quality=94);sheets.append(str(path))
    chapters=[];time=0
    for shot in m['shots']:
        seconds=round(time);chapters.append(f'{seconds//60:02d}:{seconds%60:02d} {shot["title"]}');time+=shot['seconds']
    description='''Inside Tesla’s planning patent application: how a search can organize possible interactions, score choices and stop expanding poor branches.

Original moving 3D models illustrate the method. The scenes, scores, timing and compute loads are schematic examples, not a reconstruction or benchmark of Tesla’s software. This application does not establish HW3/V14 feature parity or an 80% measured saving. Tesla describes FSD (Supervised) as requiring active driver supervision.

Sources:
https://patents.google.com/patent/US20260105614A1/en
https://www.tesla.com/support/fsd

Chapters:
'''+ '\n'.join(chapters)+'\n\nCredits: original procedural geometry; Kokoro am_fenrir narration; DejaVu Sans graphics font. No music.\n'
    (OUT/'video-description.md').write_text(description)
    write(OUT/'final-inspection/packet.json',{'status':'awaiting_actual_final_inspection','video':str(movie),'sheets':sheets,'media_qa':qa,'automatic_publication':False})
    print('WHOLE-FILM INSPECTION PACKET READY; REVIEW STILL PENDING',movie,flush=True)

if __name__=='__main__':main()
