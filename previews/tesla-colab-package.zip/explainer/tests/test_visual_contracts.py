from copy import deepcopy
from pathlib import Path
import unittest
from explainer.core import read, storyboard, validate
from explainer.presentation import resolve_theme, THEMES


class VisualContracts(unittest.TestCase):
    def setUp(self):
        self.plan = read(Path(__file__).parents[1] / 'examples/toolkit-fixture.json')
        self.shot = self.plan['shots'][0]

    def test_toolkit_contract_passes(self):
        self.assertEqual(validate(self.plan), [])

    def test_auto_selects_by_shot_and_explicit_overrides_work(self):
        self.assertEqual(resolve_theme(self.shot)[0], 'light')
        self.shot['accuracy'] = 'literal'
        self.assertEqual(resolve_theme(self.shot)[0], 'dark')
        self.shot['presentation'] = {'background': 'light', 'reason': 'Small dark components need contrast'}
        self.assertEqual(resolve_theme(self.shot)[0], 'light')
        self.assertEqual(validate(self.plan), [])

    def test_unexplained_override_is_rejected(self):
        self.shot['presentation'] = {'background': 'dark'}
        self.assertTrue(any('explain the explicit' in x for x in validate(self.plan)))

    def test_unknown_theme_is_rejected(self):
        self.shot['presentation'] = {'background': 'pink'}
        self.assertTrue(any('background must' in x for x in validate(self.plan)))
        with self.assertRaises(ValueError): resolve_theme(self.shot)

    def test_label_ink_has_contrast_on_both_backgrounds(self):
        # Linear-light luminance is a policy check; actual rendered images need separate inspection.
        def luminance(rgb): return sum(a*b for a,b in zip(rgb[:3], (.2126,.7152,.0722)))
        for theme in THEMES.values():
            values = sorted([luminance(theme['background']), luminance(theme['ink'])])
            self.assertGreater((values[1]+.05)/(values[0]+.05), 7)

    def test_resolved_theme_is_visible_in_storyboard(self):
        self.assertIn('[background: light]', storyboard(self.plan))

    def test_invalid_section_and_wall_are_rejected(self):
        housing = self.shot['components'][0]
        housing['wall'] = .5
        housing['section']['axis'] = 'z'
        errors = validate(self.plan)
        self.assertTrue(any('tube wall' in x for x in errors))
        self.assertTrue(any('preserve the bore' in x for x in errors))
        housing['section'] = {'axis': 'y', 'offset': 1, 'keep': 'none'}
        self.assertTrue(any('invalid local section' in x for x in validate(self.plan)))

    def test_unknown_callout_target_is_rejected(self):
        self.shot['labels'][0]['target'] = 'imaginary'
        self.assertTrue(any('unknown component' in x for x in validate(self.plan)))

    def test_zero_length_or_unexplained_flow_is_rejected(self):
        cue = self.shot['flows'][0]
        cue['path'] = [[0,0,0], [0,0,0]]
        self.assertTrue(any('distinct' in x for x in validate(self.plan)))
        cue.pop('explains')
        self.assertTrue(any('unexplained flow' in x for x in validate(self.plan)))

    def test_image_overlays_cannot_be_silently_dropped(self):
        self.shot['visual_type'] = 'image'
        self.assertTrue(any('silently ignore' in x for x in validate(self.plan)))
