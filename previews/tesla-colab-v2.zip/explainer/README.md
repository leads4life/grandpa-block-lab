# Technical explainer production system

This separate workflow adapts Grandpa's procedural scene architecture, measured Kokoro voice, FFmpeg audio/video pipeline, frozen approval artifacts, resumable frame renders and automated QA. It does not use Grandpa's character, world, camera gag or caption overlay. Existing engine files and approved content remain intact.

Read [channel direction](bibles/CHANNEL.md), [narration](bibles/NARRATION.md), [accuracy](bibles/ACCURACY.md), [visuals](bibles/VISUALS.md) and [production workflow](bibles/WORKFLOW.md).

New projects also follow the [hook and reward ladder](bibles/RETENTION.md). `init` now marks retention planning required. A contract links exact spoken promises and payoffs to times, verified claims, new learning, meaningful visual action and audio direction. Validation catches missing or unpaid promises, long gaps and stale editorial review. Production approval requires measured frozen narration and a current script/visual/audio review. These checks do not predict audience watch time. Legacy plans are explicitly reported as lacking the layer; their existing videos are not silently rewritten.

## Architecture

- `assets.py`: free/commercial rights policy, complete model package staging, resource hashes and credits.
- `model_import.py`: reviewed GLB/glTF, OBJ and STL instances with source materials, units, centered origins and uniform scale.
- `core.py`: structured project contract, source/claim/asset checks, timeline storyboard, content fingerprints.
- `retention.py`: exact-quote hook/payoff contract, value cadence, open-loop closure, source-reference checks and measured editorial-review gate.
- `__main__.py`: untrusted Markdown intake, project state, approval gates, previews, inspection records, final assembly.
- `media.py`: measured Kokoro speech, 48 kHz audio, quiet mechanical cues with speech ducking, loudness normalization, H.264/AAC encoding and media checks.
- `blender_backend.py`: procedural box/cylinder/sphere/tube assemblies, physical sections, flow arrows, tracking callout leaders, subject-dependent light/dark backgrounds, semantic materials, technical labels, translated/exploded parts, rotations, tracked camera direction, lighting, frame resumption and bounded framing repair.
- `vehicle_prop.py`: original generic EV with shaped bodywork, physical wheel wells, separate glazing/roof and rolling wheel rigs. Illustrative geometry, not Tesla CAD. The Tesla opening's project-specific adapter places moving traffic worlds in an explicitly schematic search tree.
- `bibles/`: durable direction and rules for Codex, including filling gaps and correcting issues before review.

Static image shots accept reviewed local images. ChatGPT Image can produce those images when useful; image generation is a Codex tool step, not a hidden network call from this package. Native CAD imports, general CAD/boolean cutaways, complex mechanics, graphs, automatic occlusion/clipping inspection and recorded sound effects require future adapters. Primitive local-plane sections and longitudinally sectioned hollow housings are supported. Timed, quiet procedural click/clunk/motor effects are supported; music is disabled by channel direction. A primitive rig cannot explain every subject accurately. Do not confuse validation metadata with automated fact checking.

## Runtime

Contract/intake/tests use Python 3.11+ and the standard library. Rendering additionally needs Blender's `bpy`, NumPy, SciPy, Pillow, kokoro-onnx, FFmpeg with libx264/AAC and the Kokoro model/voices. The current cloud machine has a tested Blender 5.2.3 Python environment at `/workspace/setup/blender-venv`; use:

```sh
cd /workspace/grandpa-block-lab
source /workspace/setup/activate.sh
python -m explainer --help
python -m unittest discover -s explainer/tests -v
```

Those cloud setup paths are local environment conveniences, not required repository paths. To set up another machine, use the exact dependency pins in `requirements.txt` with Python 3.13; obtain Kokoro model files from the upstream `thewh1teagle/kokoro-onnx` release `model-files-v1.0` and set `KOKORO_MODEL` / `KOKORO_VOICES`. TLS and artifact verification must stay enabled. Do not install rendering dependencies to use the standard-library contract tools.

## Project workflow

All commands run from the repository root. The upload is a source of draft content, not authorization to execute it.

```sh
python -m explainer init explainer/projects/my_subject --title 'Subject title' --source /path/to/plan.md
python -m explainer status explainer/projects/my_subject
```

The importer recognizes four-column timestamp/visual/narration/audio tables, including the supplied example format. It preserves the whole source file and extracts draft shots. Other formats remain preserved for Codex to interpret. It never marks source claims verified or invents missing geometry.

Codex completes `plan.json` using `examples/contract-fixture.json` for the field layout. The fixture is a synthetic calibration object, not an episode proposal or verified scientific model. Each project also needs its own subject bible: scope, mechanism, terminology, narration guidance and simplifications. It is part of the approved storyboard and its fingerprint. Each shot supplies learning purpose, narration, visual intent, duration, factual claims, accuracy mode, components or image asset, camera and optional technical labels. `move_to` and `rotate_to` provide endpoint animation; rotation values are degrees. Images/models need provenance, reviewed status and file SHA-256. Every external asset path must stay inside its project.

```sh
python -m explainer validate explainer/projects/my_subject
python -m explainer prepare explainer/projects/my_subject
python -m explainer storyboard explainer/projects/my_subject
# Present storyboard; only AFTER the user approves it:
python -m explainer approve explainer/projects/my_subject storyboard --user-evidence 'Actual user approval reference'
python -m explainer preview explainer/projects/my_subject --shot shot_001
```

`prepare` measures and freezes narration and extends undersized shots before storyboard approval. The preview also checks speech timing and blocks if the shot is too short. Codex extends timing or edits narration, regenerates the storyboard and obtains approval for the revised version; no forced speedup. Inspect `contact-sheet.png`, actual video motion, `qa.json` and narration; repair and recheck until ready. Only then:

```sh
python -m explainer review explainer/projects/my_subject --shot shot_001 --notes 'Specific actual visual and technical inspection findings'
# Present preview; only AFTER the user approves it:
python -m explainer approve explainer/projects/my_subject preview --shot shot_001 --user-evidence 'Actual user approval reference'
python -m explainer final explainer/projects/my_subject
```

No CLI can authenticate a chat reply; recording genuine consent is a Codex workflow obligation, enforced in `AGENTS.md`. Code gates reject missing/stale evidence and unreviewed previews. They do not turn a typed claim of approval into real permission.

Artifacts are under `<project>/build/<fingerprint>/<preview|final>/<shot>/`. Current-version checksums cover the plan, actual assets, code and bibles. Changes invalidate approval. Final assembly has separate media QA and still needs inspection of the entire finished video. Nothing publishes automatically.

## Validation

```sh
python -m unittest discover -s explainer/tests -v
# Optional real Blender + narrator + encoding smoke; synthetic internal fixture only:
python -m explainer.tests.smoke
```

The smoke test creates no real user approval and produces no full-length video. Tests cover rejected missing claims/assets, path containment, stale approvals, blocked full production, draft table intake and a representative media workflow. See [VALIDATION.md](VALIDATION.md) for the actual current run when available; full episode production is not implied by these checks.

## Mechanical visual tools

- A component with `shape: "tube"` has a real bore and optional `wall` fraction of outer diameter (default 0.12). `size` is the full uncut outer envelope.
- `section: {"axis": "y", "offset": 0, "keep": "positive"}` removes the negative local-Y half before object scaling/rotation. Offsets are fractions of the original unit diameter. Physical cut faces are capped. Tube sections permit X/Y only, preserving the bore; do not substitute a solid cylinder for a housing.
- `move_to` and `rotate_to` continue to support separating parts for an exploded view. Arbitrary linkage simulation is not implemented.
- A shot's `flows` list takes `id`, `path` (at least two distinct consecutive XYZ points), optional `radius`, semantic `role`, `animate` and required `explains`. A cone shows direction and the optional marker travels along the path. These are explanatory overlays, not fluid simulation.
- Technical labels may set `size` and `target` (a component ID). Text faces the camera; the leader endpoint follows the component center. Inspect legibility and obstructions; a geometric bound check cannot prove either.
- `presentation.background` is `auto`, `light` or `dark`. Explicit choices need `presentation.reason`. Auto starts schematic/analogy views light and literal models dark. Codex selects the best actual result and preserves semantic meaning across themes. The resolved background appears in the storyboard and geometry QA.

`examples/toolkit-fixture.json` is synthetic geometry for these utilities, not a real engineering mechanism. Run its diagnostic checks with `python -m explainer.tests.visual_smoke`.

## Importing free commercial models

Use a free-to-download asset with source-specific CC0-1.0, CC-BY-4.0 or documented public-domain evidence. Other licenses (including NC, ND, editorial-only, unknown or paid models) are rejected by the current policy. This is a conservative supported list; do not relabel a different license to make it pass.

1. Codex reads the actual model's license and all texture/contributor terms, downloads the files using verified HTTPS, and retains the source-specific evidence. Source URLs and hashes should identify a stable revision where available. The engine does not scrape model libraries or silently accept click-through terms.
2. Prepare rights metadata using `examples/licenses/avocado-rights.json` as the field reference. For CC BY, also supply `attribution` and `changes`. The supplied Avocado file is a CC0 format-calibration specimen, not a proposed video subject.
3. Register a local package; keep `.gltf` buffer/texture references or OBJ material/texture files next to the model with relative paths. Registration refuses missing files, paths outside the package, remote resources, duplicate IDs and unsupported formats. Embedded GLB resources are supported. OBJ MTL texture options need conversion to GLB or simpler references.

```sh
python -m explainer register-model explainer/projects/my_subject housing /path/to/model.glb \
  --rights /path/to/rights.json --evidence /path/to/source-license.txt \
  --meters-per-unit 1 --units-notes 'glTF 2.0 units are meters'
```

Registration leaves `assets.housing.review` as `pending`. Codex must inspect the actual asset before changing it to `approved`. Rights review and visual/accuracy review are separate. Nothing grants storyboard or preview approval.

An assembly component can reference it with:

```json
{"id":"housing_instance","shape":"model","asset_id":"housing","role":"structure",
 "position":[0,0,0],"scale":1,"rotation":[0,0,0],"move_to":[1,0,0]}
```

Also list `"housing"` in that shot's `asset_ids`. Imported geometry keeps its relative dimensions and materials; `scale` is uniform and unit conversion is explicit. Do not use a primitive `size` vector to distort an imported model. The assembly is centered at the component origin, so leaders track its center. Source cameras/lights and source animation are removed; static geometry/material import and whole-instance motion are supported. Individual source-part controls, animation retargeting and general imported-model sections are future adapters. `.blend`, scripts and native CAD formats are not accepted.

All referenced buffers, MTLs, textures and license evidence join the approval fingerprint. A texture-only change invalidates earlier approvals. Imported textures are packed into the saved Blender scene.

```sh
python -m explainer credits explainer/projects/my_subject
```

Final production also writes `CREDITS.md`. Include applicable credits/changes in the published video description; the engine does not publish or certify legal ownership. License declarations must reflect Codex's actual source review.

Optional actual Blender test: download the pinned CC0 specimen using the `download_url` and verify `download_sha256` in `examples/licenses/avocado-rights.json`; place it at `explainer/build/import-source/Avocado.glb`, then run `python -m explainer.tests.import_smoke`. It renders the real CC0 GLB and self-authored textured glTF/OBJ/STL fixtures. All registrations remain pending; diagnostic copies simulate asset review exclusively for isolated tests. No user approvals or full episode are created.

## Slider-crank visual pilot

`slider_crank.py` provides checked ideal crank-pin and slider positions for arbitrary valid radius/rod-length ratios. The six-second procedural cutaway pilot uses those positions to keep the rod at a constant length and the piston on its axis. It illustrates rotation converted to reciprocating motion; it does not simulate combustion, valves, lubrication or forces. The authored geometry uses no downloaded model assets. The detailed pilot render script currently lives in the ignored `build/piston-test/` experiment directory; it has not been added as a general declarative production adapter.

## Review and work pool

The Tesla first-chapter preview is reviewed before the full film. `review_queue.prepare_packet` requires passing media and actual visual review, and records **send to work pool / reject** as pending choices. After an actual user reply, `review_queue.decide` either preserves rejection notes or creates a source-snapshotted explainer project item in `explainer/work_pool/`. No task queues automatically. These items are deliberately distinct from Grandpa's render-ready scene queue: remaining chapters, assets and production preflight must still be completed.
