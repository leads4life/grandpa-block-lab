from pathlib import Path
import json,hashlib,os,math
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
from kokoro_onnx import Kokoro
from explainer.core import VOICE_DELIVERY
p=Path('explainer/projects/tesla-hw3/build/full-v2')
e=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES'])
for folder in sorted(p.glob('r[1-8]')):
 v=json.loads((folder/'voice.json').read_text());arrays=[]
 for i,g in enumerate(v['thought_groups']):
  a,sr=e.create(g['text'],voice='am_fenrir',speed=v['synthesis_speed'],**VOICE_DELIVERY)[:2];a=np.asarray(a,dtype=np.float64)
  active=np.flatnonzero(np.abs(a)>np.abs(a).max()*.005)
  a=a[max(0,active[0]-round(sr*.025)):min(len(a),active[-1]+round(sr*.055))];arrays.append(a)
  if i<len(v['thought_groups'])-1:arrays.append(np.zeros(round(sr*(.13 if g['text'].endswith('?') else .08))))
 samples=np.concatenate(arrays);div=math.gcd(sr,48000);samples=resample_poly(samples,48000//div,sr//div);samples*=.7/np.abs(samples).max()
 samples=np.concatenate([np.zeros(round(.12*48000)),samples,np.zeros(round(.45*48000))]);samples=np.pad(samples,(0,round(v['seconds']*48000)-len(samples)))
 target=folder/'voice.wav';wavfile.write(target,48000,(samples*32767).astype(np.int16))
 assert hashlib.sha256(target.read_bytes()).hexdigest()==v['sha256'],'Regenerated voice differs; remeasure/review a new version before rendering.'
 print('Verified regenerated voice',folder.name)
