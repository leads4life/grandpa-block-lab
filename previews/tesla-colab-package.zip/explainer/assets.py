"""Free/commercial asset records, contained model packages, and generated credits."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import struct
import tempfile
from urllib.parse import unquote, urlsplit

FORMATS = {'.glb', '.gltf', '.obj', '.stl'}
LICENSES = {
    'CC0-1.0': 'https://creativecommons.org/publicdomain/zero/1.0/',
    'CC-BY-4.0': 'https://creativecommons.org/licenses/by/4.0/',
    'LicenseRef-Public-Domain': None,
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inside(root, name):
    path = (Path(root) / name).resolve()
    if not path.is_relative_to(Path(root).resolve()):
        raise ValueError(f'Model dependency escapes its package: {name}')
    if not path.is_file():
        raise ValueError(f'Missing model dependency: {name}')
    return path


def rights_errors(rights):
    errors = []
    if rights.get('license') not in LICENSES:
        errors.append('Only CC0-1.0, CC-BY-4.0 or reviewed public-domain assets are supported; NC/ND/editorial/unknown licenses are blocked')
    if type(rights.get('price')) not in (int, float) or rights.get('price') != 0:
        errors.append('Asset must be free to obtain (price 0)')
    for key in ('commercial_use', 'modification_allowed'):
        if rights.get(key) is not True:
            errors.append(f'License review must confirm {key}')
    for key in ('title', 'creator', 'source_url', 'license_url', 'accessed', 'review_notes'):
        if not isinstance(rights.get(key), str) or not rights[key].strip():
            errors.append(f'License record requires {key}')
    if rights.get('rights_review') != 'approved':
        errors.append('Source-specific rights review is required; a library-wide license is insufficient')
    for key in ('source_url', 'license_url'):
        if urlsplit(rights.get(key, '')).scheme != 'https':
            errors.append(f'{key} must be an HTTPS source/evidence link')
    canonical = LICENSES.get(rights.get('license'))
    if canonical and rights.get('license_url', '').rstrip('/') not in (canonical.rstrip('/'), canonical+'legalcode'):
        errors.append('License URL must match the declared CC0/CC BY license')
    if rights.get('license') == 'LicenseRef-Public-Domain' and not rights.get('public_domain_basis'):
        errors.append('Public-domain records need the source-specific legal basis')
    if rights.get('license') == 'CC-BY-4.0':
        if not rights.get('attribution'):
            errors.append('CC BY assets require attribution text')
        if not rights.get('changes'):
            errors.append('CC BY assets require an explicit changes/modifications statement')
    if rights.get('additional_restrictions') != []:
        errors.append('Additional/unknown restrictions need review; use another compatible asset')
    return errors


def gltf_document(path):
    path = Path(path)
    if path.suffix.lower() == '.gltf':
        return json.loads(path.read_text())
    raw = path.read_bytes()
    if len(raw) < 20:
        raise ValueError('Truncated GLB')
    magic, version, length = struct.unpack_from('<4sII', raw)
    if magic != b'glTF' or version != 2 or length != len(raw):
        raise ValueError('Expected a complete glTF 2 binary file')
    size, kind = struct.unpack_from('<I4s', raw, 12)
    if kind != b'JSON' or 20 + size > len(raw):
        raise ValueError('GLB JSON chunk missing or truncated')
    return json.loads(raw[20:20+size])


def dependencies(model):
    """Discover every URI/material/texture file before Blender touches a package."""
    model = Path(model).resolve()
    root, found = model.parent, {model}
    def resource(reference, parent=root):
        if reference.startswith('data:'):
            return None
        parsed = urlsplit(reference)
        decoded = unquote(parsed.path)
        if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment or '\\' in decoded or Path(decoded).is_absolute():
            raise ValueError(f'Only contained local resources are supported: {reference}')
        path = inside(root, Path(parent).relative_to(root) / decoded)
        found.add(path)
        return path
    if model.suffix.lower() in ('.gltf', '.glb'):
        doc = gltf_document(model)
        def walk(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    if key == 'uri' and isinstance(item, str):
                        resource(item)
                    else:
                        walk(item)
            elif isinstance(value, list):
                for item in value: walk(item)
        walk(doc)
    elif model.suffix.lower() == '.obj':
        for line in model.read_text().splitlines():
            words = shlex.split(line, comments=True)
            if not words or words[0].lower() != 'mtllib': continue
            for name in words[1:]:
                material = resource(name)
                for entry in material.read_text().splitlines():
                    tokens = shlex.split(entry, comments=True)
                    if tokens and (tokens[0].lower().startswith('map_') or tokens[0].lower() in ('bump', 'disp', 'decal', 'norm', 'refl')):
                        if len(tokens) < 2 or tokens[1].startswith('-'):
                            raise ValueError('OBJ texture options are unsupported; package as GLB or simplify the MTL reference')
                        resource(' '.join(tokens[1:]), material.parent)
    return sorted(found)


def model_errors(asset, root=None):
    errors = rights_errors(asset.get('rights', {}))
    if Path(asset.get('path', '')).suffix.lower() not in FORMATS:
        errors.append('Model must be GLB, glTF, OBJ or STL; executable scene files are not accepted')
    meters = asset.get('meters_per_unit')
    if isinstance(meters, bool) or not isinstance(meters, (int, float)) or not 0 < meters < float('inf'):
        errors.append('Record a finite positive meters_per_unit')
    if not asset.get('units_notes'):
        errors.append('Record the source/assumption for model units')
    if not isinstance(asset.get('files'), dict) or not asset['files']:
        errors.append('Model package requires a complete file checksum manifest')
    if root is not None and not errors:
        try:
            model = inside(root, asset['path'])
            package = {str(p.relative_to(Path(root).resolve())) for p in dependencies(model)}
            evidence = asset.get('license_evidence', '')
            if not evidence:
                raise ValueError('Retain source-specific license evidence in the project')
            expected = package | {evidence}
            if set(asset['files']) != expected:
                raise ValueError('Package manifest does not exactly match model dependencies and license evidence')
            for name, expected_hash in asset['files'].items():
                if sha(inside(root, name)) != expected_hash:
                    raise ValueError(f'Model package bytes changed: {name}')
        except (ValueError, OSError, json.JSONDecodeError) as exc:
            errors.append(str(exc))
    return errors


def register_model(root, asset_id, model, rights, evidence, meters_per_unit, units_notes):
    """Stage and copy a local reviewed package; visual review remains pending."""
    from .core import read, write
    root = Path(root).resolve()
    plan = read(root / 'plan.json')
    if not asset_id or not asset_id.isascii() or not asset_id.replace('_', '').replace('-', '').isalnum():
        raise ValueError('Asset ID must contain ASCII letters, digits, underscores or hyphens')
    errors = rights_errors(rights)
    if errors: raise ValueError('\n'.join(errors))
    model, evidence = Path(model).resolve(), Path(evidence).resolve()
    if model.suffix.lower() not in FORMATS: raise ValueError('Unsupported model format')
    if not evidence.is_file() or not evidence.stat().st_size: raise ValueError('Local license evidence is required')
    if rights.get('download_sha256') and sha(model) != rights['download_sha256']:
        raise ValueError('Downloaded model does not match the reviewed source checksum')
    files = dependencies(model)
    destination = root / 'assets' / asset_id
    if not destination.resolve().is_relative_to(root):
        raise ValueError('Asset destination escapes project directory')
    if asset_id in plan.get('assets', {}) or destination.exists():
        raise ValueError('Asset ID or destination already exists; refusing to overwrite')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix='.stage-') as temp:
        stage = Path(temp) / asset_id
        for file in files:
            target = stage / 'source' / file.relative_to(model.parent)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, target)
        shutil.copyfile(evidence, stage / 'license-evidence.txt')
        relative = Path('assets') / asset_id
        record = {'kind': 'model', 'path': str(relative / 'source' / model.name), 'sha256': sha(model),
                  'review': 'pending', 'provenance': rights['source_url'], 'rights': rights,
                  'meters_per_unit': meters_per_unit, 'units_notes': units_notes,
                  'license_evidence': str(relative / 'license-evidence.txt'),
                  'files': {str(relative / p.relative_to(stage)): sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}}
        # Check before publishing the staged package; main-file units must also be valid.
        check = model_errors(record)
        if check: raise ValueError('\n'.join(check))
        stage.rename(destination)
        try:
            check = model_errors(record, root)
            if check: raise ValueError('\n'.join(check))
            plan.setdefault('assets', {})[asset_id] = record
            write(root / 'plan.json', plan)
        except Exception:
            shutil.rmtree(destination)
            raise
    return record


def credits(plan):
    lines = ['# Asset credits', '', 'Keep applicable credits with the published video description.', '']
    for key, asset in sorted(plan.get('assets', {}).items()):
        if asset.get('kind') != 'model': continue
        r = asset['rights']
        lines.extend([f'## {r["title"]} ({key})', '', f'Creator: {r["creator"]}',
                      f'Source: {r["source_url"]}', f'License: {r["license"]} — {r["license_url"]}',
                      f'Changes: {r.get("changes", "None recorded; update before release if modified.")}', ''])
        if r.get('attribution'): lines.extend([r['attribution'], ''])
    return '\n'.join(lines) + '\n'
