"""A bounded richer-3D direction sample, synchronized to measured thought groups."""
from pathlib import Path
import hashlib,math,os,sys
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
from kokoro_onnx import Kokoro
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
from explainer.core import read,write,VOICE_DELIVERY
from explainer.media import synthesize_paced
from explainer.vehicle_prop import build_vehicle
from explainer.traffic_scene import cube
from explainer.visual_tools import material,line
from explainer.blender_backend import aim
from explainer.turn_motion import rectangles_overlap

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'retention-v2/build/showcase';OUT.mkdir(parents=True,exist_ok=True)
PARTS=['Three choices seem manageable. What happens after three decision stages?',
       'In this example: three.','Then nine.','Then twenty-seven.','Watch how quickly the search grows.']
TEXT=' '.join(PARTS)
if not (OUT/'voice.json').exists():
 engine=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES'])
 class ThoughtGroups:
  def create(self,text,voice,speed,**delivery):
   arrays=[];self.parts=[];cursor=0;sample_rate=None
   for i,part in enumerate(PARTS):
    a,sr=engine.create(part,voice=voice,speed=speed,**delivery)[:2];a=np.asarray(a,dtype=np.float64)
    active=np.flatnonzero(np.abs(a)>np.abs(a).max()*.005);assert len(active)
    a=a[max(0,active[0]-round(sr*.025)):min(len(a),active[-1]+round(sr*.055))]
    if sample_rate is not None:assert sample_rate==sr
    sample_rate=sr;self.parts.append({'text':part,'start':cursor/sr,'seconds':len(a)/sr})
    arrays.append(a);cursor+=len(a)
    if i<len(PARTS)-1:gap=np.zeros(round(sr*.12));arrays.append(gap);cursor+=len(gap)
   return np.concatenate(arrays),sample_rate
 grouped=ThoughtGroups();a,sr,speed,attempts=synthesize_paced(grouped,TEXT,'am_fenrir',1.16,VOICE_DELIVERY)
 divisor=math.gcd(int(sr),48000);a=resample_poly(a,48000//divisor,int(sr)//divisor);a*=.7/np.abs(a).max()
 lead=.12;tail=.45;a=np.concatenate([np.zeros(round(lead*48000)),a,np.zeros(round(tail*48000))])
 seconds=math.ceil(len(a)/48000*30)/30;a=np.pad(a,(0,round(seconds*48000)-len(a)))
 wavfile.write(OUT/'voice.wav',48000,(a*32767).astype(np.int16))
 write(OUT/'voice.json',{'text':TEXT,'voice':'am_fenrir','synthesis_speed':speed,'seconds':seconds,
  'measured_words_per_minute':attempts[-1]['words_per_minute'],'pace_attempts':attempts,
  'thought_groups':[dict(p,start=p['start']+lead) for p in grouped.parts],
  'sha256':hashlib.sha256((OUT/'voice.wav').read_bytes()).hexdigest(),'speech_time_stretched':False})
voice=read(OUT/'voice.json');assert voice['text']==TEXT
D=voice['seconds'];NF=round(D*30);groups=voice['thought_groups'];reveal=[groups[i]['start']+.16 for i in [1,2,3]]
W,H=768,432
bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=10;s.cycles.use_denoising=False;s.cycles.max_bounces=4;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2;s.render.use_persistent_data=False
s.render.threads_mode='FIXED';s.render.threads=4;s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100;s.render.fps=30
s.world=bpy.data.worlds.new('Deep studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.045,.075,.12,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.5
def matte(name,c):
 m=material(name,(*c,1));p=m.node_tree.nodes['Principled BSDF'];p.inputs['Metallic'].default_value=0;p.inputs['Roughness'].default_value=.7;return m
navy=matte('Navy cyclorama',(.014,.026,.044));road=matte('Textured asphalt',(.055,.072,.085));paving=matte('Curbs and pavement',(.28,.35,.4));building=matte('Architectural shell',(.23,.31,.38));leaves=matte('Layered foliage',(.045,.2,.14));wood=matte('Tree bark',(.18,.085,.035));paint=matte('Lane paint',(.74,.83,.86))
rim=material('Display trim',(.11,.17,.23,1));cyan=material('Candidate signal',(.025,.68,.95,1),True);amber=material('Warm interior light',(.95,.48,.15,1),True)
cube('Studio floor',(0,5,-.9),(180,180,.8),navy,bevel=0)
# A continuous curved cove removes the bare floor/horizon seam.
verts=[];faces=[]
for i in range(21):
 theta=math.pi/2*i/20;y=30+10*math.sin(theta);z=-.5+10*(1-math.cos(theta))
 verts.extend([(-70,y,z),(70,y,z)])
for i in range(20):faces.append((2*i,2*i+1,2*i+3,2*i+2))
mesh=bpy.data.meshes.new('Cove mesh');mesh.from_pydata(verts,[],faces);mesh.update();cove=bpy.data.objects.new('Curved technical studio',mesh);s.collection.objects.link(cove);cove.data.materials.append(navy)
for polygon in mesh.polygons:polygon.use_smooth=True
cube('Cove rear wall',(0,40,25),(140,.2,31),navy,bevel=0)

def tree(name,x,y,z,scale=1,parent=None):
 cube(name+' trunk',(x,y,z+.65*scale),(.15*scale,.15*scale,1.3*scale),wood,parent,.04)
 for k,(dx,dy,dz,r) in enumerate([(-.35,0,1.5,.68),(.35,.1,1.7,.72),(0,-.15,2.1,.6)]):
  bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=r*scale,location=(x+dx*scale,y+dy*scale,z+dz*scale));o=bpy.context.object;o.name=name+' foliage';o.parent=parent;o.data.materials.append(leaves)
def house(name,x,y,z,scale=1,parent=None):
 cube(name,(x,y,z+1.5*scale),(3*scale,2.7*scale,3*scale),building,parent,.12*scale)
 cube(name+' cornice',(x,y,z+3.08*scale),(3.22*scale,2.92*scale,.18*scale),rim,parent,.05)
 for row in [0,1]:
  for col in [-1,0,1]:cube(name+' lit window',(x+col*.8*scale,y-1.36*scale,z+(.85+row*1.25)*scale),(.48*scale,.035,.72*scale),amber,parent,.015)
 cube(name+' entry',(x,y-1.38*scale,z+.52*scale),(.55*scale,.05,1.04*scale),rim,parent,.02)

cube('Sculpted city platform',(0,-1,-.25),(17,20,.5),rim,bevel=.28)
cube('City paving',(0,-1,.025),(16.7,19.7,.08),paving,bevel=.22)
cube('Road north south',(0,-1,.076),(7.3,19.7,.035),road,bevel=0)
cube('Road east west',(0,0,.080),(16.7,7.3,.035),road,bevel=0)
for sign in [-1,1]:
 for y in [-7,-4.6,4.6,7]:cube('Center lane dash',(0,y,.107),(.09,1.2,.012),paint,bevel=0)
 for x in [-2.8,-1.7,-.6,.5,1.6,2.7]:cube('Crossing stripe',(x,sign*3.1,.112),(.5,1.0,.016),paint,bevel=0)
 house('Street corner',sign*6.3,4.5,.07,.9);tree('Street tree',sign*6.1,-2.3,.07,.9)
 cube('Curb',(sign*3.85,-6.8,.16),(.2,6,.2),paving,bevel=.045)
 cube('Platform illuminated edge',(sign*8.3,-1,-.05),(.04,19,.045),cyan,bevel=.02)
 cube('Planted verge',(sign*6.5,-6.5,.11),(3.4,3.2,.12),leaves,bevel=.15)
 cube('Bench seat',(sign*5.3,-4.4,.58),(.5,1.5,.14),wood,bevel=.04)
 for dy in [-.55,.55]:cube('Bench support',(sign*5.3,-4.4+dy,.32),(.38,.09,.5),rim,bevel=.025)
 cube('Light column',(sign*4.8,1.8,1.8),(.10,.10,3.6),rim)
 cube('Light aperture',(sign*4.8,1.8,3.55),(.35,.35,.10),amber)
coat=matte('Road-user jacket',(.8,.3,.035));ped=bpy.data.objects.new('Waiting road user',None);s.collection.objects.link(ped);ped.location=(-3.5,-3.6,.1)
cube('Coat',(0,0,1.15),(.42,.26,.58),coat,ped,.07)
bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=.16,location=(0,0,1.62));head=bpy.context.object;head.parent=ped;head.data.materials.append(matte('Skin',(.54,.32,.2)))
for sign in [-1,1]:
 cube('Trouser leg',(sign*.12,0,.48),(.15,.18,.75),rim,ped,.045)
 cube('Shoe',(sign*.12,.04,.07),(.18,.31,.14),rim,ped,.035)
 cube('Coat sleeve',(sign*.28,0,1.08),(.13,.17,.5),coat,ped,.04)
car=build_vehicle('Hero blue car');other=build_vehicle('Oncoming',(.44,.06,.035,1))
template=car
def clone(source,name,parent):
 def visit(obj,par):
  o=obj.copy();o.name=name+' '+obj.name;s.collection.objects.link(o);o.parent=par
  for child in obj.children:visit(child,o)
  return o
 return visit(source,parent)
worlds=[];nodes=[];links=[];signals=[]
origin=Vector((0,1.7,1.1))
def link(name,a,b,mat,r=.045):
 points=[]
 for i in range(17):
  q=i/16;p=a.lerp(b,q);p.z+=math.sin(q*math.pi)*.5;points.append(tuple(p))
 o=line(name,points,r,mat);return o
for i,x in enumerate([-7.5,0,7.5]):
 root=bpy.data.objects.new('Possible future '+str(i+1),None);s.collection.objects.link(root);root.location=(x,8,2.1)
 cube('State volume',(0,0,-.18),(5.2,5.6,.36),rim,root,.18)
 cube('State road',(0,0,.02),(2,5.4,.07),road,root,.04)
 for sign in [-1,1]:cube('State curb',(sign*1.2,0,.10),(.18,5.4,.17),paving,root,.03)
 mini=clone(template,'State car '+str(i),root);mini.location=(0,-.55,.07);mini.scale=(.38,)*3
 house('Future architecture',-1.9,1.25,.04,.42,root);tree('Future tree',1.9,.9,.04,.48,root)
 for side in [-1,1]:cube('Future trim',(side*2.5,0,0),(.025,5.1,.04),cyan,root,.01)
 worldpoint=Vector((x,8,3.1));edge=link('First choice',origin,worldpoint,cyan)
 worlds.append((root,mini));nodes.append((root,1,i));links.append((edge,1,i))
 for j in range(3):
  index=i*3+j;point=Vector(((index-4)*2.65,15,5.8));edge=link('Second layer',worldpoint,point,cyan,.032);links.append((edge,2,index))
  bpy.ops.mesh.primitive_torus_add(major_radius=.36,minor_radius=.065,major_segments=24,minor_segments=8,location=point,rotation=(math.pi/2,0,0));ring=bpy.context.object;ring.data.materials.append(rim);nodes.append((ring,2,index))
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=.17,location=point);dot=bpy.context.object;dot.data.materials.append(cyan);nodes.append((dot,2,index))
  for k in range(3):
   sub=index*3+k;tip=Vector(((sub-13)*.92,22,8.2));edge=link('Third layer',point,tip,cyan,.021);links.append((edge,3,sub))
   bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=.18,location=tip);dot=bpy.context.object;dot.data.materials.append(cyan);nodes.append((dot,3,sub))
for i,(edge,level,k) in enumerate(links):
 if level==1:
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=.12);marker=bpy.context.object;marker.data.materials.append(amber);signals.append((marker,edge))
for name,pos,power,size,color in [('Soft key',(-8,-10,18),3200,12,(.88,.94,1)),('Ice rim',(12,13,19),6200,11,(.38,.7,1)),('Warm fill',(-16,5,10),2300,9,(1,.7,.42))]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.size=size;d.color=color;o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.location=pos;aim(o,(0,3,2))
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.clip_end=300
def ease(x):x=max(0,min(1,x));return x*x*(3-2*x)
poses={};lenses={'decision':48.,'grow':36.,'reward':39.}
def apply(f):
 t=f/30;u=t/D;travel=.55*ease(t/1.8);car.location=(1.55,-6.5+travel,.1);other.location=(-1.55,6.6-6.0*u,.1);other.rotation_euler.z=math.pi
 assert not rectangles_overlap((car.location.x,car.location.y,0),(other.location.x,other.location.y,math.pi))
 for vehicle,distance in [(car,travel),(other,6*u)]:
  for wheel in vehicle.children:
   if wheel.get('vehicle_part')=='wheel':wheel.rotation_euler.x=-distance/.34
 for o,level,k in nodes:
  start=reveal[level-1]-.36;growth=ease((t-start)/.42);o.scale=(max(.0001,growth),)*3
 for root,mini in worlds:mini.location.y=-.55+.3*math.sin(t*1.8)
 for edge,level,k in links:edge.data.bevel_factor_end=ease((t-reveal[level-1]+.45)/.46)
 for marker,edge in signals:
  q=(t*.65)%1;ps=edge.data.splines[0].points;a=Vector(ps[0].co[:3]);b=Vector(ps[-1].co[:3]);marker.location=a.lerp(b,q)+Vector((0,0,math.sin(q*math.pi)*.5));marker.scale=(.01 if t<reveal[0]-.4 else 1,)*3
 if t<reveal[0]-.65:
  q=t/max(.1,reveal[0]-.65);cam.location=(6.5-q,-13+q,4.0);target=Vector((1.5,-5.8,.8));shot='decision';important=[car]
 elif t<reveal[2]-.15:
  cam.location=(19-2*u,-26+u,18);target=Vector((0,6,3.5));shot='grow';important=[o for o,l,k in nodes if max(o.scale)>.04]
 else:
  cam.location=(6.5-2*u,-28+u,11);target=Vector((0,9,4.3));shot='reward';important=[o for o,l,k in nodes if max(o.scale)>.04]
 cam.data.lens=lenses[shot];aim(cam,target);bpy.context.view_layer.update();ratio=1.
 for obj in important:
  if obj==car:corners=[(x,y,z) for x in [-1.15,1.15] for y in [-2.4,2.4] for z in [0,1.8]]
  elif obj.type=='EMPTY':corners=[(x,y,z) for x in [-2.6,2.6] for y in [-2.8,2.8] for z in [-.36,1.8]]
  else:corners=obj.bound_box
  for corner in corners:
   p=world_to_camera_view(s,cam,obj.matrix_world@Vector(corner));assert p.z>0;ratio=min(ratio,.46/max(abs(p.x-.5),1e-9),.43/max(abs(p.y-.5),1e-9))
 poses[f]={'shot':shot,'ratio':ratio,'count':27 if t>=reveal[2] else 9 if t>=reveal[1] else 3 if t>=reveal[0] else None}
 return ratio
for attempt in range(3):
 for f in range(NF):apply(f)
 bad=[p for p in poses.values() if p['ratio']<.999]
 if not bad:break
 for name in lenses:
  values=[p['ratio'] for p in poses.values() if p['shot']==name]
  if values and min(values)<1:lenses[name]*=min(values)*.97
assert not bad,'Framing repair failed'
write(OUT/'timing.json',{'seconds':D,'frames':NF,'width':W,'height':H,'reveal_seconds':reveal,'text':TEXT,'voice':voice})
write(OUT/'poses.json',poses);write(OUT/'scene-qa.json',{'passed':True,'frames':NF,'continuous_3d':True,'claim':'Illustrative3^1,3^2,3^3 branching counts, not Tesla measurements','lenses':lenses,'purpose':'Proposed richer art direction and one measured micro hook/reward; not a revision of the complete film'})
raw=OUT/'raw';raw.mkdir(exist_ok=True)
signature=hashlib.sha256((Path(__file__).read_bytes()+(OUT/'voice.wav').read_bytes())).hexdigest()
if any(raw.glob('*.png')):assert read(OUT/'render-version.json')['sha256']==signature,'Changed sample source: clear only the prior diagnostic frames before rerendering'
write(OUT/'render-version.json',{'sha256':signature})
frames=[0,round(reveal[1]*30),NF-1] if '--stills' in sys.argv else range(NF)
for f in frames:
 p=raw/f'{f:06d}.png'
 if p.exists():continue
 apply(f);s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
print('RETENTION SHOWCASE READY',D,'seconds',NF,'frames',flush=True)
