"""Resumable complete-film production; final inspection is distinct from automated QA."""
from pathlib import Path
import argparse, hashlib, math, shutil, subprocess, sys
from explainer.core import read, write
from explainer.media import voice, check_video, assemble, mix_mechanical

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'build/full-v1'
FPS=30
AUTH="User: go ahead and send to pool and run the entire process, look is ok dress it up more on blank canvas going forward"
TITLES=['Opening','What Tesla disclosed','Why decision time matters','How search grows','Start with a goal','Layers of interaction','Relevant agents remain visible','Compare coherent choices','What scores can consider','Prune poor branches','Efficiency and hardware limits','Application versus deployment','Selective effort']
MODES=['opening','graph','latency','growth','traffic','layers','attention','traffic','scores','pruning','compute','evidence','graph']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(args):subprocess.run([str(x) for x in args],check=True)

def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    plan=read(ROOT/'plan.json');shots=[]
    opening=read(ROOT/'build/opening-v2/qa.json')
    decision=read(ROOT/'review/decision.json')
    assert decision['status']=='sent_to_work_pool'
    authorization=read(ROOT/'production-state.json')
    assert authorization.get('full_process_authorized') and authorization.get('user_authorization')==AUTH,'Full production needs actual recorded user authorization'
    for i,source in enumerate(plan['shots']):
        shot={key:source[key] for key in ['id','narration','claim_ids','teaches','simplifications']}
        shot.update(index=i,title=TITLES[i],mode=MODES[i],implementation='render_film_chapter.py')
        folder=OUT/shot['id'];folder.mkdir(exist_ok=True)
        if i==0:
            shot.update(narration=opening['script'],seconds=opening['seconds'],frames=round(opening['seconds']*FPS),voice=opening['voice'],voice_sha256=opening['voice_sha256'])
        else:
            # Original dramatic plan used a truck; the verified teaching mechanism does
            # not require that class. Keep wording aligned with the actual vehicle prop.
            shot['narration']=shot['narration'].replace('truck','vehicle')
            meta=folder/'voice.json'
            if not meta.exists():voice(shot,folder)
            a=read(meta)
            assert a['text']==shot['narration'] and a['sha256']==sha(folder/'voice.wav')
            seconds=math.ceil((a['seconds']+.55)*FPS)/FPS
            shot.update(seconds=seconds,frames=round(seconds*FPS),voice=a['profile'],voice_sha256=a['sha256'])
        shot['duration']=shot['seconds']
        shots.append(shot)
    manifest={'title':plan['title'],'authorization':AUTH,'preview_decision':decision['id'],
              'fps':FPS,'width':960,'height':540,'render_samples':8,'shots':shots,
              'seconds':sum(s['seconds'] for s in shots),'music':False,'captions':False,
              'sources':plan['sources'],'accuracy':'All graphics are original schematic explanations; no proprietary Tesla software, measured score or deployment reconstruction.'}
    write(OUT/'manifest.json',manifest)
    md=['# Full-film production storyboard','',AUTH,'',f"Measured runtime: {manifest['seconds']:.1f} seconds. The approved opening is reused byte-for-byte.",'']
    for shot in shots:md.extend([f"## {shot['index']+1}. {shot['title']}",'',shot['narration'],'',f"Moving 3D scene: {shot['mode']}. Duration: {shot['seconds']:.2f}s.",''])
    (ROOT/'full-production-storyboard.md').write_text('\n'.join(md))
    (OUT/'CREDITS.md').write_text('# Sources and credits\n\nAll vehicle, road, environment, compute and graph geometry: original procedural project models. No downloaded models. Generic vehicles are not Tesla CAD.\n\nNarration: Kokoro am_fenrir. Graphics fonts: DejaVu Sans. No music.\n\nTechnical source: US20260105614A1, published April 16, 2026, https://patents.google.com/patent/US20260105614A1/en\n\nProduct limitations: https://www.tesla.com/support/fsd\n\nApplication disclosure is not evidence of deployment, hardware parity or measured performance.\n')
    return manifest

def encode(shot):
    folder=OUT/shot['id'];video=folder/'chapter.mp4'
    encode_sources={p.name:sha(p) for p in [Path(__file__),ROOT/'film_labels.py']}
    if video.exists() and (folder/'qa.json').exists():
        prior=read(folder/'qa.json')
        if prior['passed'] and prior.get('encode_source_hashes')==encode_sources:return video
    from PIL import Image
    from importlib import import_module
    decorate=import_module('explainer.projects.tesla-hw3.film_labels').decorate
    frames=folder/'frames';frames.mkdir(exist_ok=True)
    expected={f'{i:06d}.png' for i in range(shot['frames'])}
    assert {p.name for p in (folder/'raw').glob('*.png')}==expected,'Incomplete chapter'
    filtered=folder/'filtered';filtered.mkdir(exist_ok=True)
    run(['ffmpeg','-v','error','-y','-threads','2','-filter_threads','2','-framerate',FPS,'-i',folder/'raw/%06d.png','-vf','nlmeans=s=4:p=7:r=9','-start_number',0,filtered/'%06d.png'])
    poses=read(folder/'poses.json')
    for f in range(shot['frames']):
        with Image.open(filtered/f'{f:06d}.png') as src:im=src.convert('RGB')
        im=decorate(im,poses[str(f)])
        im.save(frames/f'{f:06d}.png')
    cues=[]
    if shot['mode'] in ['traffic','attention','latency']:
        start=0 if shot['mode']=='latency' else 6.7
        cues=[{'kind':'motor','at':start,'duration':shot['seconds']-start-.2,'purpose':'Quiet synthetic movement cue; not an authentic vehicle recording.'}]
    audio=mix_mechanical({'id':shot['id'],'sfx':cues},folder/'voice.wav',folder/'mix.wav',shot['seconds'])
    gain=0
    for _ in range(4):
        run(['ffmpeg','-v','error','-y','-framerate',FPS,'-i',frames/'%06d.png','-i',audio,'-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:level=false:latency=1,apad','-t',shot['seconds'],'-c:v','libx264','-threads',2,'-crf',18,'-pix_fmt','yuv420p','-c:a','aac','-ar',48000,'-movflags','+faststart',video])
        qa=check_video(video,shot['seconds'],960,540)
        if qa['passed']:break
        gain+=-14-qa['lufs']
    assert qa['passed'],qa
    qa.update(review='pending_final_sequence_inspection',voice_sha256=shot['voice_sha256'],scene_checks=read(folder/'scene-qa.json'),encode_source_hashes=encode_sources)
    write(folder/'qa.json',qa)
    # Retain native frames and media; disposable denoise/compositing copies are reproducible.
    shutil.rmtree(filtered);shutil.rmtree(frames)
    return video

def main():
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--preflight',action='store_true');a.add_argument('--render',action='store_true');args=a.parse_args()
    m=prepare()
    if args.prepare:return
    renderer='explainer.projects.tesla-hw3.render_film_chapter'
    if args.preflight:
        for shot in m['shots'][1:]:run([sys.executable,'-m',renderer,'--index',shot['index'],'--stills'])
        write(OUT/'pipeline-state.json',{'stage':'preflight_images_ready','full_render_started':False,'seconds':m['seconds']})
        return
    if not args.render:return
    review=read(OUT/'preflight-review.json')
    assert review['passed'],'Actual preflight images must be inspected first'
    for path,expected in review['source_hashes'].items():
        assert sha(path)==expected,('Preflight review is stale',path)
    assert review['manifest_sha256']==sha(OUT/'manifest.json'),'Measured production manifest changed after review'
    videos=[ROOT/'build/opening-v2/tesla-opening-v2.mp4']
    for shot in m['shots'][1:]:
        write(OUT/'pipeline-state.json',{'stage':'rendering','chapter':shot['index']+1,'title':shot['title'],'total_chapters':len(m['shots']),'full_render_started':True})
        run([sys.executable,'-m',renderer,'--index',shot['index']])
        videos.append(encode(shot))
    output=OUT/'tesla-planning-complete.mp4'
    assemble(videos,[s['seconds'] for s in m['shots']],output)
    qa=check_video(output,m['seconds'],960,540);assert qa['passed'],qa
    qa.update(review='pending_actual_final_video_inspection',scope='Complete film',chapters=len(videos))
    write(OUT/'final-qa.json',qa)
    write(OUT/'pipeline-state.json',{'stage':'complete_media_pending_final_inspection','full_render_started':True,'video':str(output),'seconds':m['seconds'],'automatic_publication':False})
    print('FULL FILM ENCODED; FINAL INSPECTION REQUIRED',output,flush=True)

if __name__=='__main__':
    try:main()
    except Exception as error:
        OUT.mkdir(parents=True,exist_ok=True)
        write(OUT/'pipeline-error.json',{'stage':'stopped_on_error','error':str(error),'automatic_publication':False})
        raise
