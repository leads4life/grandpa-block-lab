# 🎬 Production Re-Cut Guide: Tesla Planning Explainer

**Project Objective:** Transform clinical patent walkthrough into a high-retention engineering explainer.  
**Target Runtime:** ~4:15 – 4:45  
**Core Conflict:** Hardware 3 Obsolescence vs. Algorithmic Efficiency

---

## ⏱️ Scene-by-Scene Re-Cut Table

| Scene & Target Time | Visual Direction & Asset Edits | Script / Voiceover (VO) | Sound Design & Audio Cues |
| :--- | :--- | :--- | :--- |
| **Scene 1: The Cold Open**<br>`(0:00 – 0:35)` | • **Move from End:** Pull the compute bar chart and HW3 chip asset directly to frame 0.<br>• **Split Screen:** Left side shows glowing red HW3 chip (`MAX CAPACITY`). Right side shows cool blue AI4 chip.<br>• Compute bar spikes through the ceiling. | *"For the last two years, over four million Tesla owners have been staring at an engineering time bomb: the belief that older Hardware 3 chips lack the raw muscle to ever run next-generation autonomy."* | • Heavy sub-bass drop at 0:01.<br>• Digital warning beep/alarm on the HW3 threshold breach. |
| **Scene 2: The Villain – "The Combinatorial Trap"**<br>`(0:35 – 1:15)` | • Multiply red predictive vectors from the cyclist, pedestrian, and oncoming truck into tangled spaghetti.<br>• Bold center overlay: **`THE COMBINATORIAL TRAP`**.<br>• Quick 2-second cut to steering wheel micro-jerking in cabin to visually anchor phantom braking. | *"At 45 miles per hour, your car travels 66 feet every second. If the computer tries to brute-force calculate every possible move of every pedestrian, bike, and vehicle all at once, latency explodes. That mathematical bottleneck is why older autonomous systems hesitate and stutter."* | • Fast-ticking clock SFX accelerating with vector count.<br>• Digital glitch sting when latency peaks. |
| **Scene 3: The Patent Reveal & Goal Node**<br>`(1:15 – 2:05)` | • Crisp graphic wipe clears away the red vector web.<br>• Sleek patent schematic (`US2026/105614`) slides in and unfolds.<br>• High-contrast green pin drops into the target lane labeled **`GOAL NODE`**. | *"Patent US2026/105614 abandons brute force entirely. Instead of calculating everything in parallel, it shifts to a Sequential Nodal Graph. And the secret to making old hardware fast isn't what it calculates—it’s what it refuses to look at."* | • Crisp whip-whoosh on the clean wipe.<br>• Sonar ping on the Goal Node pin.<br>• Driving ambient tech synth beat kicks in. |
| **Scene 4: Aggressive Pruning**<br>`(2:05 – 2:55)` | • Turning corridor sweeps the path.<br>• Cyclist on far right bike lane desaturates to matte grey with tag: **`[IGNORED / 0 FLOPS]`**.<br>• Branching tree: laser slices vaporize discarded paths at the root rather than gently fading them. | *"Watch the right side of the screen. Because that cyclist never intersects the turning corridor, the car ignores their future path completely. Zero wasted compute. The system slashes out bad branches at the root before they ever touch the processor."* | • Downward pitch "mute" cue when cyclist greys out.<br>• Laser-zap / scissor-cut SFX on branch terminations. |
| **Scene 5: Three-Tier Scoring Pillar**<br>`(2:55 – 3:45)` | • Vertical 3D pillar illuminates tier by tier:<br>  1. Top: `PHYSICS (Zero Collision)`<br>  2. Middle: `COMFORT & PANIC THRESHOLD`<br>  3. Bottom: `HUMAN DISCRIMINATOR`<br>• Highlight middle layer when discussing lateral G-forces. | *"It’s not just avoiding collisions. The algorithm actively scores passenger panic—pruning paths that pull too many lateral G-forces or feel unnatural to a human driver."* | • Three ascending mechanical clicks as each tier locks into place. |
| **Scene 6: The Verdict & End Card**<br>`(3:45 – End)` | • Compute load bar chart drops sharply below the HW3 limit line and turns solid green.<br>• Hero shot of vehicle clearing intersection smoothly.<br>• End card boxes appear right / left. | *"True intelligence isn't measured by how many millions of paths a chip can calculate at once—it’s defined by what the algorithm is smart enough to never calculate at all. If you want to see how this psychological filter changes when you switch drive modes, click the breakdown on screen right now."* | • Resolving orchestral-synth swell.<br>• Clean bass thud on final line. |

---

## 🛠️ Key Takeaways for the Timeline Edit

1. **Don't Bury the Stakes:** Keep the HW3 vs. AI4 controversy in Act I to hook the audience immediately.
2. **Contrast Before Resolution:** Establish the chaotic "spaghetti math" before revealing the clean nodal graph.
3. **Punchy Visual Flags:** Ensure labels like `[IGNORED / 0 FLOPS]` pop on screen so the viewer instantly grasps the compute savings.
