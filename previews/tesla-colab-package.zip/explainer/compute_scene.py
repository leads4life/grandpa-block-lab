"""Original generic compute-module prop with a reusable exploded-processor rig."""
import bpy
from .traffic_scene import cube
from .visual_tools import material,line


def build_compute(name='Compute'):
    root=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(root)
    core=bpy.data.objects.new(name+' processor rig',None);bpy.context.collection.objects.link(core);core.parent=root
    pcb=material(name+' PCB',(.025,.11,.095,1));chip=material(name+' packages',(.035,.045,.065,1))
    metal=material(name+' lid',(.35,.42,.5,1));gold=material(name+' conductors',(.55,.32,.075,1))
    white=material(name+' connectors',(.65,.69,.74,1))
    pieces=[]
    def part(label,pos,size,mat,parent=root,bevel=.025):
        obj=cube(name+' '+label,pos,size,mat,parent,bevel);pieces.append(obj);return obj
    part('board',(0,0,0),(5,3.7,.12),pcb,bevel=.05)
    part('processor',(0,0,.21),(1.65,1.65,.32),chip,core,.06)
    part('cap',(0,0,.39),(1.42,1.42,.06),metal,core,.04)
    for sign in [-1,1]:
        for i in range(12):
            a=-.66+i*.12
            part('contact',(sign*.88,a,.17),(.2,.045,.055),gold,core,.005)
            part('contact',(a,sign*.88,.17),(.045,.2,.055),gold,core,.005)
        for y in [-1.15,1.15]:part('memory',(sign*1.6,y,.2),(.62,.62,.26),chip)
    for i in range(8):
        x=-2.1+i*.2
        part('passive',(x,-1.55,.12),(.10,.18,.12),metal,bevel=.01)
        obj=line(name+' trace',[(x,1.55,.07),(x,.95,.07),(-.8,.95,.07)],.012,gold);obj.parent=root;pieces.append(obj)
    for x in [-1.8,-.9,0,.9,1.8]:part('connector',(x,1.77,.2),(.55,.20,.3),white)
    for x in [-2.15,2.15]:
        for y in [-1.4,1.4]:part('mount',(x,y,-.15),(.14,.14,.18),gold)
    return root,core,pieces
