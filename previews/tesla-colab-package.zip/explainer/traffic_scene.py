"""Original schematic EV/intersection assets. No OEM branding or proprietary geometry."""
import math
import bpy
from .visual_tools import material


def cube(name, location, dimensions, mat, parent=None, bevel=.04):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.object
    obj.name, obj.scale = name, dimensions
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    if parent: obj.parent = parent
    if bevel:
        edge = obj.modifiers.new('Rounded edges', 'BEVEL'); edge.width = bevel; edge.segments = 3
        obj.modifiers.new('Weighted normals', 'WEIGHTED_NORMAL')
    return obj


def sedan(name='Illustrative EV'):
    """Generic 4.6 m sedan; local forward is +Y, ground is Z=0."""
    root = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(root)
    paint = material(name+' paint', (.035, .16, .29, 1))
    glass = material(name+' glass', (.025, .045, .065, 1))
    tire = material(name+' tires', (.018, .022, .026, 1))
    alloy = material(name+' alloys', (.48, .55, .63, 1))
    white = material(name+' headlamps', (.8, .93, 1, 1), luminous=True)
    red = material(name+' tail lamps', (.7, .03, .025, 1), luminous=True)
    cube(name+' lower body', (0, 0, .65), (1.86, 4.6, .56), paint, root, .18)
    cube(name+' hood', (0, 1.32, .94), (1.76, 1.6, .18), paint, root, .10)
    # Sloping windshield/rear glass and a narrower roof avoid a rectangular cab silhouette.
    vertices=[(-.79,-1.35,.92),(.79,-1.35,.92),(.79,1.0,.92),(-.79,1.0,.92),
              (-.65,-.82,1.48),(.65,-.82,1.48),(.65,.38,1.48),(-.65,.38,1.48)]
    mesh=bpy.data.meshes.new(name+' cabin mesh')
    mesh.from_pydata(vertices,[],[(0,3,2,1),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)])
    mesh.update();cabin=bpy.data.objects.new(name+' cabin',mesh);bpy.context.collection.objects.link(cabin)
    cabin.parent=root;cabin.data.materials.append(glass)
    cube(name+' roof',(0,-.22,1.49),(1.32,1.23,.055),paint,root,.035)
    for x in [-.94, .94]:
        for y in [-1.42, 1.42]:
            bpy.ops.mesh.primitive_cylinder_add(vertices=40, radius=.35, depth=.21, location=(x, y, .35))
            wheel = bpy.context.object; wheel.name = name+' tire'; wheel.rotation_euler.y = math.pi/2
            wheel.data.materials.append(tire); wheel.parent = root
            bpy.ops.mesh.primitive_cylinder_add(vertices=40, radius=.23, depth=.22, location=(x, y, .35))
            rim = bpy.context.object; rim.name = name+' rim'; rim.rotation_euler.y = math.pi/2
            rim.data.materials.append(alloy); rim.parent = root
        cube(name+' lamp', (x*.7, 2.29, .83), (.42, .035, .11), white, root, .025)
        cube(name+' tail lamp', (x*.7, -2.29, .83), (.42, .035, .10), red, root, .025)
    # Make genuine wheel arches so rotating/steered wheels do not pass through solid bodywork.
    body=bpy.data.objects[name+' lower body'];bpy.context.view_layer.objects.active=body
    for modifier in list(body.modifiers):bpy.ops.object.modifier_apply(modifier=modifier.name)
    for x in [-.94,.94]:
        for y in [-1.42,1.42]:
            bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.41,depth=.75,location=(x,y,.35))
            cutter=bpy.context.object;cutter.rotation_euler.y=math.pi/2
            bpy.context.view_layer.objects.active=body
            cut=body.modifiers.new('Wheel well','BOOLEAN');cut.operation='DIFFERENCE';cut.solver='EXACT';cut.object=cutter
            bpy.ops.object.modifier_apply(modifier=cut.name);bpy.data.objects.remove(cutter,do_unlink=True)
    edge=body.modifiers.new('Arch edge highlights','BEVEL');edge.width=.015;edge.segments=2
    body.modifiers.new('Arch normals','WEIGHTED_NORMAL')
    root['provenance'] = 'Original project-generated schematic geometry; no downloaded model or OEM branding'
    root['accuracy'] = 'Generic sedan, not a dimensionally accurate Tesla model'
    return root


def intersection():
    """Illustrative right-hand-traffic intersection, dimensions in meters."""
    asphalt = material('Asphalt', (.055, .065, .075, 1))
    sidewalk = material('Pavement', (.30, .33, .35, 1))
    white = material('Road paint', (.85, .88, .90, 1))
    yellow = material('Center paint', (.85, .52, .04, 1))
    cube('Ground', (0, 0, -.16), (44, 44, .25), sidewalk, bevel=0)
    cube('North south road', (0, 0, -.015), (8, 44, .05), asphalt, bevel=0)
    cube('East west road', (0, 0, -.01), (44, 8, .05), asphalt, bevel=0)
    for sign in [-1, 1]:
        for n in range(3):
            p = sign*(7+n*5)
            cube('Lane mark', (0, p, .025), (.10, 2.5, .015), yellow, bevel=0)
            cube('Lane mark', (p, 0, .025), (2.5, .10, .015), yellow, bevel=0)
        for k in range(8):
            t = -3.5+k
            cube('Crosswalk', (t, sign*5, .025), (.45, 1.65, .015), white, bevel=0)
            cube('Crosswalk', (sign*5, t, .025), (1.65, .45, .015), white, bevel=0)
    return {'roads': 'two perpendicular 8 m illustrative roads', 'traffic': 'right-hand',
            'provenance': 'Original project-generated schematic geometry'}
