"""Versioned production contracts and approval evidence (standard library only)."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path

VERSION = 1
VOICE = {"engine": "kokoro-onnx", "voice": "am_fenrir", "speed": 0.8, "sample_rate": 48000}
VOICE_DELIVERY = {"sentence_pause": 0.18, "clause_pause": 0.06}
ROLES = {"structure", "active", "flow", "signal", "context"}


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def contained(root, relative):
    path = (Path(root) / relative).resolve()
    if not path.is_relative_to(Path(root).resolve()):
        raise ValueError(f'Asset escapes project directory: {relative}')
    return path


def finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def vector(value, n=3):
    return isinstance(value, list) and len(value) == n and all(finite(x) for x in value)


def validate(plan, root=None):
    """Return actionable blockers. Drafts may be incomplete; production contracts may not."""
    errors = []
    if plan.get('version') != VERSION:
        errors.append('Unsupported plan version')
    if not isinstance(plan.get('title'), str) or not plan['title'].strip():
        errors.append('Supply a project title')
    if plan.get('format') != {'width': 1920, 'height': 1080, 'fps': 30, 'captions': False}:
        errors.append('Format must be 1920x1080, 30 fps, without burned-in captions')
    if plan.get('narrator') != VOICE:
        errors.append('Use the channel narrator profile; changing it requires a direction decision')
    if plan.get('audio_policy') != {'music': False, 'sfx': 'restrained_mechanical'}:
        errors.append('Audio must use restrained mechanical effects and no music')
    if not plan.get('learning_goal'):
        errors.append('Codex must complete the learning goal')
    if plan.get('open_questions'):
        errors.append('Resolve outstanding direction questions')
    if plan.get('retention_required') or 'retention' in plan:
        from .retention import audit
        errors.extend('Retention: '+e for e in audit(plan)['errors'])
    subject_bible = plan.get('subject_bible', {})
    for key in ('scope', 'mechanism', 'terminology', 'narration_guidance', 'simplifications'):
        if not subject_bible.get(key):
            errors.append(f'Codex must complete subject bible: {key}')
    sources = plan.get('sources', {})
    claims = plan.get('claims', {})
    assets = plan.get('assets', {})
    for key, claim in claims.items():
        if claim.get('status') != 'verified' or not claim.get('sources'):
            errors.append(f'Claim {key}: verify against sources before production')
        for source in claim.get('sources', []):
            entry = sources.get(source, {})
            if not all(entry.get(k) for k in ('title', 'locator', 'accessed', 'supports')):
                errors.append(f'Claim {key}: source {source} lacks a locator/date/supporting evidence')
    for key, asset in assets.items():
        if asset.get('kind') not in ('image', 'model'):
            errors.append(f'Asset {key}: unsupported kind')
        if asset.get('review') != 'approved' or not asset.get('provenance'):
            errors.append(f'Asset {key}: requires accuracy/provenance review')
        if asset.get('kind') == 'model':
            from .assets import model_errors
            errors.extend(f'Asset {key}: {message}' for message in model_errors(asset, root))
        if root is not None:
            try:
                path = contained(root, asset.get('path', ''))
                if not path.is_file():
                    errors.append(f'Asset {key}: file missing')
                elif asset.get('sha256') != hashlib.sha256(path.read_bytes()).hexdigest():
                    errors.append(f'Asset {key}: bytes changed; review and update its SHA-256')
            except ValueError as exc:
                errors.append(str(exc))
    shots = plan.get('shots', [])
    if not shots:
        errors.append('Codex must complete the shot list from the supplied plan')
    ids = set()
    for shot in shots:
        sid = shot.get('id', '')
        prefix = f'Shot {sid or "<missing>"}'
        if not sid or not isinstance(sid, str) or not sid.replace('_', '').replace('-', '').isalnum() or sid in ids:
            errors.append(f'{prefix}: needs a unique alphanumeric ID')
        ids.add(sid)
        duration = shot.get('duration')
        if not finite(duration) or duration <= 0:
            errors.append(f'{prefix}: duration must be positive and finite')
        for key in ('narration', 'teaches', 'visual_intent'):
            if not isinstance(shot.get(key), str) or not shot[key].strip():
                errors.append(f'{prefix}: complete {key}')
        if shot.get('accuracy') not in ('literal', 'schematic', 'analogy'):
            errors.append(f'{prefix}: declare literal, schematic, or analogy')
        if shot.get('accuracy') != 'literal' and not shot.get('simplifications'):
            errors.append(f'{prefix}: record simplifications')
        if not shot.get('claim_ids') and not shot.get('nonfactual_reason'):
            errors.append(f'{prefix}: link factual claims or explain why this shot is nonfactual')
        for claim in shot.get('claim_ids', []):
            if claim not in claims:
                errors.append(f'{prefix}: unknown claim {claim}')
        for cue in shot.get('sfx', []):
            if (cue.get('kind') not in ('click', 'clunk', 'motor') or not cue.get('purpose') or
                not finite(cue.get('at')) or not finite(cue.get('duration')) or
                not finite(duration) or cue.get('at', -1) < 0 or cue.get('duration', 0) <= 0 or
                cue.get('at', 0) + cue.get('duration', 0) > duration):
                errors.append(f'{prefix}: invalid or unexplained mechanical sound cue')
        presentation = shot.get('presentation', {})
        if presentation.get('background', 'auto') not in ('auto', 'light', 'dark'):
            errors.append(f'{prefix}: background must be auto, light or dark')
        if presentation.get('background', 'auto') != 'auto' and not presentation.get('reason'):
            errors.append(f'{prefix}: explain the explicit background choice')
        components = shot.get('components', [])
        component_ids = set()
        for obj in components:
            oid = obj.get('id')
            if not oid or oid in component_ids:
                errors.append(f'{prefix}: duplicate/missing component ID')
            component_ids.add(oid)
            if obj.get('shape') not in ('box', 'cylinder', 'sphere', 'tube', 'model') or obj.get('role') not in ROLES:
                errors.append(f'{prefix}/{oid}: unsupported shape or semantic role')
            if obj.get('shape') == 'model':
                asset_id = obj.get('asset_id')
                if assets.get(asset_id, {}).get('kind') != 'model':
                    errors.append(f'{prefix}/{oid}: model component needs a registered model asset')
                if asset_id not in shot.get('asset_ids', []):
                    errors.append(f'{prefix}/{oid}: declare model asset_id in shot asset_ids')
                if not finite(obj.get('scale', 1)) or obj.get('scale', 1) <= 0:
                    errors.append(f'{prefix}/{oid}: model scale must be positive and uniform')
                if 'section' in obj or 'size' in obj:
                    errors.append(f'{prefix}/{oid}: imported models use uniform scale; general model sections are not implemented')
            wall = obj.get('wall', .12)
            if obj.get('shape') == 'tube' and (not finite(wall) or not 0 < wall < .5):
                errors.append(f'{prefix}/{oid}: tube wall must be between 0 and 0.5')
            if 'section' in obj:
                cut = obj['section']
                if (cut.get('axis') not in ('x', 'y', 'z') or
                    cut.get('keep') not in ('positive', 'negative') or
                    not finite(cut.get('offset', 0)) or not -.5 < cut.get('offset', 0) < .5):
                    errors.append(f'{prefix}/{oid}: invalid local section plane')
                if obj.get('shape') == 'tube' and cut.get('axis') == 'z':
                    errors.append(f'{prefix}/{oid}: tube sections currently support x/y only to preserve the bore')
            for field in (('position',) if obj.get('shape') == 'model' else ('position', 'size')):
                if not vector(obj.get(field)) or (field == 'size' and min(obj[field]) <= 0):
                    errors.append(f'{prefix}/{oid}: invalid {field}')
            for field in ('move_to', 'rotation', 'rotate_to'):
                if field in obj and not vector(obj[field]):
                    errors.append(f'{prefix}/{oid}: invalid {field}')
        flow_ids = set()
        for cue in shot.get('flows', []):
            path = cue.get('path', [])
            radius = cue.get('radius', .025)
            if (not cue.get('id') or cue['id'] in flow_ids or not cue.get('explains') or
                cue.get('role', 'flow') not in ROLES or not isinstance(path, list) or len(path) < 2 or
                not all(vector(point) for point in path) or
                not finite(radius) or radius <= 0):
                errors.append(f'{prefix}: invalid or unexplained flow arrow')
            elif any(a == b for a, b in zip(path, path[1:])):
                errors.append(f'{prefix}: consecutive flow points must be distinct')
            flow_ids.add(cue.get('id'))
        visual_assets = shot.get('asset_ids', [])
        for aid in visual_assets:
            if aid not in assets:
                errors.append(f'{prefix}: unknown asset {aid}')
        mode = shot.get('visual_type', 'assembly')
        if mode == 'image' and (shot.get('flows') or shot.get('labels') or shot.get('components')):
            errors.append(f'{prefix}: image shots cannot silently ignore 3D overlays')
        if mode == 'image':
            if len(visual_assets) != 1 or assets.get(visual_assets[0], {}).get('kind') != 'image':
                errors.append(f'{prefix}: image shot requires exactly one image asset')
        elif mode == 'assembly':
            if not components:
                errors.append(f'{prefix}: assembly needs subject-specific components')
            referenced = {obj.get('asset_id') for obj in components if obj.get('shape') == 'model'}
            if set(visual_assets) != referenced:
                errors.append(f'{prefix}: assembly asset_ids must match its model component references')
        else:
            errors.append(f'{prefix}: unsupported visual_type {mode}')
        for label in shot.get('labels', []):
            if not label.get('text') or not vector(label.get('position')):
                errors.append(f'{prefix}: invalid technical label')
            if label.get('target') and label['target'] not in component_ids:
                errors.append(f'{prefix}: callout targets unknown component {label["target"]}')
            if not finite(label.get('size', .18)) or label.get('size', .18) <= 0:
                errors.append(f'{prefix}: invalid label size')
        camera = shot.get('camera', {})
        if not all(vector(camera.get(k)) for k in ('position', 'target')):
            errors.append(f'{prefix}: camera needs position and target vectors')
        elif camera['position'] == camera['target']:
            errors.append(f'{prefix}: camera position equals target')
        if 'end_position' in camera and not vector(camera['end_position']):
            errors.append(f'{prefix}: invalid camera end_position')
        if not finite(camera.get('lens', 50)) or camera.get('lens', 50) <= 0:
            errors.append(f'{prefix}: camera lens must be positive')
    return errors


def fingerprint(plan, root):
    """Bind approvals to plan, local asset bytes, code and bibles, not mutable filenames."""
    files = {}
    for key, asset in plan.get('assets', {}).items():
        path = contained(root, asset['path'])
        files[f'asset:{key}'] = hashlib.sha256(path.read_bytes()).hexdigest()
        for name in asset.get('files', {}):
            related = contained(root, name)
            files[f'asset:{key}:{name}'] = hashlib.sha256(related.read_bytes()).hexdigest()
    here = Path(__file__).parent
    for path in sorted([*here.glob('*.py'), *here.glob('bibles/*.md')]):
        files[str(path.relative_to(here))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return digest({'plan': plan, 'files': files})


def storyboard(plan):
    bible = plan.get('subject_bible', {})
    lines = [f'# {plan["title"]}', '', f'Learning goal: {plan.get("learning_goal", "UNRESOLVED")}', '',
             '## Subject bible', '', *[f'- {key}: {value}' for key, value in bible.items()], '',
             '## Storyboard', '',
             '| Time | Shot | Narration | What viewers learn | Visual |', '|---|---|---|---|---|']
    t = 0
    from .presentation import resolve_theme
    for shot in plan.get('shots', []):
        end = t + shot['duration']
        cells = [f'{t:.2f}–{end:.2f}s', shot['id'], shot['narration'], shot['teaches'], shot['visual_intent'] + (' [image preserved]' if shot.get('visual_type') == 'image' else f' [background: {resolve_theme(shot)[0]}]')]
        lines.append('| ' + ' | '.join(str(c).replace('|', '\\|').replace('\n', ' ') for c in cells) + ' |')
        t = end
    if isinstance(plan.get('retention'),dict):
        from .retention import audit
        result=audit(plan)
        lines.extend(['','## Hook and reward ladder','',
                      'Timing basis: '+str(result.get('timing_basis','unresolved'))+'. These are planning checks, not audience-retention measurements.','',
                      '| Prompt time | Payoff time | New knowledge |','|---|---|---|'])
        for rung in result['rungs']:
            lines.append(f"| {rung['prompt_seconds']:.2f}s | {rung['payoff_seconds']:.2f}s | {rung['new_knowledge']} |")
        for rung in plan['retention'].get('rungs',[]):
            if isinstance(rung,dict):lines.extend(['',str(rung.get('id',''))+': visual — '+str(rung.get('visual_payoff','UNRESOLVED'))+'; audio — '+str(rung.get('audio_direction','UNRESOLVED'))])
    return '\n'.join(lines) + '\n'
