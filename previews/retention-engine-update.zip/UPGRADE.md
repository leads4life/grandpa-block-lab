# Retention and visual-direction revision workspace

This is a separate source checkpoint for a proposed revision, not a replacement for the delivered Tesla v1 Colab/media ZIP. Keep the v1 package intact. No complete v2 film or new user approvals are included. Do not overlay this onto a frozen production workspace: source and bible changes invalidate its fingerprints and reviews.

The engine adds exact-quote prompt/payoff mapping, value-gap and unpaid-promise checks, claim/source references and measured editorial review before production. New intakes require this layer. Read explainer/bibles/RETENTION.md and VISUALS.md. These checks do not predict YouTube watch time, certify accuracy or replace actual visual and auditory review.

The Tesla retention-v2 draft is estimated and intentionally blocked from full production. It has eight proposed rewards; narration and visual execution for the full revision remain pending. The richer-3D sample is delivered separately, tests one micro hook, and is not a complete implementation of that draft. No runtime weights, rendered frames, complete movie, user approval records or voice cache are included here.

Extract in a fresh directory. Standard-library checks (Python 3.11+) need no AI key or Blender:

    python -m unittest discover -s explainer/tests -v
    python -m explainer.retention explainer/projects/tesla-hw3/retention-v2/script-and-retention-draft.json

The latter passes planning structure, with a draft-timing warning. Adding --require-review correctly fails until measured frozen narration and a current editorial review exist. Do not mark those as passed without doing the review.

Optional render dependencies and model setup are in explainer/README.md and requirements.txt. The procedural sample sources are retention_showcase.py and finish_retention_showcase.py in the Tesla project; running them creates fresh narration and frames and needs those optional dependencies. Cloud rendering has been tested, actual Colab/GPU execution has not. No content is uploaded to YouTube.
