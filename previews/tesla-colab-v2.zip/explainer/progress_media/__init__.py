"""Progress media helpers; these never grant preview or finished-film approval."""
