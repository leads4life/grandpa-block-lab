# Key files

- Tesla_Claude_Handoff_Colab.ipynb — upload this same no-video ZIP.
- COLAB_AND_VOICE.md — actual contents, runtime, notebook behavior and repair instructions.
- repository/explainer/projects/tesla-hw3/build/full-v2/tesla-project-v2.json — master JSON.
- repository/explainer/projects/tesla-hw3/build/full-v2/r1/voice.wav through r8/voice.wav — actual frozen main-v2 voice.
- repository/explainer/projects/tesla-recut-v3/build/opening-edit/voice.wav — current opening VO.
- CLAUDE_CODE_PROMPT.md — audit-to-final production prompt.
- WRITTEN_FINAL_V2.md, WRITTEN_FINAL_V1.md, RECUT_V3_PROPOSAL.md — final written scripts and latest proposal.
- user_materials/ — both original user uploads unchanged and received external audit.
- handoff/ — requirements, historical status, QA/repair context and runtime guidance.
- repository/explainer/ — renderer/engine/props, tests, research, bibles and structured project data.
- MANIFEST.json — every included file hash and exact scope. No video files.
