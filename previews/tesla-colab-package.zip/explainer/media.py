"""Measured offline narration and FFmpeg validation, adapted from engine/bl_voice.py."""
from __future__ import annotations
import hashlib
import math
import os
from pathlib import Path
import subprocess
from .core import VOICE, VOICE_DELIVERY, write, digest


def run(args):
    return subprocess.run([str(a) for a in args], check=True, capture_output=True, text=True).stdout


def synthesize_paced(engine, text, voice_name, start_speed, delivery, target=179, tolerance=8, max_attempts=6):
    """Calibrate synthesis to measured speech, never to an existing video duration."""
    words=len(text.split());rate=start_speed;attempts=[];below=None;above=None
    for _ in range(max_attempts):
        samples,sr=engine.create(text,voice=voice_name,speed=rate,**delivery)[:2]
        if not len(samples) or sr<=0:raise ValueError('Empty synthesis output')
        wpm=words/(len(samples)/sr)*60
        attempts.append({'speed':rate,'words_per_minute':wpm,'seconds':len(samples)/sr})
        if words<20 or abs(wpm-target)<=tolerance:
            return samples,sr,rate,attempts
        if wpm<target:below=(rate,wpm)
        else:above=(rate,wpm)
        if below and above and below[0]<above[0]:
            # Synthesis is not linear in its speed control. Once a bracket exists,
            # stay inside it rather than oscillating between slow and fast takes.
            fraction=(target-below[1])/(above[1]-below[1])
            fraction=max(.15,min(.85,fraction))
            next_rate=below[0]+fraction*(above[0]-below[0])
        else:next_rate=max(.65,min(1.35,rate*target/wpm))
        if abs(next_rate-rate)<1e-5:break
        rate=next_rate
    raise ValueError(f'Natural-pace target not reached; rephrase or audition before proceeding: {attempts}')


def voice(shot, out):
    import numpy as np
    from scipy.io import wavfile
    from scipy.signal import resample_poly
    from kokoro_onnx import Kokoro
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    model, voices = (os.environ.get(n) for n in ('KOKORO_MODEL', 'KOKORO_VOICES'))
    if not model or not voices:
        raise ValueError('Set KOKORO_MODEL and KOKORO_VOICES to existing model files')
    engine = Kokoro(model, voices)
    samples,sr,rate,pace_attempts=synthesize_paced(engine,shot['narration'],VOICE['voice'],VOICE['speed'],VOICE_DELIVERY)
    actual_profile=dict(VOICE,speed=rate)
    samples = np.asarray(samples, dtype=np.float64)
    if not len(samples) or not np.isfinite(samples).all() or np.abs(samples).max() < 1e-5:
        raise ValueError('Narration is empty, silent or nonfinite')
    divisor = math.gcd(int(sr), 48000)
    samples = resample_poly(samples, 48000 // divisor, int(sr) // divisor)
    # Preserve speech speed. Trim only near-silence and reserve a short natural tail.
    active = np.flatnonzero(np.abs(samples) > np.abs(samples).max() * 0.005)
    samples = samples[max(0, active[0] - 2400):min(len(samples), active[-1] + 9600)]
    samples = samples * (0.7 / np.abs(samples).max())
    wavfile.write(out / 'voice.wav', 48000, (samples * 32767).astype(np.int16))
    duration = len(samples) / 48000
    evidence = {'profile': actual_profile, 'pace_attempts': pace_attempts,
                'measured_words_per_minute': len(shot['narration'].split())/duration*60, 'text': shot['narration'], 'seconds': duration,
                'delivery': VOICE_DELIVERY,
                'input_hash': digest({'text': shot['narration'], 'profile': VOICE, 'delivery': VOICE_DELIVERY, 'target_wpm': 179}),
                'sha256': hashlib.sha256((out / 'voice.wav').read_bytes()).hexdigest(),
                'model_sha256': hashlib.sha256(Path(model).read_bytes()).hexdigest(),
                'voices_sha256': hashlib.sha256(Path(voices).read_bytes()).hexdigest()}
    write(out / 'voice.json', evidence)
    return evidence


def encode(frames, audio, duration, output, fps=30, gain_db=0):
    # Normalize loudness without speeding up speech; pad only the remaining shot tail.
    run(['ffmpeg', '-v', 'error', '-y', '-framerate', fps, '-start_number', '0',
         '-i', str(Path(frames) / '%06d.png'), '-i', audio,
         '-af', f'volume={gain_db:.3f}dB,alimiter=limit=0.7:attack=2:release=60:level=false:latency=1,apad', '-t', f'{duration:.9f}',
         '-c:v', 'libx264', '-threads', '2', '-pix_fmt', 'yuv420p', '-c:a', 'aac',
         '-ar', '48000', '-movflags', '+faststart', output])


def check_video(path, duration, width, height, fps=30):
    import json
    data = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', path]))
    video = [s for s in data['streams'] if s['codec_type'] == 'video']
    audio = [s for s in data['streams'] if s['codec_type'] == 'audio']
    checks = {
        'video_format': bool(video) and (video[0]['width'], video[0]['height'], video[0]['codec_name'],
                                        video[0]['pix_fmt'], video[0]['r_frame_rate']) ==
                                       (width, height, 'h264', 'yuv420p', f'{fps}/1'),
        'audio_format': bool(audio) and audio[0]['codec_name'] == 'aac' and audio[0]['sample_rate'] == '48000',
        'duration': abs(float(data['format']['duration']) - duration) < max(0.1, 2 / fps),
        'frame_count': bool(video) and abs(int(video[0].get('nb_frames', 0)) - round(duration * fps)) <= 1,
        'no_caption_track': not any(s['codec_type'] == 'subtitle' for s in data['streams'])}
    proc = subprocess.run(['ffmpeg', '-hide_banner', '-i', str(path), '-af', 'ebur128=peak=true',
                           '-f', 'null', '-'], check=True, capture_output=True, text=True)
    log = proc.stderr
    loudness = float(log.rsplit('I:', 1)[1].split('LUFS')[0])
    peak = float(log.rsplit('Peak:', 1)[1].split('dBFS')[0])
    checks['loudness'] = abs(loudness + 14) <= 1.5
    checks['no_clipping'] = peak <= -1
    return {'checks': checks, 'passed': all(checks.values()), 'lufs': loudness, 'peak_dbfs': peak}


def assemble(videos, durations, output):
    """Decode and concatenate exact shot windows, avoiding per-file AAC padding drift."""
    inputs, filters, streams = [], [], []
    for i, (video, duration) in enumerate(zip(videos, durations)):
        inputs.extend(['-i', str(video)])
        filters.extend([f'[{i}:v]trim=duration={duration:.9f},setpts=PTS-STARTPTS[v{i}]',
                        f'[{i}:a]apad,atrim=duration={duration:.9f},asetpts=PTS-STARTPTS[a{i}]'])
        streams.append(f'[v{i}][a{i}]')
    filters.append(''.join(streams) + f'concat=n={len(videos)}:v=1:a=1[v][a]')
    run(['ffmpeg', '-v', 'error', '-y', *inputs, '-filter_complex', ';'.join(filters),
         '-map', '[v]', '-map', '[a]', '-r', '30', '-c:v', 'libx264', '-threads', '2',
         '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-ar', '48000', '-movflags', '+faststart', output])


def mix_mechanical(shot, voice_path, output, duration):
    """Quiet deterministic procedural cues, adopting Grandpa's event-timed audio pattern."""
    import numpy as np
    from scipy.io import wavfile
    sr, speech = wavfile.read(voice_path)
    if sr != 48000 or speech.ndim != 1:
        raise ValueError('Expected frozen mono 48 kHz narration')
    track = np.zeros(round(duration * sr), dtype=np.float64)
    voice_samples = speech.astype(np.float64) / 32768
    if len(voice_samples) > len(track):
        raise ValueError('Narration exceeds mixed shot length')
    track[:len(voice_samples)] = voice_samples
    for index, cue in enumerate(shot.get('sfx', [])):
        n = max(1, round(cue['duration'] * sr))
        t = np.arange(n) / sr
        seed = int(hashlib.sha256(f'{shot["id"]}:{index}'.encode()).hexdigest()[:8], 16)
        rng = np.random.default_rng(seed)
        if cue['kind'] == 'click':
            effect = (np.sin(2*np.pi*1400*t) + .3*rng.standard_normal(n)) * np.exp(-60*t)
        elif cue['kind'] == 'clunk':
            effect = (np.sin(2*np.pi*110*t) + .4*np.sin(2*np.pi*270*t)) * np.exp(-16*t)
        elif cue['kind'] == 'motor':
            effect = np.sin(2*np.pi*70*t) + .3*np.sin(2*np.pi*140*t)
        else:
            raise ValueError('Unsupported mechanical cue')
        ramp = min(n//2, 480)
        envelope = np.ones(n)
        if ramp:
            envelope[:ramp] = np.linspace(0, 1, ramp)
            envelope[-ramp:] = np.linspace(1, 0, ramp)
        # Keep effects subordinate to speech, with an additional 12 dB duck during narration.
        effect = effect / max(float(np.abs(effect).max()), 1e-9) * 10**(-27/20) * envelope
        start = round(cue['at'] * sr)
        end = min(start+n, len(track))
        if start < 0 or end <= start:
            raise ValueError('Mechanical cue lies outside shot')
        for offset in range(0, end-start, 480):
            stop = min(offset+480, end-start)
            segment = voice_samples[start+offset:min(start+stop, len(voice_samples))]
            if len(segment) and np.sqrt(np.mean(segment**2)) > .015:
                effect[offset:stop] *= .25
        track[start:end] += effect[:end-start]
    if np.abs(track).max() >= 1:
        raise ValueError('Pre-normalization mix clips')
    wavfile.write(output, sr, (track*32767).astype(np.int16))
    return output
