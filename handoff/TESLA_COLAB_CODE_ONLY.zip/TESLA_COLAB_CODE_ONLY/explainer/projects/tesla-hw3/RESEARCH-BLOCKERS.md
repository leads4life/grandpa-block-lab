# Verification required before narration lock

The supplied script contains consequential assertions about patents, deployed Tesla software, HW3 feature parity, 80% savings, safety guarantees and competitor costs. These are not verified by the supplied video reference or timestamps.

Read-only requests to patents.google.com, ir.tesla.com and www.tesla.com were denied by the environment egress proxy (CONNECT 403), before a source document could be retrieved. Network access to the primary sources is needed. No claim has been marked verified.

Independent checks: 45 mph = 66 ft/s; in 0.3 s the distance is 19.8 ft. This does not mean a continuously sensing/planning vehicle is literally blind during that interval. Compute throughput and latency are distinct quantities, so a percentage-latency gauge labeled 99.9% is misleading. A patent alone establishes neither deployed implementation nor a vehicle upgrade promise. Removing candidate trajectories does not mean ignoring road users entirely.
