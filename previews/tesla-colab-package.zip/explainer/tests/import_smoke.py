"""Actual import/render tests. Uses a downloaded CC0 specimen and self-authored format fixtures."""
from copy import deepcopy
import hashlib
from pathlib import Path
import bpy
from explainer.assets import register_model, credits
from explainer.core import read, write, validate, fingerprint
from explainer.blender_backend import render
from explainer.__main__ import contact_sheet


def main():
    here = Path(__file__).resolve().parents[1]
    source = here/'build/import-source'
    rights = read(here/'examples/licenses/avocado-rights.json')
    model = source/'Avocado.glb'
    if not model.exists() or hashlib.sha256(model.read_bytes()).hexdigest() != rights['download_sha256']:
        raise ValueError('Download the pinned CC0 Avocado specimen using examples/licenses/avocado-rights.json first')
    root = here/'build/model-selftest'
    root.mkdir(parents=True,exist_ok=True)
    # Reuse immutable registrations on rerun; never overwrite a user's assets.
    plan = read(here/'examples/contract-fixture.json')
    if (root/'plan.json').exists(): plan['assets'] = read(root/'plan.json')['assets']
    write(root/'plan.json',plan)
    if 'avocado' not in plan['assets']:
        register_model(root,'avocado',model,rights,here/'examples/licenses/avocado-source.md',1,
                       'glTF 2.0 units are meters; test instance scale is explicitly illustrative')
    plan = read(root/'plan.json')
    assert plan['assets']['avocado']['review'] == 'pending', 'Source registration must not grant visual approval'
    # Only this isolated diagnostic copy simulates a completed asset review to exercise production import.
    diagnostic = deepcopy(plan)
    diagnostic['assets'] = {'avocado': deepcopy(plan['assets']['avocado'])}
    diagnostic['assets']['avocado']['review'] = 'approved'
    shot = diagnostic['shots'][0]
    shot['components'] = [{'id':'specimen','shape':'model','asset_id':'avocado','role':'structure',
                           'position':[0,0,0],'scale':25,'move_to':[.5,0,0]}]
    shot['asset_ids'] = ['avocado']
    shot['labels'] = [{'text':'CC0 import test','position':[1.8,0,1.4],'target':'specimen','size':.2}]
    assert not validate(diagnostic,root), validate(diagnostic,root)
    output = root/fingerprint(diagnostic,root)[:16]/'glb'
    render(shot,output,640,360,30,3,samples=8,assets=diagnostic['assets'],project_root=root)
    imported = [obj for obj in bpy.data.objects if obj.name.startswith('specimen::') and obj.type == 'MESH']
    assert imported and any(mat.use_nodes for obj in imported for mat in obj.data.materials if mat)
    assert any(image.packed_file for image in bpy.data.images if image.type == 'IMAGE')
    contact_sheet(output/'frames',output/'contact-sheet.png')
    from explainer.__main__ import produce
    media_out = produce(root,diagnostic,shot,'preview')
    assert read(media_out/'qa.json')['passed']
    (root/'CREDITS.md').write_text(credits(plan))
    # Export an original textured cube to the remaining formats, then exercise their importers.
    generated = here/'build/import-generated'
    generated.mkdir(exist_ok=True)
    results = {'glb': {'passed':True, 'output':str(output), 'media_output':str(media_out)}}
    for format in ['gltf','obj','stl']:
        folder = generated/format;folder.mkdir(exist_ok=True)
        bpy.ops.wm.read_factory_settings(use_empty=True)
        bpy.ops.mesh.primitive_cube_add(size=1)
        cube=bpy.context.object;cube.name='Original calibration cube'
        mat=bpy.data.materials.new('Original fixture material');mat.use_nodes=True
        image=bpy.data.images.new('fixture',width=4,height=4)
        image.generated_color=(.1,.6,.9,1);image.filepath_raw=str(folder/'texture.png');image.file_format='PNG';image.save()
        texture=mat.node_tree.nodes.new('ShaderNodeTexImage');texture.image=image
        mat.node_tree.links.new(texture.outputs['Color'],mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
        cube.data.materials.append(mat)
        if format == 'gltf':
            path=folder/'fixture.gltf';bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLTF_SEPARATE')
        elif format == 'obj':
            path=folder/'fixture.obj';bpy.ops.wm.obj_export(filepath=str(path),path_mode='COPY')
        else:
            path=folder/'fixture.stl';bpy.ops.wm.stl_export(filepath=str(path))
        evidence=folder/'license.txt';evidence.write_text('Original synthetic calibration cube authored by this test; dedicated to CC0-1.0. No third-party geometry or textures.')
        own=deepcopy(rights);own.update({'title':f'Original {format} calibration cube','creator':'Explainer test fixture',
                                       'source_url':'https://creativecommons.org/publicdomain/zero/1.0/',
                                       'review_notes':evidence.read_text()})
        own.pop('download_sha256',None);own.pop('download_url',None)
        key='fixture_'+format
        registered=read(root/'plan.json')
        if key not in registered['assets']:
            register_model(root,key,path,own,evidence,1,'Original fixture authored as a one-meter cube')
        registered=read(root/'plan.json');test_assets=deepcopy(registered['assets'])
        for item in test_assets.values(): item['review']='approved'
        case=deepcopy(shot);case['components'][0]['asset_id']=key;case['components'][0]['scale']=1
        case['asset_ids']=[key]
        out=root/fingerprint(registered,root)[:16]/format
        render(case,out,640,360,30,3,samples=4,assets=test_assets,project_root=root)
        meshes=[o for o in bpy.data.objects if o.type=='MESH' and o.name.startswith('specimen::')]
        assert meshes
        assert (max(meshes[0].dimensions)-min(meshes[0].dimensions)) < 1e-4
        contact_sheet(out/'frames',out/'contact-sheet.png')
        results[format]={'passed':True,'output':str(out)}
    write(root/'import-results.json',results)
    assert not (root/'approvals').exists()
    assert all(a['review']=='pending' for a in read(root/'plan.json')['assets'].values())
    print('MODEL IMPORT SMOKE PASSED:',root/'import-results.json')


if __name__ == '__main__': main()
