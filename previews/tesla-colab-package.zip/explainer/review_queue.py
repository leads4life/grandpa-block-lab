"""Explicit chat-reviewed approval/rejection records; isolated from Grandpa's render queue."""
from pathlib import Path
import shutil
from .core import contained,digest,read,write
from .assets import sha


def prepare_packet(project,video,qa_path):
    project=Path(project).resolve();video=Path(video).resolve();qa_path=Path(qa_path).resolve()
    if not video.is_relative_to(project) or not qa_path.is_relative_to(project):raise ValueError('Review artifacts must be inside project')
    qa=read(qa_path)
    if not qa.get('passed') or qa.get('review')!='passed':raise ValueError('Automated and actual visual review must pass first')
    engine=Path(__file__).parent
    sources=[*engine.glob('*.py'),*engine.glob('bibles/*.md'),*project.glob('*.py'),project/'plan.json']
    packet={'status':'awaiting_user','options':['send_to_work_pool','reject'],
            'video':str(video.relative_to(project)),'qa':str(qa_path.relative_to(project)),
            'video_sha256':sha(video),'qa_sha256':sha(qa_path),
            'source_hashes':{str(p.resolve()):sha(p) for p in sources},
            'note':'Preview direction approval. Full production assets and preflight must still be completed; this is not a ready-to-run Grandpa render job.'}
    packet['id']=digest(packet)[:16];write(project/'review/decision.json',packet)
    return packet


def decide(project,choice,user_evidence,notes='',pool_root=None):
    if choice not in ('send_to_work_pool','reject') or not user_evidence.strip():raise ValueError('Record an actual user decision and its evidence')
    project=Path(project).resolve();path=project/'review/decision.json';packet=read(path)
    if packet['status']!='awaiting_user':raise ValueError('Decision already recorded')
    if choice=='reject':
        packet.update({'status':'rejected','user_evidence':user_evidence,'notes':notes});write(path,packet);return path
    for source,expected in packet['source_hashes'].items():
        if sha(source)!=expected:raise ValueError('Preview sources changed; present a fresh review')
    video=contained(project,packet['video']);qa=contained(project,packet['qa'])
    if sha(video)!=packet['video_sha256'] or sha(qa)!=packet['qa_sha256']:raise ValueError('Reviewed artifacts changed')
    output=(Path(pool_root) if pool_root is not None else Path(__file__).parent/'work_pool')/packet['id']
    if output.exists():raise ValueError('Work item already exists')
    output.mkdir(parents=True)
    try:
        shutil.copy2(video,output/'approved-preview.mp4');shutil.copy2(qa,output/'preview-qa.json')
        shutil.copy2(project/'plan.json',output/'plan.json')
        snapshot=output/'source-snapshot';snapshot.mkdir()
        for source in packet['source_hashes']:
            src=Path(source)
            if src.is_relative_to(Path(__file__).parent):relative=src.relative_to(Path(__file__).parent)
            else:relative=Path('external-source')/src.name
            target=snapshot/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
        write(output/'manifest.json',{'kind':'explainer_project','status':'approved_direction_requires_production_preflight',
               'project':str(project),'review':packet,'user_evidence':user_evidence,
               'next_steps':'Complete the remaining source-backed chapters/assets, fit frozen narration, self-check, then render the authorized full video. Preserve approved visual direction; ask about material creative changes.'})
    except Exception:
        shutil.rmtree(output);raise
    packet.update({'status':'sent_to_work_pool','user_evidence':user_evidence,'work_item':str(output)})
    write(path,packet);return output
