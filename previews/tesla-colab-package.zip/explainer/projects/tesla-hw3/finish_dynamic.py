"""Encode a continuously rendered 3D review with restrained labels, not held image sections."""
from pathlib import Path
import subprocess
from PIL import Image,ImageDraw,ImageFont
from explainer.core import read,write
from explainer.media import mix_mechanical,check_video
from explainer.turn_motion import pose
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/dynamic-v3';t=read(OUT/'timing.json');NF=t['frames'];SECONDS=t['seconds'];W,H=960,540
expected={f'{i:06d}.png' for i in range(NF)};actual={p.name for p in (OUT/'raw').glob('*.png')}
if actual!=expected:raise ValueError(f'Incomplete render: {len(actual)} / {NF}')
fontdir=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False):return ImageFont.truetype(str(fontdir/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
# Denoise the rendered motion, upscale, then add crisp technical labels.
filtered=OUT/'filtered';filtered.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-start_number','0','-i',str(OUT/'raw/%06d.png'),
 '-vf','nlmeans=s=7:p=7:r=9,hqdn3d=2:2:4:4,scale=960:540:flags=lanczos','-start_number','0',str(filtered/'%06d.png')],check=True)
frames=OUT/'frames';frames.mkdir(exist_ok=True)
for i in range(NF):
 with Image.open(filtered/f'{i:06d}.png') as raw:im=raw.convert('RGBA')
 panel=Image.new('RGBA',(W,H));d=ImageDraw.Draw(panel)
 d.rectangle((0,0,W,76),fill=(6,17,29,205));d.rectangle((0,H-33,W,H),fill=(6,17,29,180))
 d.text((31,18),'Planning a left turn',font=font(24,True),fill='#f0f7ff')
 phase=pose(i/30,SECONDS)['phase'];color='#efbd70' if phase=='wait' else '#62d8f0'
 label='YIELD' if phase=='wait' else 'FOLLOW ROUTE'
 d.rounded_rectangle((716,18,929,57),radius=8,fill=(9,26,41,235),outline=color,width=2)
 d.text((734,29),label,font=font(15,True),fill=color)
 d.text((32,H-23),'Illustrative traffic interaction · not a reconstruction of Tesla’s software',font=font(11),fill='#c0d3e0')
 im=Image.alpha_composite(im,panel).convert('RGB');im.save(frames/f'{i:06d}.png')
 if i in [0,round(3*30),round(7*30),round(10*30),round(13*30),NF-1]:im.save(OUT/f'check-{i:06d}.jpg',quality=95)
sfx=[{'kind':'motor','at':6.7,'duration':SECONDS-6.7-.35,'purpose':'Quiet illustrative movement cue, not a vehicle recording.'}]
audio=mix_mechanical({'id':'dynamic_turn','sfx':sfx},OUT/'voice.wav',OUT/'mix.wav',SECONDS)
output=OUT/'tesla-dynamic-3d-preview.mp4';gain=0;attempts=[]
for _ in range(4):
 subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-start_number','0','-i',str(frames/'%06d.png'),'-i',str(audio),
  '-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:attack=2:release=60:level=false:latency=1,apad','-t',str(SECONDS),
  '-c:v','libx264','-threads','2','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-movflags','+faststart',str(output)],check=True)
 qa=check_video(output,SECONDS,W,H);attempts.append(dict(qa))
 if qa['passed']:break
 gain+=-14-qa['lufs']
if not qa['passed']:raise ValueError(str(qa))
qa.update({'review':'pending','attempts':attempts,'scene_checks':read(OUT/'scene-qa.json'),'voice':t['voice'],
 'static_image_sections':False,'camera_motion':'Rendered in the 3D scene, no held-plate pan/zoom sections',
 'render_size':[t['width'],t['height']],'output_size':[W,H],'scope':'Draft continuous-3D direction review, not full film'})
write(OUT/'qa.json',qa)
with Image.open(frames/f'{round(10*30):06d}.png') as im:im.save(OUT/'poster.jpg',quality=94)
sheet=Image.new('RGB',(960,720),'#081725')
for j,sec in enumerate([0,2,4,6,8,10,13,SECONDS-1/30]):
 with Image.open(frames/f'{round(sec*30):06d}.png') as im:sheet.paste(im.resize((320,180)),((j%3)*320,(j//3)*240))
sheet.save(OUT/'review-sheet.jpg',quality=95)
print('CONTINUOUS 3D PREVIEW READY:',output,flush=True)
