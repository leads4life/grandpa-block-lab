"""Run from a Colab notebook to create the isolated, matching render runtime."""
from pathlib import Path
import os,subprocess,sys

ROOT=Path(__file__).resolve().parents[2]

def run(args):subprocess.run([str(a) for a in args],check=True)

def main():
    if os.geteuid()==0:
        run(['apt-get','update','-qq'])
        run(['apt-get','install','-y','-qq','ffmpeg','fonts-dejavu-core','libgl1','libegl1','libxrender1','libxi6','libxfixes3','libxkbcommon0','libsm6','libice6','libgomp1'])
    run([sys.executable,'-m','pip','install','-q','uv'])
    run([sys.executable,'-m','uv','python','install','3.13'])
    runtime=ROOT/'.colab-render-venv'
    run([sys.executable,'-m','uv','venv','--python','3.13',runtime])
    python=runtime/'bin/python'
    run([sys.executable,'-m','uv','pip','install','--python',python,'-r',ROOT/'explainer/colab/render-requirements.txt'])
    run([python,'-m','explainer.colab.runtime','verify'])
    print('RENDER_PYTHON =',python)

if __name__=='__main__':main()
