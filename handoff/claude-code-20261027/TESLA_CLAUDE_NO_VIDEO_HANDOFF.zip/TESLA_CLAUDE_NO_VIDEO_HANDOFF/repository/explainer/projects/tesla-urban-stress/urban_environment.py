"""Original industrial-neighborhood set: procedural surfaces, graphics and props."""
import math,random
import bpy,bmesh
from mathutils import Vector
from explainer.visual_tools import material,line
from explainer.vehicle_prop import build_vehicle
from . import rich_scene as rig

SEED=261026


def cube(name,location,dimensions,mat,parent=None,bevel=.04):
    # Data API avoids repeated whole-scene operator updates in the dense set.
    x,y,z=(v/2 for v in dimensions)
    vertices=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
    faces=[(3,2,1,0),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(vertices,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(obj);obj.location=location;obj.parent=parent;obj.data.materials.append(mat)
    if bevel:
        bm=bmesh.new();bm.from_mesh(mesh)
        result=bmesh.ops.bevel(bm,geom=list(bm.edges),offset=min(bevel,min(dimensions)*.4),segments=2,affect='EDGES',clamp_overlap=True)
        for face in result['faces']:face.smooth=True
        bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free();mesh.update()
    return obj


def rough(name,color,roughness=.8):
    m=material(name,(*color,1));p=m.node_tree.nodes['Principled BSDF'];p.inputs['Metallic'].default_value=0;p.inputs['Roughness'].default_value=roughness
    return m


def weathered(name,low,high,scale=8,bump=.012):
    m=rough(name,low);n=m.node_tree.nodes;l=m.node_tree.links;p=n['Principled BSDF']
    coords=n.new('ShaderNodeTexCoord');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=scale;noise.inputs['Detail'].default_value=3
    l.new(coords.outputs['Object'],noise.inputs['Vector']);ramp=n.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position=.18;ramp.color_ramp.elements[0].color=(*low,1)
    ramp.color_ramp.elements[1].position=.8;ramp.color_ramp.elements[1].color=(*high,1)
    l.new(noise.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs['Color'],p.inputs['Base Color'])
    normal=n.new('ShaderNodeBump');normal.inputs['Strength'].default_value=.28;normal.inputs['Distance'].default_value=bump
    l.new(noise.outputs['Fac'],normal.inputs['Height']);l.new(normal.outputs['Normal'],p.inputs['Normal'])
    return m


def brick(name,red=True):
    m=rough(name,(.2,.08,.04));n=m.node_tree.nodes;l=m.node_tree.links;p=n['Principled BSDF']
    coords=n.new('ShaderNodeTexCoord');separate=n.new('ShaderNodeSeparateXYZ');combine=n.new('ShaderNodeCombineXYZ')
    l.new(coords.outputs['Object'],separate.inputs[0]);l.new(separate.outputs['X'],combine.inputs['X']);l.new(separate.outputs['Z'],combine.inputs['Y']);l.new(separate.outputs['Y'],combine.inputs['Z'])
    blocks=n.new('ShaderNodeTexBrick');blocks.inputs['Scale'].default_value=1.8;blocks.inputs['Mortar Size'].default_value=.025
    blocks.inputs['Brick Width'].default_value=.45;blocks.inputs['Row Height'].default_value=.22
    blocks.inputs['Color1'].default_value=(.28,.105,.055,1) if red else (.17,.19,.18,1)
    blocks.inputs['Color2'].default_value=(.10,.038,.022,1) if red else (.075,.095,.10,1)
    blocks.inputs['Mortar'].default_value=(.028,.025,.021,1);l.new(combine.outputs[0],blocks.inputs['Vector'])
    grime=n.new('ShaderNodeTexNoise');grime.inputs['Scale'].default_value=.8;grime.inputs['Detail'].default_value=3;l.new(coords.outputs['Object'],grime.inputs['Vector'])
    stain=n.new('ShaderNodeValToRGB');stain.color_ramp.elements[0].color=(.18,.16,.13,1);stain.color_ramp.elements[1].color=(.9,.88,.8,1)
    l.new(grime.outputs['Fac'],stain.inputs[0]);mix=n.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=.6
    l.new(blocks.outputs['Color'],mix.inputs[1]);l.new(stain.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],p.inputs['Base Color'])
    relief=n.new('ShaderNodeBump');relief.inputs['Strength'].default_value=.35;relief.inputs['Distance'].default_value=.025
    l.new(blocks.outputs['Fac'],relief.inputs['Height']);l.new(relief.outputs['Normal'],p.inputs['Normal'])
    return m


def palette():
    m=rig._base_palette()
    m['road']=weathered('Worn asphalt',(.022,.029,.033),(.085,.095,.097),14,.009)
    m['paving']=weathered('Stained concrete',(.16,.17,.16),(.30,.31,.28),3,.012)
    m['building']=brick('Oxidized brick');m['old_brick']=brick('Soot-dark masonry',False)
    m['paint']=weathered('Chipped road paint',(.045,.052,.055),(.57,.53,.38),30,.002)
    m['metal']=weathered('Scuffed metal',(.035,.05,.052),(.13,.17,.16),12,.008)
    m['rust']=weathered('Rust and peeling enamel',(.055,.045,.028),(.27,.105,.035),9,.01)
    m['plaster']=weathered('Faded plaster',(.16,.145,.11),(.39,.36,.28),1.7,.012)
    m['shutter']=weathered('Scarred shop shutters',(.09,.12,.13),(.24,.27,.25),18,.009)
    m['dark_window']=rough('Dark glazing',(.018,.033,.036),.28)
    m['patch']=weathered('Road repair aggregate',(.013,.018,.019),(.044,.052,.053),23,.008)
    m['wet']=rough('Damp road scars',(.012,.019,.023),.35)
    m['paper']=weathered('Weathered poster paper',(.29,.25,.17),(.68,.62,.43),17,.001)
    m['graffiti']=[rough('Original wall paint '+str(i),c) for i,c in enumerate([(.035,.46,.46),(.68,.17,.32),(.85,.53,.12),(.62,.67,.49)])]
    m['ink']=rough('Paint shadow',(.008,.012,.014));m['leaves']=rough('Urban foliage',(.075,.12,.065))
    return m


def studio(scene,m):
    rig._base_studio(scene,m)
    for obj in scene.objects:
        if obj.type=='LIGHT':
            if obj.name=='Soft key':obj.data.color=(.72,.82,1);obj.data.energy=4700
            elif obj.name=='Cool rim':obj.data.color=(.4,.59,.78);obj.data.energy=5400
            elif obj.name=='Warm fill':obj.data.color=(1,.61,.32);obj.data.energy=3700


def lettering(name,text,location,size,mat,parent=None,tilt=0,offset=0):
    data=bpy.data.curves.new(name,'FONT');data.body=text;data.size=size;data.align_x='CENTER';data.align_y='CENTER';data.offset=offset;data.resolution_u=3
    data.font=bpy.data.fonts.load('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-BoldOblique.ttf',check_existing=True)
    obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);obj.parent=parent;obj.location=location;obj.rotation_euler=(math.pi/2,tilt,0);obj.data.materials.append(mat)
    return obj


def graffiti(parent,m,text='SHIFT',seed=1,scale=1):
    rng=random.Random(seed);color=m['graffiti'][seed%len(m['graffiti'])];y=-3.135;z=1.05*scale;size=.9*scale;tilt=rng.uniform(-.11,.11)
    lettering('Original tag outline',text,(.025,y+.004,z-.015),size,m['ink'],parent,tilt,.045*scale)
    lettering('Original tag paint',text,(0,y,z),size,color,parent,tilt)
    for i in range(5):
        x=rng.uniform(-1.5,1.5)*scale;top=rng.uniform(.75,1.1)*scale;bottom=top-rng.uniform(.15,.48)*scale
        o=line('Original paint drip',[(x,y-.002,top),(x+.012,y-.002,bottom)],.012*scale,color);o.parent=parent
    vertices=[];faces=[]
    for i in range(38):
        x=rng.uniform(-2.0,2.0)*scale;zz=rng.uniform(.45,1.7)*scale;r=rng.uniform(.01,.055)*scale;index=len(vertices)
        vertices.append((x,y-.001,zz))
        for j in range(9):
            angle=math.tau*j/9;vertices.append((x+r*math.cos(angle),y-.001,zz+r*math.sin(angle)))
        for j in range(9):faces.append((index,index+1+j,index+1+(j+1)%9))
    mesh=bpy.data.meshes.new('Original spray flecks');mesh.from_pydata(vertices,[],faces);mesh.update();obj=bpy.data.objects.new('Original spray flecks',mesh);bpy.context.collection.objects.link(obj);obj.parent=parent;obj.data.materials.append(color)


def facade(m,x,y,height,index,orientation):
    root=rig.empty('Urban storefront '+str(index));root.location=(x,y,.06);root.rotation_euler.z=orientation
    masonry=m['building'] if index%2 else m['old_brick'];cube('Masonry block',(0,0,height/2),(5.3,6,height),masonry,root,.035)
    cube('Chipped base course',(0,-3.035,.36),(5.3,.09,.65),m['plaster'],root,.015)
    cube('Roof parapet',(0,0,height+.12),(5.6,6.3,.25),m['metal'],root,.025)
    cube('Roof tank',(1.2,.7,height+.55),(.9,1.1,.85),m['metal'],root,.03)
    for floor in range(max(0,int((height-2.8)/2.2))):
        z=3.7+floor*2.2
        for col in [-1,0,1]:
            xx=col*1.52;cube('Window stone surround',(xx,-3.035,z),(1.06,.13,1.45),m['plaster'],root,.012)
            cube('Recessed window',(xx,-3.11,z),(.88,.025,1.24),m['amber'] if (index+floor+col)%4==0 else m['dark_window'],root,.008)
            cube('Window mullion',(xx,-3.13,z),(.045,.025,1.24),m['metal'],root,.003)
            cube('Window sill',(xx,-3.16,z-.73),(1.2,.28,.10),m['metal'],root,.012)
        if floor==0:
            cube('Old air conditioner',(1.5,-3.4,z-.65),(.7,.65,.48),m['shutter'],root,.03)
            for zz in [-.12,0,.12]:cube('AC grille',(1.5,-3.735,z-.65+zz),(.55,.02,.026),m['metal'],root,0)
    if index%3==0:
        cube('Shop glazing',(0,-3.04,1.45),(3.65,.08,2.45),m['dark_window'],root,.025)
        for xx in [-1.86,0,1.86]:cube('Shop frame',(xx,-3.11,1.45),(.08,.08,2.55),m['metal'],root,.01)
        for i in range(8):cube('Faded awning stripe',(-2.1+i*.6,-3.5,2.8),(.6,1.2,.12),m['rust'] if i%2 else m['plaster'],root,.01)
        lettering('Fictional market sign','NIGHT MARKET',(0,-3.13,3.0),.34,m['paper'],root)
    else:
        cube('Shutter recess',(0,-3.04,1.45),(3.65,.08,2.5),m['metal'],root,.02)
        for i in range(15):cube('Bent shutter slat',(0,-3.09, .25+i*.165),(3.55,.06,.13),m['shutter'],root,.012)
        cube('Store sign board',(0,-3.13,2.95),(4.45,.12,.55),m['metal'],root,.025)
        lettering('Fictional repair sign',['LOCAL REPAIR','TIRES / SERVICE','ELECTRIC WORKS'][index%3],(0,-3.205,2.95),.33,m['paper'],root)
        graffiti(root,m,['SHIFT','FLOW','LATE','NORTH'][index%4],index+SEED)
    cube('Side door',(2.18,-3.07,1.1),(.65,.08,2),m['rust'],root,.015)
    for i in range(3):
        poster=cube('Layered old flyer',(-2.27+i*.13,-3.086-i*.002,1.05+i*.25),(.42,.01,.59),m['paper'],root,.003);poster.rotation_euler.y=.06*(i-1)
    if index%3==1:
        for level in [3.0,5.2]:
            if level>height-1:continue
            cube('Fire escape platform',(-.6,-3.55,level),(2.3,1.0,.10),m['metal'],root,.01)
            for xx in [-1.7,-.6,.5]:cube('Fire escape baluster',(xx,-4,level+.5),(.035,.035,1),m['rust'],root,.004)
            cube('Fire escape handrail',(-.6,-4,level+1),(2.3,.045,.045),m['metal'],root,.005)
            for rung in range(8):cube('Escape stair tread',(-1.45+rung*.24,-3.5,level-.15-rung*.25),(.3,.75,.05),m['metal'],root,.005)
    return root


def polygon(name,points,z,mat):
    mesh=bpy.data.meshes.new(name);mesh.from_pydata([(x,y,z) for x,y in points],[],[tuple(range(len(points)))]);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(mat);return o


def road_scars(m,rng):
    for i,(x,y) in enumerate([(-2.7,-12.0),(2.7,-4.8),(-2.4,7.5),(1.4,11.5),(-.2,-17),(6.8,.8),(-8,2)]):
        rx=rng.uniform(.5,1.0);ry=rng.uniform(.7,1.8);points=[]
        for j in range(18):
            a=math.tau*j/18;points.append((x+rx*math.cos(a)*rng.uniform(.9,1.1),y+ry*math.sin(a)*rng.uniform(.9,1.1)))
        polygon('Irregular asphalt repair',points,.102+i*.00005,m['patch'] if i%3 else m['wet'])
        crack=[(x+rx*.8,y-ry,.109),(x+rx*.9,y-ry*.2,.109),(x+rx*1.2,y+ry*.4,.109),(x+rx*.9,y+ry,.109)]
        line('Hairline repair edge',crack,.009,m['ink'])
    for i in range(7):
        x=rng.uniform(-3.5,3.5);y=rng.choice([-1,1])*rng.uniform(6,20)
        points=[(x,y,.109)]
        for j in range(5):points.append((points[-1][0]+rng.uniform(-.22,.22),points[-1][1]+rng.uniform(.15,.5),.109))
        line('Asphalt crack',points,.009,m['ink'])
    bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.39,depth=.015,location=(-.4,-12.2,.106));o=bpy.context.object;o.name='Street manhole';o.data.materials.append(m['metal'])
    for i in range(6):cube('Manhole rib',(-.4,-12.45+i*.1,.116),(.58,.018,.008),m['rust'],bevel=0)


def street(m,extended=False):
    rng=random.Random(SEED);setback=11.5 if extended else 17.0
    cube('Continuous urban ground',(0,0,-.12),(220,220,.32),m['paving'],bevel=0)
    cube('Through avenue',(0,0,.065),(8.4,180,.07),m['road'],bevel=0)
    cube('Cross avenue',(0,0,.067),(180,8.4,.07),m['road'],bevel=0)
    for sign in [-1,1]:
        cube('Walkable pavement',(sign*6.6,0,.065),(4.8,180,.07),m['paving'],bevel=0)
        for lo,hi in [(-45,-5.8),(-4.2,4.2),(5.8,45)]:cube('Worn curb',(sign*4.24,(lo+hi)/2,.13),(.13,hi-lo,.12),m['paving'],bevel=.022)
        for y in range(-30,32,2):
            if abs(y)>5.7:line('Pavement expansion joint',[(sign*4.4,y,.104),(sign*8.5,y,.104)],.006,m['ink'])
        for y in [-10.7,9.3]:
            cube('Curb drain',(sign*3.95,y,.109),(.4,.7,.015),m['metal'],bevel=.01)
            for n in range(5):cube('Drain slot',(sign*3.95,y-.25+n*.125,.12),(.31,.036,.01),m['ink'],bevel=0)
        for y in [-24.0,12.5]:
            pole=rig.empty('Avenue light');pole.location=(sign*6.3,y,.1)
            cube('Weathered lamp shaft',(0,0,2.9),(.13,.13,5.8),m['metal'],pole,.015)
            bar=line('Bent streetlight arm',[(0,0,5.7),(-sign*.55,0,6.05),(-sign*1.05,0,6.05)],.065,m['rust']);bar.parent=pole
            cube('Streetlight head',(-sign*1.05,0,6.02),(.65,.3,.12),m['amber'],pole,.035)
        for y in [-22,-2,18]:
            cube('Utility pole',(sign*7.5,y,3.6),(.18,.18,7.0),m['wood'],bevel=.02)
            cube('Utility crossarm',(sign*7.5,y,6.8),(1.3,.14,.13),m['metal'])
        for y0,y1 in [(-22,-2),(-2,18)]:
            for dx in [-.4,.4]:
                points=[(sign*7.5+dx,y0+(y1-y0)*j/12,6.9-.5*math.sin(math.pi*j/12)) for j in range(13)]
                line('Sagging utility cable',points,.018,m['ink'])
        for y in [-19,17]:
            cube('Street litter bin',(sign*7.1,y,.55),(.7,.65,.9),m['metal'],bevel=.07)
            cube('Bin rim',(sign*7.1,y,1.04),(.78,.72,.12),m['rust'],bevel=.025)
            for i in range(3):
                paper=cube('Discarded paper',(sign*(6.5+i*.4),y+.6+i*.2,.114),(.23,.35,.009),m['paper'],bevel=0);paper.rotation_euler.z=rng.uniform(-1,1)
        for i,y in enumerate([-30,-23,-16,-9,9,16,23,30]):
            height=(3.8 if y==-9 else 5.5 if y==-16 else 6.3) if y<0 else [8.7,11.0,9.3,12.0][i%4]
            facade(m,sign*setback,y,height,(i+1)+(0 if sign<0 else 12),-sign*math.pi/2)
        for i,x in enumerate([-30,-22,-14,14,22,30]):
            facade(m,x,sign*setback,5.8 if sign<0 else 8.4,35+i+(0 if sign<0 else 7),0 if sign>0 else math.pi)
    for y in range(-35,36,3):
        if abs(y)>4.4:cube('Faded avenue center dash',(0,y,.111),(.09,1.1,.012),m['paint'],bevel=0)
    for x in range(-35,36,3):
        if abs(x)>4.4:cube('Faded cross-street dash',(x,0,.113),(1.1,.09,.012),m['paint'],bevel=0)
    for x in [-3.2,-2.1,-1,.1,1.2,2.3,3.4]:
        for sign in [-1,1]:cube('Worn but readable crosswalk',(x,sign*5,.116),(.48,1,.014),m['paint'],bevel=0)
    road_scars(m,rng)
    # Clutter remains outside the crossing and the x=5.2m bicycle corridor.
    for sign,y in [(-1,-17),(1,13)]:
        cube('Scratched dumpster',(sign*8.0,y,.72),(1.1,1.8,1.25),m['metal'],bevel=.07)
        lid=cube('Uneven dumpster lid',(sign*8.0,y,1.39),(1.2,1.9,.11),m['rust'],bevel=.025);lid.rotation_euler.x=.08
        for i in range(3):cube('Flattened delivery carton',(sign*(7.7+i*.22),y-1.2,.13+i*.04),(.7,.45,.05),m['paper'],bevel=.008)
    for i,(x,y) in enumerate([(-6.9,-28),(6.9,25)]):
        parked=build_vehicle('Parked neighborhood car '+str(i),(.18,.14,.075,1));parked.location=(x,y,.1);parked.rotation_euler.z=math.pi if x<0 else 0
    print('URBAN SET BUILT',len(bpy.context.scene.objects),'original objects; protected crossings and bicycle corridor',flush=True)


def house(name,x,y,z,m,scale=1,parent=None):
    # Miniature future context keeps the original envelope, with urban materials.
    cube(name,(x,y,z+1.5*scale),(3*scale,2.7*scale,3*scale),m['building'],parent,.025*scale)
    cube(name+' parapet',(x,y,z+3.08*scale),(3.18*scale,2.9*scale,.18*scale),m['metal'],parent,.015)
    for row in [0,1]:
        for col in [-1,0,1]:cube(name+' old window',(x+col*.8*scale,y-1.36*scale,z+(.85+row*1.25)*scale),(.48*scale,.035,.72*scale),m['amber'] if col==0 else m['dark_window'],parent,.008)
    cube(name+' shutter',(x,y-1.38*scale,z+.5*scale),(.7*scale,.035,scale),m['shutter'],parent,.01)
