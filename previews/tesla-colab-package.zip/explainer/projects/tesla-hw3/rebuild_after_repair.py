"""Re-encode only the repaired chapter, then reassemble and verify the whole film."""
from pathlib import Path
import hashlib,importlib,json,shutil

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v1'

def main():
    producer=importlib.import_module('explainer.projects.tesla-hw3.produce_film')
    media=importlib.import_module('explainer.media')
    manifest=producer.read(OUT/'manifest.json');folder=OUT/'05_intersection'
    repair=producer.read(folder/'surface-repair.json');assert repair['passed']
    backup=folder/'before-surface-repair';backup.mkdir(exist_ok=True)
    for name in ['chapter.mp4','qa.json']:
        if not (backup/name).exists():shutil.copy2(folder/name,backup/name)
    qa=producer.read(folder/'qa.json');qa.update(passed=False,review='surface_repair_reencoding')
    producer.write(folder/'qa.json',qa)
    producer.encode(manifest['shots'][4])
    qa=producer.read(folder/'qa.json');qa['surface_repair']=repair;producer.write(folder/'qa.json',qa)
    movie=OUT/'tesla-planning-complete.mp4';original=OUT/'before-surface-repair.mp4'
    if not original.exists():shutil.copy2(movie,original)
    videos=[ROOT/'build/opening-v2/tesla-opening-v2.mp4']+[OUT/s['id']/'chapter.mp4' for s in manifest['shots'][1:]]
    media.assemble(videos,[s['seconds'] for s in manifest['shots']],movie)
    qa=media.check_video(movie,manifest['seconds'],manifest['width'],manifest['height']);assert qa['passed'],qa
    qa.update(review='pending_repaired_final_video_inspection',scope='Complete film',chapters=13,
              surface_repair={'chapter':'05_intersection','frame_count':len(repair['frames']),'geometry_or_narration_changed':False},
              video_sha256=hashlib.sha256(movie.read_bytes()).hexdigest())
    producer.write(OUT/'final-qa.json',qa)
    importlib.import_module('explainer.projects.tesla-hw3.final_review_packet').main()
    producer.write(OUT/'pipeline-state.json',{'stage':'repaired_complete_media_pending_final_inspection','video':str(movie),'automatic_publication':False})
    print('REPAIRED FULL FILM CHECKED; FINAL INSPECTION PENDING',movie,flush=True)

if __name__=='__main__':main()
