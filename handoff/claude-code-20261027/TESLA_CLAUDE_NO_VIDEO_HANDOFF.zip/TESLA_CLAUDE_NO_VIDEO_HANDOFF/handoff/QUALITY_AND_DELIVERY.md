# Quality and delivery checklist

These are acceptance questions, not evidence that the future film has already passed.

1. The first 8s establish a concrete question and visible stakes; an early useful reward arrives by about 20–30s. Later promises have specific visible/spoken payoffs. Timing comes from frozen actual narration. No retention-performance claims without audience data.
2. The hardware-first framing remains truthful before and after the reveal. No invented capacity meter, HW3 deployment promise,0FLOPS road user, panic threshold or phantom-braking diagnosis.
3. The driving mechanism, graph choices and evaluation factors remain causally connected. A comparison shows what changes, not just a new camera angle. All old source claims and new additions have an explicit evidence status.
4. Every section uses appropriate moving3D. The set is rich but readable; the explanation survives phone-sized viewing. Avoid repeated overhead shots, bare platforms, arbitrary pulsing bars, generic orbits and held-image filler.
5. Narration sounds like spoken explanation. The chosen voice is retained, actual delivery measured and pauses purposeful. No time stretching, music, presenter or narration captions. Mechanical cues are quiet and attached to visible action.
6. Camera paths avoid roofs, poles and close-up body intersections. Inspect first/middle/payoff, all transitions and risky frames. Bound checks, ray checks and temporal decoding supplement actual visual judgment.
7. Source/model/voice hashes match the frozen production version. Resume only compatible frames. State native resolution separately from export resolution; a 960×540 review copy is not a native 1080p master.
8. Run existing tests after logic changes. Validate all media, audio levels/peaks, codecs, durations, frame counts and complete decode. Open chronological actual decoded sequences throughout the final film and inspect details at full size. Document what was actually heard or seen, pending decisions and untested GPU/Colab execution.
9. Provide actual moving 30-second sneak peeks as inspected footage becomes available. Never replace a requested preview with stills or say a render is active without checking its process and output.
10. Final deliverables: full MP4; script/storyboard/source ledger; measured hook/reward ladder; audit and repair history; master JSON; source/props/frozen audio and credits; portable ZIP and render instructions; checksums; honest handoff. No YouTube upload is authorized.
