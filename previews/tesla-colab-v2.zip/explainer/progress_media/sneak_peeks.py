"""Build checked 30-second progress windows from existing native Tesla v2 frames."""
from pathlib import Path
from importlib import import_module
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,time
from explainer.core import read,write
from explainer.media import mix_mechanical,check_video

ROOT=Path(__file__).resolve().parents[1]/'projects/tesla-hw3'
OUT=ROOT/'build/full-v2';PEEKS=OUT/'sneak-peeks'


def windows(total,size=900):
    if not isinstance(total,int) or not isinstance(size,int) or total<=0 or size<=0:raise ValueError('Positive frame counts required')
    if total<=size:return [(0,total)]
    starts=list(range(0,total-size+1,size))
    if starts[-1]+size<total:starts.append(total-size)
    return [(start,start+size) for start in starts]


def chunks(shots,start,end):
    cursor=0;result=[]
    for shot in shots:
        stop=cursor+shot['frames'];lo=max(start,cursor);hi=min(end,stop)
        if hi>lo:result.append((shot,lo-cursor,hi-cursor))
        cursor=stop
    if sum(b-a for _,a,b in result)!=end-start:raise ValueError('Preview window lies outside production')
    return result


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ready(parts):
    return all((OUT/shot['id']/'raw'/f'{f:06d}.png').is_file() for shot,a,b in parts for f in range(a,b))


def full_audio(shot):
    # Separate files avoid racing the producer's final mix. Frozen voice is shared.
    folder=PEEKS/'audio';folder.mkdir(exist_ok=True);target=folder/(shot['id']+'.wav')
    stamp=folder/(shot['id']+'.json');expected={'voice_sha256':shot['voice_sha256'],'helper_sha256':sha(__file__)}
    if target.exists() and stamp.exists() and read(stamp)==expected:return target
    assert sha(OUT/shot['id']/'voice.wav')==shot['voice_sha256']
    cues=[]
    if shot['mode']=='decision':
        at=next(g['start'] for g in shot['thought_groups'] if 'A pedestrian' in g['text'])
        cues=[{'kind':'motor','at':at,'duration':6,'purpose':'Same quiet opposing-traffic cue as the frozen production.'}]
    elif shot['mode']=='resolve':cues=[{'kind':'motor','at':6.7,'duration':shot['seconds']-7,'purpose':'Same quiet turn cue as the frozen production.'}]
    mix_mechanical({'id':shot['id'],'sfx':cues},OUT/shot['id']/'voice.wav',target,shot['seconds'])
    write(stamp,expected)
    return target


def build(index,start,end,parts):
    from PIL import Image,ImageDraw,ImageFont
    import numpy as np
    from scipy.io import wavfile
    producer=import_module('explainer.projects.tesla-hw3.produce_revision');producer.verify_preflight()
    folder=PEEKS/f'{index:02d}';folder.mkdir(exist_ok=True);video=folder/f'tesla-v2-sneak-peek-{index:02d}.mp4'
    pieces=[];poses={};source_hashes={}
    for shot,a,b in parts:
        rate,samples=wavfile.read(full_audio(shot));assert rate==48000 and samples.ndim==1
        pieces.append(samples[a*1600:b*1600]);poses[shot['id']]=read(OUT/shot['id']/'poses.json')
        source_hashes[shot['id']]=sha(OUT/shot['id']/'render-source.json')
    samples=np.concatenate(pieces);assert len(samples)==(end-start)*1600
    audio=folder/'excerpt.wav';wavfile.write(audio,48000,samples)
    width,height=960,540;gain=1.;native_hashes=[];luma=[]
    for attempt in range(4):
        command=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-framerate','30','-i','pipe:0','-i',str(audio),'-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:level=false:latency=1','-t',str((end-start)/30),'-c:v','libx264','-threads','1','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-movflags','+faststart',str(video)]
        with (folder/f'encode-{attempt}.log').open('wb') as log:
            process=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=log)
            try:
                native_hashes=[];luma=[]
                for shot,a,b in parts:
                    for f in range(a,b):
                        path=OUT/shot['id']/'raw'/f'{f:06d}.png'
                        with Image.open(path) as im:
                            im.load();native_hashes.append(hashlib.sha256(im.tobytes()).hexdigest())
                            luma.append(float(np.asarray(im.resize((64,36)).convert('L')).mean()))
                            decorated=producer.decorate(im,poses[shot['id']][str(f)],shot['mode'])
                        process.stdin.write(decorated.tobytes())
                process.stdin.close();assert process.wait()==0,(folder/f'encode-{attempt}.log').read_text()
            except BaseException:
                process.kill();process.wait();raise
        qa=check_video(video,(end-start)/30,width,height)
        if qa['passed']:break
        gain+=-14-qa['lufs']
    assert qa['passed'],qa
    assert min(luma)>4,'Unexpected nearly black native frame'
    # Decode the actual encoded preview for chronological visual inspection.
    decoded=folder/'decoded';decoded.mkdir(exist_ok=True)
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-vf',"select='not(mod(n,30))',scale=480:270",'-fps_mode','vfr','-start_number','0',str(decoded/'%03d.jpg')],check=True)
    frames=sorted(decoded.glob('*.jpg'));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
    for offset in range(0,len(frames),12):
        selected=frames[offset:offset+12];sheet=Image.new('RGB',(1440,((len(selected)+2)//3)*296),'#081420');draw=ImageDraw.Draw(sheet)
        for j,path in enumerate(selected):
            x=j%3*480;y=j//3*296
            with Image.open(path) as im:sheet.paste(im,(x,y))
            draw.text((x+8,y+278),f'Film {start/30+offset+j:.2f}s / peek {offset+j:.0f}s',font=font,fill='white')
        sheet.save(folder/f'decoded-review-{offset//12:02d}.jpg',quality=94)
    qa.update(status='ready_for_assistant_visual_review',visual_review='pending',user_approval='not_recorded',video_sha256=sha(video),seconds=(end-start)/30,film_start_seconds=start/30,film_end_seconds=end/30,native_frames=end-start,source_render_hashes=source_hashes,helper_sha256=sha(__file__),plan_sha256=sha(OUT/'plan.json'),minimum_native_luma=min(luma),identical_adjacent_native_frames=sum(a==b for a,b in zip(native_hashes,native_hashes[1:])),scope='Working progress excerpt, not final release or a new production approval. Actual encoded-image inspection is required before sharing. No new voice synthesis or 3D rendering used.')
    write(folder/'qa.json',qa);print('SNEAK PEEK BUILT; VISUAL REVIEW PENDING',index,start/30,end/30,flush=True)
    return qa


def run(watch):
    PEEKS.mkdir(exist_ok=True);manifest=read(OUT/'manifest.json');shots=manifest['shots'];ranges=windows(sum(s['frames'] for s in shots))
    version={'helper_sha256':sha(__file__),'plan_sha256':sha(OUT/'plan.json'),'manifest_sha256':sha(OUT/'manifest.json'),'producer_sha256':sha(ROOT/'produce_revision.py')}
    if (PEEKS/'source-version.json').exists() and read(PEEKS/'source-version.json')!=version:
        raise ValueError('Progress-preview source changed; preserve this queue and start a fresh version rather than mixing previews.')
    write(PEEKS/'source-version.json',version)
    while True:
        states=[]
        for i,(start,end) in enumerate(ranges,1):
            folder=PEEKS/f'{i:02d}';qa=folder/'qa.json';parts=chunks(shots,start,end)
            if qa.exists():status=read(qa)['status']
            elif ready(parts):
                try:status=build(i,start,end,parts)['status']
                except (OSError,ValueError) as e:
                    write(PEEKS/'last-error.json',{'window':i,'error':str(e),'utc':datetime.now(timezone.utc).isoformat()});raise
            else:status='waiting_for_native_frames'
            states.append({'number':i,'film_start_seconds':start/30,'film_end_seconds':end/30,'status':status,'folder':str(folder)})
        write(PEEKS/'queue.json',{'updated_utc':datetime.now(timezone.utc).isoformat(),'main_render_separate':True,'previews':states,'last_window_may_overlap_previous_to_remain_30_seconds':True})
        if not watch or all(s['status']!='waiting_for_native_frames' for s in states):break
        time.sleep(30)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--watch',action='store_true');args=parser.parse_args();run(args.watch)
