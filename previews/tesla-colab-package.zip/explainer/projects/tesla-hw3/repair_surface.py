"""Repair a bounded Cycles cache artifact using the identical frozen scene/poses."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys
from PIL import Image
import numpy as np

ROOT=Path(__file__).resolve().parent
FOLDER=ROOT/'build/full-v1/05_intersection'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--test',action='store_true');args=parser.parse_args()
    renderer=ROOT/'render_film_chapter.py';source=renderer.read_text()
    prefix=source.split('\nfor attempt in range(3):',1)[0]
    assert len(prefix)<len(source),'Renderer structure changed'
    saved=sys.argv;sys.argv=['render_film_chapter','--index','4']
    namespace={'__file__':str(renderer),'__name__':'surface_repair_scene'}
    try:exec(compile(prefix,str(renderer),'exec'),namespace)
    finally:sys.argv=saved
    scene=namespace['s'];scene.render.use_persistent_data=False
    scene_qa=json.loads((FOLDER/'scene-qa.json').read_text())
    namespace['lens_scale']={int(k):v for k,v in scene_qa['lens_scale'].items()}
    bad=json.loads((FOLDER/'surface-diagnostic.json').read_text())['frames']
    indices=[int(x[0]) for x in bad]
    if args.test:indices=[indices[0],indices[len(indices)//2],indices[-1]]
    target=FOLDER/('repair-test' if args.test else 'raw');target.mkdir(exist_ok=True)
    backup=FOLDER/'surface-repair-original';backup.mkdir(exist_ok=True)
    records=[]
    for f in indices:
        file=FOLDER/'raw'/f'{f:06d}.png';destination=target/file.name
        if not args.test:
            if not (backup/file.name).exists():shutil.copy2(file,backup/file.name)
        ratio=namespace['apply'](f);assert ratio>=.999,('Framing changed',f,ratio)
        scene.render.filepath=str(destination)
        namespace['bpy'].ops.render.render(write_still=True)
        with Image.open(destination) as im:a=np.array(im)
        black=float(np.mean(np.max(a[:,:,:3],axis=2)<5))
        assert black<.10,('Surface artifact remains',f,black)
        records.append({'frame':f,'near_black_fraction':black,'sha256':sha(destination)})
        print('SURFACE REPAIRED',f,len(records),'/',len(indices),flush=True)
    report={'kind':'bounded_surface_cache_repair','passed':True,'persistent_data':False,
            'geometry_and_narration_changed':False,'frames':records,'renderer_sha256':sha(renderer),'repair_script_sha256':sha(Path(__file__))}
    (FOLDER/('repair-test.json' if args.test else 'surface-repair.json')).write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
