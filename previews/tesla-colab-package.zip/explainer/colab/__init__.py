"""Portable Colab adapters; canonical production sources remain unchanged."""
