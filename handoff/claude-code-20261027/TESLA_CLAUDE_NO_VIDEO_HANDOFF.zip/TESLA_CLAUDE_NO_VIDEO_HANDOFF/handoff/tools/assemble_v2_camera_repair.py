from pathlib import Path
from PIL import Image
import hashlib, importlib,json,shutil,subprocess
from explainer.media import check_video,assemble
repo=Path(__file__).resolve().parents[2]/'repository';p=repo/'explainer/projects/tesla-hw3/build/full-v2';r=p.parent/'full-v2-camera-repair';s=p/'r8';m=json.loads((p/'manifest.json').read_text());shot=m['shots'][7];mod=importlib.import_module('explainer.projects.tesla-hw3.produce_revision')
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read(f):return json.loads(Path(f).read_text())
def write(f,a):Path(f).write_text(json.dumps(a,indent=2)+'\n')
repair=read(r/'repair.json');repair['single_frame_visibility_repair']={'frame':347,'source':read(r.parent/'full-v2-camera-repair-single/repair.json'),'occluder':read(r.parent/'full-v2-camera-repair-single/occluder.json'),'scope':'Omit the offscreen rider sleeve intersecting the close-up camera near plane in one frame; no road-user or trajectory state changes.'};assert all((r/'r8/raw'/f'{i:06d}.png').exists() for i in repair['frames'])
backup=p/'before-camera-repair';backup.mkdir(exist_ok=True)
for a,b in [(s/'chapter.mp4',backup/'r8-chapter.mp4'),(s/'qa.json',backup/'r8-qa.json'),(p/'tesla-planning-v2.mp4',backup/'tesla-planning-v2.mp4'),(p/'final-qa.json',backup/'final-qa.json')]:
 if not b.exists():shutil.copy2(a,b)
poses=read(s/'poses.json');fixposes=read(r/'r8/poses.json');dest=r/'r8/chapter.mp4'
cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-framerate','30','-i','pipe:0','-i',str(backup/'r8-chapter.mp4'),'-map','0:v:0','-map','1:a:0','-t',str(shot['seconds']),'-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(dest)]
with (r/'encode.log').open('wb') as log:
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
 try:
  for i in range(shot['frames']):
   patch=i in repair['frames'];f=(r/'r8/raw' if patch else s/'raw')/f'{i:06d}.png'
   if i==347:f=r.parent/'full-v2-camera-repair-single/r8/raw/000347.png'
   with Image.open(f) as im:frame=mod.decorate(im,(fixposes if patch else poses)[str(i)],shot['mode'])
   proc.stdin.write(frame.tobytes())
  proc.stdin.close();assert proc.wait()==0
 except BaseException:proc.kill();proc.wait();raise
qa=check_video(dest,shot['seconds'],960,540);assert qa['passed'],qa
old=read(backup/'r8-qa.json');qa.update(encode_config=old['encode_config'],base_encode_config_scope='Frozen base render; camera repair independently recorded below.',video_sha256=sha(dest),native_width=768,native_height=432,native_fps=30,scene=old['scene'],review='pending_repaired_sequence_inspection',editorial_camera_repair=repair)
shutil.copy2(dest,s/'chapter.mp4');write(s/'qa.json',qa)
video=r/'assembled.mp4';assemble([p/x['id']/'chapter.mp4' for x in m['shots']],[x['seconds'] for x in m['shots']],video)
final=r/'tesla-planning-v2.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-i',str(backup/'tesla-planning-v2.mp4'),'-map','0:v:0','-map','1:a:0','-c','copy','-movflags','+faststart',str(final)],check=True)
def audio_packets(f):
 v=subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_packets','-show_data_hash','sha256','-show_entries','packet=pts,duration,data_hash','-of','json',str(f)],text=True)
 return json.loads(v)['packets']
assert audio_packets(final)==audio_packets(backup/'tesla-planning-v2.mp4'),'Audio must remain byte-identical with original timing'
q=check_video(final,m['seconds'],960,540);assert q['passed'],q
old=read(backup/'final-qa.json');q.update(review='pending_repaired_sequence_inspection',video_sha256=sha(final),chapters=8,retention=old['retention'],native_width=768,native_height=432,native_fps=30,editorial_camera_repair=repair,audio_original_packet_hashes_and_timestamps_identical=True)
shutil.copy2(final,p/'tesla-planning-v2.mp4');write(p/'final-qa.json',q)
print(json.dumps(q,indent=2),flush=True)
