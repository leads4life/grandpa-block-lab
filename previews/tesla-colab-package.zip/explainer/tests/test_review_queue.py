from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from explainer.core import write,read
from explainer.review_queue import prepare_packet,decide

class ReviewQueue(unittest.TestCase):
 def setUp(self):
  self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.root=Path(self.temp.name)/'project';self.root.mkdir()
  write(self.root/'plan.json',{'title':'SYNTHETIC REVIEW TEST'})
  (self.root/'video.mp4').write_bytes(b'synthetic test artifact')
  write(self.root/'qa.json',{'passed':True,'review':'passed'})
 def packet(self):return prepare_packet(self.root,self.root/'video.mp4',self.root/'qa.json')
 def test_preparation_does_not_queue_or_approve(self):
  packet=self.packet();self.assertEqual(packet['status'],'awaiting_user')
  self.assertNotIn('user_evidence',packet)
 def test_reject_preserves_video(self):
  self.packet();decide(self.root,'reject','SYNTHETIC TEST ONLY',notes='Revise style')
  self.assertEqual(read(self.root/'review/decision.json')['status'],'rejected')
  self.assertTrue((self.root/'video.mp4').exists())
 def test_artifact_tampering_blocks_queue(self):
  self.packet();(self.root/'video.mp4').write_bytes(b'changed')
  with self.assertRaisesRegex(ValueError,'artifacts changed'):
   decide(self.root,'send_to_work_pool','SYNTHETIC TEST ONLY',pool_root=Path(self.temp.name)/'pool')
 def test_explicit_approval_creates_distinct_project_work_item(self):
  self.packet();out=decide(self.root,'send_to_work_pool','SYNTHETIC TEST ONLY',pool_root=Path(self.temp.name)/'pool')
  item=read(out/'manifest.json');self.assertEqual(item['kind'],'explainer_project')
  self.assertEqual(item['status'],'approved_direction_requires_production_preflight')
  self.assertTrue((out/'source-snapshot/core.py').exists())
  self.assertEqual(read(self.root/'review/decision.json')['status'],'sent_to_work_pool')
 def test_failed_qa_cannot_be_presented(self):
  write(self.root/'qa.json',{'passed':False,'review':'passed'})
  with self.assertRaises(ValueError):self.packet()
