import math
import unittest
from explainer.slider_crank import positions


class SliderCrank(unittest.TestCase):
    def test_rod_length_and_slider_axis_over_two_revolutions(self):
        for frame in range(360):
            pin,slider=positions(frame*math.tau/180)
            self.assertAlmostEqual(math.dist(pin,slider),2.7,places=10)
            self.assertEqual(slider[:2],(0,0))

    def test_stroke_and_closed_cycle(self):
        top=positions(0)[1][2];bottom=positions(math.pi)[1][2]
        self.assertAlmostEqual(top-bottom,1.4)
        self.assertAlmostEqual(positions(0)[1][2],positions(math.tau)[1][2])

    def test_impossible_linkage_is_rejected(self):
        for radius,length in [(0,2),(2,1),(1,1),(float('nan'),2)]:
            with self.assertRaises(ValueError):positions(0,radius,length)
