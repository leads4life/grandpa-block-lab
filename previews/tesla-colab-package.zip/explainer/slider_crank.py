"""Reusable ideal slider-crank kinematics. No combustion or force simulation."""
import math


def positions(angle, radius=.7, rod_length=2.7, center_z=.75):
    if not all(math.isfinite(v) for v in (angle, radius, rod_length, center_z)) or not 0 < radius < rod_length:
        raise ValueError('Use finite values with 0 < crank radius < connecting-rod length')
    x = radius * math.sin(angle)
    z = center_z + radius * math.cos(angle)
    slider_z = z + math.sqrt(rod_length**2 - x**2)
    return (x, 0, z), (0, 0, slider_z)
