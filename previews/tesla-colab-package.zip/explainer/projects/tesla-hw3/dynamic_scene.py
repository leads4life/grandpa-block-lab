"""A continuous 3D yield-and-turn illustration, built and checked before expensive rendering."""
from pathlib import Path
import json,math,os,sys
import numpy as np
import bpy
from mathutils import Vector,Quaternion
from bpy_extras.object_utils import world_to_camera_view
from explainer.traffic_scene import sedan,intersection,cube
from explainer.visual_tools import material,line
from explainer.blender_backend import aim
from explainer.turn_motion import pose,circle_clearance,rectangles_overlap,smooth
from explainer.media import voice
from explainer.core import read,write,VOICE
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/dynamic-v3';OUT.mkdir(parents=True,exist_ok=True)
W,H,FPS=640,360,30
TEXT="The goal is a left turn. The vehicle waits for the crossing pedestrian and the oncoming car. After both clear the junction, it follows the selected route into the target lane. This is a simplified planning illustration."
if not (OUT/'voice.json').exists():voice({'narration':TEXT},OUT)
audio=read(OUT/'voice.json');DURATION=max(17.,math.ceil((audio['seconds']+.8)*FPS)/FPS);NF=round(DURATION*FPS)
write(OUT/'timing.json',{'seconds':DURATION,'frames':NF,'voice':VOICE,'script':TEXT,'width':W,'height':H})
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=6;s.cycles.use_denoising=False
s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2
s.render.threads_mode='FIXED';s.render.threads=4;s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100;s.render.fps=FPS
s.frame_start=0;s.frame_end=NF-1
s.world=bpy.data.worlds.new('Daylight');s.world.use_nodes=True
s.world.node_tree.nodes['Background'].inputs[0].default_value=(.45,.58,.75,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.8
intersection();ev=sedan('EV');other=sedan('Oncoming')
for name in ['Asphalt','Pavement','Road paint','Center paint']:
 m=bpy.data.materials.get(name)
 if m:
  b=m.node_tree.nodes['Principled BSDF'];b.inputs['Metallic'].default_value=0;b.inputs['Roughness'].default_value=.85
b=bpy.data.materials['Oncoming paint'].node_tree.nodes['Principled BSDF'];b.inputs['Base Color'].default_value=(.5,.095,.035,1)
# Low-angle soft sunlight gives clear contact shadows without a noisy reflective studio floor.
bpy.ops.object.light_add(type='AREA',location=(-6,-8,20));sun=bpy.context.object;sun.data.energy=3100;sun.data.size=14;aim(sun,(0,0,0))
# Add visible spokes, then rotate actual wheel geometry rather than sliding a still car.
wheels={}
for root in [ev,other]:
 group=[]
 for obj in list(root.children):
  if 'tire' in obj.name or 'rim' in obj.name:
   group.append((obj,obj.location.y>0));obj.rotation_mode='QUATERNION'
  if 'rim' in obj.name:
   side=1 if obj.location.x>0 else -1
   dark=material(obj.name+' spoke',(.07,.09,.12,1))
   for n in range(3):
    spoke=cube('Wheel spoke',(0,0,side*.118),(.36,.035,.012),dark,obj,0);spoke.rotation_euler.z=n*math.pi/3
 wheels[root.name]=group
# Generic walking pedestrian, no presenter rig or character narration.
ped=bpy.data.objects.new('Pedestrian',None);s.collection.objects.link(ped)
shirt=material('Pedestrian jacket',(.82,.4,.06,1));trousers=material('Pedestrian trousers',(.06,.09,.13,1));skin=material('Pedestrian skin',(.6,.37,.23,1));shoes=material('Shoes',(.025,.03,.04,1))
cube('Jacket',(0,0,1.13),(.43,.24,.58),shirt,ped,.065);cube('Pelvis',(0,0,.82),(.33,.22,.18),trousers,ped,.035)
bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=.15,location=(0,0,1.60));head=bpy.context.object;head.parent=ped;head.data.materials.append(skin)
def bone(name,mat,radius):
 bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=1,depth=1);o=bpy.context.object;o.name=name;o.parent=ped;o.data.materials.append(mat);o['radius']=radius;return o
def link(obj,a,b):
 a,b=Vector(a),Vector(b);obj.location=(a+b)*.5;obj.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();obj.scale=(obj['radius'],obj['radius'],(b-a).length)
limbs=[]
for side in [-1,1]:
 foot=cube('Walking shoe',(side*.13,0,.05),(.16,.3,.1),shoes,ped,.025)
 limbs.append((side,foot,bone('Thigh',trousers,.07),bone('Shin',trousers,.058),bone('Upper arm',shirt,.06),bone('Forearm',skin,.043)))
def walk(distance):
 phase=distance/1.2*math.tau
 for side,foot,thigh,shin,upper,lower in limbs:
  a=phase+(0 if side<0 else math.pi);ankle=Vector((side*.13,.28*math.cos(a),.055+max(0,-math.sin(a))*.12));hip=Vector((side*.13,0,.82))
  delta=ankle-hip;length=delta.length;assert length<.9
  normal=Vector((0,-delta.z,delta.y)).normalized();knee=(hip+ankle)*.5+normal*math.sqrt(.45**2-(length*.5)**2)
  foot.location=ankle;link(thigh,hip,knee);link(shin,knee,ankle)
  shoulder=Vector((side*.27,0,1.36));hand=Vector((side*.29,-.18*math.cos(a),.99));elbow=(shoulder+hand)*.5+Vector((0,.10,0))
  link(upper,shoulder,elbow);link(lower,elbow,hand)
route_points=[]
for i in range(101):
 p=pose(6.7+(DURATION-.35-6.7)*i/100,DURATION)['ev'];route_points.append((p[0],p[1],.045))
route_mat=material('Selected route',(.15,.35,.44,1),luminous=True);route=line('Left turn route',route_points,.055,route_mat)
# A target-lane marker at road level, not a full-screen graphic.
bpy.ops.mesh.primitive_cone_add(vertices=24,radius1=.18,radius2=0,depth=.5,location=(-10.5,1.8,.12));goal=bpy.context.object;goal.rotation_euler.y=-math.pi/2;goal.data.materials.append(material('Goal cyan',(.02,.7,.9,1),True))
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.lens=40;cam.data.dof.use_dof=False
shot_info={};minimum_clearance=100.;lens_adjustments=0
main_meshes=[o for o in bpy.data.objects if o.type=='MESH' and (o.parent==ev or (o.parent and o.parent.parent==ev))]
ped_meshes=[o for o in ped.children if o.type=='MESH']
def apply(f):
 global minimum_clearance,lens_adjustments
 t=f/FPS;p=pose(t,DURATION)
 ev.location=(*p['ev'][:2],.015);ev.rotation_euler.z=p['ev'][2]
 other.location=(*p['other'][:2],.015);other.rotation_euler.z=p['other'][2];other.hide_render=p['other'][1]<-24
 ped.location=(*p['pedestrian'][:2],.035);ped.rotation_euler.z=p['pedestrian'][2];walk(p['walk_distance'])
 for root,distance in [(ev,p['ev_distance']),(other,4*t)]:
  for wheel,front in wheels[root.name]:
   steer=p['steer'] if root==ev and front else 0
   wheel.rotation_quaternion=Quaternion((0,0,1),steer)@Quaternion((0,1,0),math.pi/2)@Quaternion((0,0,1),-distance/.35)
 emission=route_mat.node_tree.nodes.get('Emission')
 if emission:emission.inputs['Color'].default_value=(.03,.7,.95,1) if p['phase']=='turn' else (.2,.32,.4,1)
 x,y,yaw=p['ev'];direction=Vector((-math.sin(yaw),math.cos(yaw),0))
 if t<4.2:
  q=t/4.2;cam.location=(11-q,-18+q,11+.5*q);target=Vector((1,-5.5,.5));lens=40;shot='waiting_close'
 elif t<6.7:
  q=(t-4.2)/2.5;cam.location=(18-q,-15+q,24);target=Vector((0,-2,0));lens=37;shot='conflict_overview'
 elif t<DURATION*.77:
  cam.location=Vector((x,y,.7))+Vector((10,-13,11));target=Vector((x,y,.4))+direction*2;lens=43;shot='turn_tracking'
 else:
  cam.location=Vector((x,y,.7))+Vector((6,-10,7));target=Vector((x,y,.5))+direction*1.2;lens=43;shot='exit_tracking'
 cam.data.lens=lens;aim(cam,target);bpy.context.view_layer.update()
 # Preflight all poses before rendering. The main car and relevant crossing agent stay in frame.
 important=main_meshes+(ped_meshes if t<6.7 and abs(p['pedestrian'][0])<4 else [])
 for attempt in range(5):
  bad=[]
  for obj in important:
   if obj.hide_render:continue
   for corner in obj.bound_box:
    v=world_to_camera_view(s,cam,obj.matrix_world@Vector(corner))
    if v.z<=0 or not (.035<v.x<.965 and .035<v.y<.965):bad.append(obj.name);break
  if not bad:break
  cam.data.lens/=1.12
 else:raise ValueError(('Framing',f,bad[:4]))
 if attempt:lens_adjustments+=1
 assert not rectangles_overlap(p['ev'],p['other'])
 for car in [p['ev'],p['other']]:minimum_clearance=min(minimum_clearance,circle_clearance(car,p['pedestrian']))
 assert minimum_clearance>.1
 # Main actor motion must not be a camera-only still.
 shot_info[f]={'shot':shot,'phase':p['phase'],'ev':list(p['ev']),'progress':p['progress'],'lens':cam.data.lens}
 return p
for f in range(NF):apply(f)
write(OUT/'scene-qa.json',{'frames':NF,'minimum_agent_clearance':minimum_clearance,'framing_repaired_frames':lens_adjustments,'camera_shots':sorted(set(x['shot'] for x in shot_info.values())),'static_image_sections':False,'source':'Original illustrative traffic actors; not a Tesla software reconstruction'})
write(OUT/'poses.json',shot_info)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'dynamic-scene.blend'))
folder=OUT/'raw';folder.mkdir(exist_ok=True)
frames=[0,round(3*FPS),round(7*FPS),round((DURATION-2)*FPS)] if '--stills' in sys.argv else range(NF)
for f in frames:
 path=folder/f'{f:06d}.png'
 if path.exists():continue
 apply(f);s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
print('DYNAMIC 3D SCENE READY',NF,'frames',DURATION,'seconds',flush=True)
