# Research findings

The patent identity, Tesla assignee, graph planning, scoring factors and threshold pruning are verified against the retrieved full patent text. Tesla support confirms supervision remains required.

The patent contains no HW3, V14 or 80% claim. This does not prove that no other source makes such a claim; it means the patent cannot substantiate those promises. The official Q1 2026 webcast page was retrieved and points to YouTube video qO7T5zgRvXM. Its transcript and the quarterly PDF on assets-ir.tesla.com remain inaccessible from the current proxy. Do not invent or attribute an earnings-call statement without checking it.

Production preparation: complete original plan retained, 13 draft shots, explicit claim ledger, an original generic EV/intersection asset built and rendered for layout checking. No full episode or unverified factual narration has been rendered.
