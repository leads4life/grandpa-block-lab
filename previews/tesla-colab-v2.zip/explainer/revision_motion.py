"""Illustrative equal-time motion comparison, not Tesla measurements or scores."""
def motion_progress(u,style):
    u=max(0.,min(1.,u))
    if style=='gradual':return u**3*(10-15*u+6*u*u)
    if style!='abrupt':raise ValueError('Unknown motion style')
    ramp=.06
    if u<ramp:return u*u/(2*ramp*(1-ramp))
    if u>1-ramp:return 1-(1-u)**2/(2*ramp*(1-ramp))
    return (u-ramp/2)/(1-ramp)
