from pathlib import Path
import copy,hashlib,json,math,os,re
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
from kokoro_onnx import Kokoro
from explainer.core import read,write,VOICE_DELIVERY
from explainer.media import synthesize_paced
from explainer.retention import audit
ROOT=Path(__file__).resolve().parent;REV=ROOT/'retention-v2';OUT=ROOT/'build/full-v2';OUT.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=read(REV/'script-and-retention-draft.json');p=copy.deepcopy(base)
p.update(status='user_authorized_revision_in_preflight',title="Inside Tesla's planning patent: how selective search works",learning_goal='Follow one driving example through branching, evaluation and pruning; distinguish candidate search from perception and hardware deployment.',subject_bible=read(ROOT/'plan.json')['subject_bible'],production_version='full-v2',narration_lock={})
p['subject_bible']['simplifications']='All models and scores are original schematic illustrations. No manufacturer CAD, Tesla software reconstruction, performance percentages or complete perception guarantees.'
p['claims']['patent_identity']['text']='US20260105614A1 is a Tesla-assigned patent application published April 16, 2026; it is evidence of disclosure, not product deployment.'
p['claims']['branching_math']['text']='In an illustrative full three-way tree, one, two and three decision stages produce 3, 9 and 27 complete sequences; no statistical independence or Tesla performance result is asserted.'
primary=(ROOT/'sources/patent.txt').read_text().splitlines()
p['sources']['tesla_patent']['supporting_passages']=[next(line for line in primary if line.startswith(prefix)) for prefix in ['The hierarchical nodal graph can have hierarchical layers of nodes.','To avoid generating a hierarchical nodal graph that is too large','In some cases, the node scores can correspond to factors such as comfortability']]
p['sources']['tesla_patent']['retained_text_sha256']=sha(ROOT/'sources/patent.txt')
p['sources']['tesla_fsd_support']['supporting_passage']=next(line for line in (ROOT/'sources/tesla-fsd.txt').read_text().splitlines() if line.startswith('Currently enabled features require active driver supervision'))
p['sources']['tesla_fsd_support']['retained_text_sha256']=sha(ROOT/'sources/tesla-fsd.txt')
p['shots'][0]['narration']=p['shots'][0]['narration'].replace('This example will show how a planner chooses where to spend effort.','Follow one turn to see how a planner chooses where to spend effort.')
p['retention']['opening']['value_promise']['quote']='Follow one turn to see how a planner chooses where to spend effort.'
p['shots'][3]['narration']=p['shots'][3]['narration'].replace('No. The cyclist stays in the scene.','In our illustration, no. The cyclist stays represented.').replace('What can change is their relevance','What can change is their relevance')
p['retention']['rungs'][3]['payoff']['quote']='The cyclist stays represented.'
p['shots'][7]['teaches']='Apply the candidate-versus-road-user distinction while resolving the illustrative turn.'
p['retention']['rungs'][7]['new_knowledge']=p['shots'][7]['teaches']
MODES=['decision','growth','trajectory','attention','comparison','pruning','hardware','resolve']
engine=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES'])
for i,shot in enumerate(p['shots']):
 folder=OUT/shot['id'];folder.mkdir(exist_ok=True);text=shot['narration']
 parts=re.split(r'(?<=[.!?])\s+',text)
 # Keep brief answers with the following thought, avoiding a one-word synthesized clip.
 merged=[];j=0
 while j<len(parts):
  part=parts[j]
  if len(part.split())<4 and j+1<len(parts):part+=' '+parts[j+1];j+=1
  merged.append(part);j+=1
 class Thoughts:
  def create(self,text,voice,speed,**delivery):
   arrays=[];self.groups=[];cursor=0;sr0=None
   for k,part in enumerate(merged):
    a,sr=engine.create(part,voice=voice,speed=speed,**delivery)[:2];a=np.asarray(a,dtype=np.float64)
    active=np.flatnonzero(np.abs(a)>np.abs(a).max()*.005);assert len(active)
    a=a[max(0,active[0]-round(sr*.025)):min(len(a),active[-1]+round(sr*.055))]
    if sr0 is not None:assert sr==sr0
    sr0=sr;self.groups.append({'text':part,'start':cursor/sr,'seconds':len(a)/sr})
    arrays.append(a);cursor+=len(a)
    if k<len(merged)-1:
     gap=np.zeros(round(sr*(.13 if part.endswith('?') else .08)));arrays.append(gap);cursor+=len(gap)
   return np.concatenate(arrays),sr0
 meta=folder/'voice.json'
 if meta.exists():
  v=read(meta);assert v['text']==text and sha(folder/'voice.wav')==v['sha256']
 else:
  grouped=Thoughts();samples,sr,speed,attempts=synthesize_paced(grouped,text,'am_fenrir',1.24,VOICE_DELIVERY,target=179,tolerance=7,max_attempts=5)
  divisor=math.gcd(int(sr),48000);samples=resample_poly(samples,48000//divisor,int(sr)//divisor);samples*=.7/np.abs(samples).max()
  lead=.12;tail=.45;samples=np.concatenate([np.zeros(round(lead*48000)),samples,np.zeros(round(tail*48000))])
  seconds=math.ceil(len(samples)/48000*30)/30;samples=np.pad(samples,(0,round(seconds*48000)-len(samples)))
  wavfile.write(folder/'voice.wav',48000,(samples*32767).astype(np.int16))
  v={'text':text,'voice':'am_fenrir','synthesis_speed':speed,'seconds':seconds,'measured_words_per_minute':attempts[-1]['words_per_minute'],'pace_attempts':attempts,'thought_groups':[dict(g,start=g['start']+lead) for g in grouped.groups],'sha256':sha(folder/'voice.wav'),'speech_time_stretched':False,'model_sha256':sha(os.environ['KOKORO_MODEL']),'voices_sha256':sha(os.environ['KOKORO_VOICES'])};write(meta,v)
 shot.update(index=i,mode=MODES[i],duration=v['seconds'],seconds=v['seconds'],frames=round(v['seconds']*30),thought_groups=v['thought_groups'],voice_sha256=v['sha256'])
 p['narration_lock'][shot['id']]={'text':text,'seconds':v['seconds'],'sha256':v['sha256']}
 rung=p['retention']['rungs'][i]
 for kind in ['prompt','payoff']:
  old=rung[kind]['quote'];g=next(g for g in v['thought_groups'] if old in g['text']);rung[kind].update(at=g['start'],quote=g['text'])
 if i==0:
  g=next(g for g in v['thought_groups'] if p['retention']['opening']['value_promise']['quote'] in g['text']);p['retention']['opening']['value_promise'].update(at=g['start'],quote=g['text'])
 print('FROZEN',shot['id'],round(v['seconds'],2),'seconds',round(v['measured_words_per_minute'],1),'wpm',flush=True)
p['retention']['timing_basis']='measured';p['retention']['review']={'status':'pending_actual_preflight_inspection','timing_method':'Exact complete thought-group quote onsets measured during synthesis; not estimated quarter-duration or forced word alignment.'}
write(OUT/'plan.json',p);r=audit(p);assert r['passed'],r;write(OUT/'retention-check.json',r)
manifest={'version':'full-v2','title':p['title'],'fps':30,'width':768,'height':432,'export_width':960,'export_height':540,'render_samples':6,'shots':p['shots'],'seconds':sum(x['seconds'] for x in p['shots']),'music':False,'captions':False,'sources':p['sources'],'claims':p['claims']};write(OUT/'manifest.json',manifest)
auth={'user_evidence':"yes closer do a once more audit add more where you can and go to production'",'scope':'Approval of the linked richer direction sample and revision direction, with explicit authorization for another audit, routine additions and complete production. Final user approval of the new finished film is not claimed.','approved_baseline_script_sha256':sha(REV/'script-and-retention-draft.json'),'approved_sample_sha256':sha(REV/'build/showcase/richer-3d-retention-sample.mp4'),'user_full_production_authorized':True,'permitted_refinements':['Measured narration and true reveal timing','More visual depth and subject-specific staging','Visible motion consequences replacing arbitrary scores','Remove visible set edges','Qualify road-user representation as illustrative'],'publication':'Use existing authorized review-artifact delivery branch; no YouTube upload'};write(OUT/'authorization.json',auth)
md=['# Tesla full-v2 production storyboard','',auth['user_evidence'],'',f"Measured runtime: {manifest['seconds']:.2f}s. Preferred narrator; actual speech timing, no time stretch.",'']
t=0
for s,rung in zip(p['shots'],p['retention']['rungs']):
 md.extend([f"## {s['index']+1}. {s['title']}",'',f"{t:.2f}–{t+s['seconds']:.2f}s",'',s['narration'],'','Visual: '+rung['visual_payoff'],'','Audio: '+rung['audio_direction'],'',f"Measured prompt {rung['prompt']['at']:.3f}s → payoff {rung['payoff']['at']:.3f}s within chapter.",'']);t+=s['seconds']
(OUT/'storyboard.md').write_text('\n'.join(md)+'\n')
print('MEASURED PRODUCTION PLAN',manifest['seconds'],'seconds',sum(x['frames'] for x in p['shots']),'frames; review pending',flush=True)
