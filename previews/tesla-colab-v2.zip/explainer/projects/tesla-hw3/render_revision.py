"""Measured speech drives distinct, continuous 3D explanation scenes for full-v2."""
from pathlib import Path
import argparse,hashlib,math
import bpy
from mathutils import Vector,Quaternion
from bpy_extras.object_utils import world_to_camera_view
from explainer.core import read,write
from explainer.visual_tools import line
from explainer.traffic_scene import cube
from explainer.vehicle_prop import build_vehicle
from explainer.blender_backend import aim
from explainer.turn_motion import pose,smooth,rectangles_overlap,circle_clearance
from explainer.revision_motion import motion_progress
from .rich_scene import palette,studio,street,person,walking,bicycle,empty,sphere,clone,visible,futures,workbench,bake_mesh_modifiers

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v2'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--index',type=int,required=True);parser.add_argument('--stills',action='store_true');parser.add_argument('--frames',type=int,nargs='*');args=parser.parse_args()
    manifest=read(OUT/'manifest.json');shot=manifest['shots'][args.index];folder=OUT/shot['id'];folder.mkdir(exist_ok=True)
    D,NF,mode=shot['seconds'],shot['frames'],shot['mode'];groups=shot['thought_groups']
    def event(needle):
        return next(g['start'] for g in groups if needle in g['text'])
    def at_group(i):return groups[min(i,len(groups)-1)]['start']
    bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.render.engine='CYCLES'
    s.cycles.samples=manifest['render_samples'];s.cycles.use_denoising=True;s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2
    s.render.use_persistent_data=False;s.render.threads_mode='FIXED';s.render.threads=4
    s.render.resolution_x=manifest['width'];s.render.resolution_y=manifest['height'];s.render.resolution_percentage=100;s.render.fps=30
    s.render.image_settings.file_format='PNG';s.render.image_settings.compression=15
    m=palette();studio(s,m);labels=[];nodes=[];edges=[];worlds=[];packets=[]
    def label(text,target):labels.append((text,target))
    is_street=mode not in ['hardware','comparison']
    if is_street:
        street(m,extended=mode in ['decision','resolve'])
        car=build_vehicle('Hero blue car');other=build_vehicle('Opposing red car',(.44,.06,.035,1))
        ped,limbs=person('Crossing pedestrian',m);cycle,cycle_wheels,rider_limbs=bicycle(m)
        cycle.location=(5.2,-2,.1)
        cyclist_torso=next(o for o in cycle.children_recursive if o.name.startswith('Rider coat'))
        cyclist_head=next(o for o in cycle.children_recursive if o.name.startswith('Rider head'))
        if mode in ['growth','trajectory','pruning']:
            nodes,edges,worlds=futures(m,car,depth=2 if mode=='trajectory' else 3)
        routes=[]
        # Turn, creep and wait are candidate illustrations, not executed maneuvers.
        points=[[(1.8,-8.5,.15),(1.8,-4,.15),(-.8,.8,.15),(-6,1.8,.15)],
                [(1.8,-8.5,.16),(1.8,-6,.16)],[(1.0,-9,.17),(2.6,-9,.17)]]
        for i,ps in enumerate(points):routes.append(line(['Candidate turn','Candidate creep','Candidate wait'][i],ps,.055,m['cyan'] if i==2 else m['muted']))
        goal=cube('Goal lane patch',(-6.6,1.8,.13),(2.6,1.6,.025),m['cyan'],bevel=.08)
        label('Goal lane',Vector((-6.6,1.8,.25)))
        halo=None;relevance=None
        if mode=='attention':
            bpy.ops.mesh.primitive_torus_add(major_radius=.95,minor_radius=.045,major_segments=32,minor_segments=8)
            halo=bpy.context.object;halo.data.materials.append(m['amber'])
            relevance=line('Illustrative interaction link',[(1.8,-6.5,1),(6.5,-2,1)],.04,m['cyan'])
        if mode in ['attention','pruning','resolve']:label('Cyclist stays represented',cycle)
        if mode in ['decision','resolve','pruning']:label('Pedestrian',ped)
        if mode in ['growth','trajectory','pruning']:
            for root,mini,i in worlds:label(['Turn candidate','Creep candidate','Wait candidate'][i],root)
        frontwheel=next(o for o in car.children if o.get('vehicle_part')=='wheel' and o.location.x>0 and o.location.y>0)
    elif mode=='hardware':
        board,core,parts=workbench(m)
        # Equal-size tokens identify system functions, not measured utilization.
        for i,name in enumerate(['Perception','Prediction','Planning','Memory / timing']):
            x=-5.4+i*3.6;cube(name+' interface',(x,3.6,2.2),(2.8,1.4,.16),m['rim'])
            label(name,Vector((x,3.6,2.5)))
            track=line(name+' channel',[(x,3,2.45),(x,1.8,2.45),(0,0,2.8)],.025,m['muted'])
            marker=sphere(name+' explanatory token',(x,3,2.45),.11,m['cyan']);packets.append((marker,track,i))
        label('Generic module · fixed hardware',Vector((0,-3,2.5)))
        label('Application',Vector((-6.5,-1,2.7)));label('Release evidence',Vector((6.5,-1,2.7)))
    else:
        # Twin longitudinal motion studies share distance and duration, without scores.
        cars=[];study_markers=[]
        for i,x in enumerate([-7.5,7.5]):
            cube('Motion-study cutaway',(x,0,-.25),(13.5,24,.5),m['rim'],bevel=.18)
            cube('Motion-study pavement',(x,0,.025),(13.2,23.7,.08),m['paving'],bevel=.12)
            cube('Motion-study lane',(x,0,.08),(5.4,23.7,.035),m['road'],bevel=0)
            for y in range(-10,12,3):cube('Study lane dash',(x-1.9,y,.12),(.09,1.3,.015),m['paint'],bevel=0)
            # Context remains to the outside so the compared motions are unobstructed.
            from .rich_scene import house,tree
            house('Motion-study architecture',x+(-4.6 if i==0 else 4.6),5,.07,m,.8)
            tree('Motion-study tree',x+(-4.6 if i==0 else 4.6),-4,.07,m,.8)
            vehicle=build_vehicle(['Abrupt-motion vehicle','Gradual-motion vehicle'][i]);cars.append(vehicle)
            label(['Abrupt speed change','Gradual speed change'][i],Vector((x,-10,.8)))
            marks=[]
            for j in range(7):
                progress=motion_progress(j/6,['abrupt','gradual'][i]);o=cube('Equal-time position tick',(x+2.3,-8+16*progress,.15),(.5,.07,.03),m['amber'],bevel=.01);marks.append(o)
            study_markers.append(marks)
    bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.clip_end=10000
    bake_mesh_modifiers(s)
    poses={};scales={};min_clearance=1e9;visibility={}

    def wheel_roll(vehicle,distance,steer=0):
        for wheel in vehicle.children:
            if wheel.get('vehicle_part')=='wheel':
                wheel.rotation_euler.x=-distance/.34;wheel.rotation_euler.z=steer if wheel.location.y>0 else 0

    def apply(f):
        nonlocal min_clearance
        t=f/30;u=t/D;badges=[];callouts=[];count=None;job='';focus=[];group_index=max([i for i,g in enumerate(groups) if g['start']<=t] or [0])
        if is_street:
            # Cars and road users are independent of graph membership.
            if mode=='resolve':
                p=pose(t,D);car.location=(*p['ev'][:2],.1);car.rotation_euler.z=p['ev'][2]
                other.location=(*p['other'][:2],.1);other.rotation_euler.z=math.pi
                ped.location=(*p['pedestrian'][:2],.1);ped.rotation_euler.z=math.pi/2
                wheel_roll(car,p['ev_distance'],p['steer']);wheel_roll(other,4*t);walking(limbs,p['walk_distance'])
                actual=p['ev'];opposing=p['other'];pedpoint=p['pedestrian']
                visible(other,abs(other.location.y)<24)
            else:
                start=event('A pedestrian') if mode=='decision' else 0
                moving=max(0,t-start);creep=.55*smooth(t/1.8)
                car.location=(1.8,-9.2+creep,.1);car.rotation_euler.z=0
                other.location=(-1.8,16-3.3*moving,.1);other.rotation_euler.z=math.pi;visible(other,abs(other.location.y)<24)
                walked=min(11,max(0,moving)*1.5);ped.location=(4.6-walked,-5,.1);ped.rotation_euler.z=math.pi/2
                wheel_roll(car,creep);wheel_roll(other,3.3*moving);walking(limbs,walked)
                actual=(car.location.x,car.location.y,0);opposing=(other.location.x,other.location.y,math.pi);pedpoint=(ped.location.x,ped.location.y,0)
            assert not rectangles_overlap(actual,opposing),('Vehicle intersection',f)
            clearance=circle_clearance(actual,pedpoint,.38);min_clearance=min(min_clearance,clearance);assert clearance>.1,('Pedestrian clearance',f)
            cycle.location=(5.2,-7+12*u,.1)
            for wheel in cycle_wheels:wheel.rotation_mode='QUATERNION';wheel.rotation_quaternion=Quaternion((0,1,0),math.pi/2)@Quaternion((0,0,1),-12*u/.32)
            walking(rider_limbs,12*u)
            assert circle_clearance(actual,cycle.location,.7)>.1,('Cyclist clearance',f)
            for i,route in enumerate(routes):
                route.data.bevel_factor_end=smooth((t-(.2 if mode=='decision' else 0))/1.1)
                route.hide_render=mode in ['growth','pruning','attention']
            goal.hide_render=mode not in ['trajectory','resolve']
            if mode=='decision':
                if t<event('Follow one turn'):
                    job='decision_close';target=car.location+Vector((0,.5,.7));cam.location=car.location+Vector((6-u,-7,3.2));focus=[car];lens=40
                    badges=['Turn · creep · wait']
                elif t<event('A pedestrian'):
                    job='decision_options';target=Vector((-1,-4,1));cam.location=(10-u,-19,11);focus=[car,routes[0]];lens=39
                    badges=['Three candidate actions']
                elif t<event('Our car waits'):
                    job='crossing_interaction';target=Vector((.5,-4,1));cam.location=(13-u,-21,9);focus=[car,ped];lens=37
                elif t<event("Tesla's patent"):
                    job='wait_and_alternatives';target=Vector((-.8,-5,.7));cam.location=(-13+u,-20,10);focus=[car,ped];lens=39
                    badges=['Turn / creep / wait']
                else:
                    job='search_setup';target=Vector((0,-3,1));cam.location=(14-u,-24,13);focus=[car];lens=43
                    badges=['Select where to explore']
            elif mode in ['growth','trajectory','pruning']:
                if mode=='growth':
                    reveals=[0,event('Give each'),event('Add a third')]
                    count=27 if t>=reveals[2]+.3 else 9 if t>=event('Now there are nine') else 3
                elif mode=='trajectory':reveals=[0,0,0]
                else:reveals=[0,0,event('The poor branch')+.8]
                for obj,level,k in nodes:
                    growth=smooth((t-reveals[level-1]+.3)/.55);keep=1
                    if mode=='pruning' and k<2*3**(level-1):keep=1-smooth((t-event('This is pruning'))/1.2)
                    obj.scale=(max(.0001,growth*keep),)*3
                for edge,level,k in edges:
                    growth=smooth((t-reveals[level-1]+.35)/.55);keep=1
                    if mode=='pruning' and k<2*3**(level-1):keep=1-smooth((t-event('This is pruning'))/1.2)
                    edge.data.bevel_factor_end=growth*keep
                    selected=k==3**level-1
                    edge.data.materials[0]=m['cyan'] if selected or mode=='growth' else m['muted']
                    if mode=='pruning' and k<2*3**(level-1) and t>event('This is pruning')-.8:edge.data.materials[0]=m['red']
                for root,mini,i in worlds:
                    progress=smooth((t-2-i*.3)/max(3,D*.55));mini.location.y=-.8+1.5*progress if i!=2 else -.8
                    wheel_roll(mini,1.5*progress/.38 if i!=2 else 0)
                if mode=='growth':
                    if group_index<2:
                        job='future_worlds';cam.location=(17-u,-24,15);target=Vector((0,5,3));lens=39
                    elif group_index<5:
                        job='branching_reveal';cam.location=(6-2*u,-29,13);target=Vector((0,10,5));lens=39
                    elif group_index<6:
                        job='linked_future_context';cam.location=(-16+2*u,-27,14);target=Vector((0,8,4));lens=38
                    else:
                        job='future_context_detail';cam.location=(16-u,-7,9);target=Vector((7.5,8,3.7));lens=40
                    focus=[obj for obj,level,k in nodes if max(obj.scale)>.05]
                    if job=='future_context_detail':focus=[worlds[2][0]]
                    badges=[f'{count} '+('choices' if count==3 else 'sequences')]
                    if job=='future_context_detail':badges=['Connect choices to a goal']
                elif mode=='trajectory':
                    if group_index<2:
                        job='physical_goal';cam.location=(-14+u,-19,10);target=Vector((-2,-1,.8));focus=[car,goal];lens=42
                    elif t<event('That linked sequence'):
                        job='connected_interactions';cam.location=(15-u,-26,14);target=Vector((0,7,3.4));focus=[obj for obj,l,k in nodes];lens=40
                    elif t<event('The patent calls'):
                        job='candidate_chain';cam.location=(4+u,-26,12);target=Vector((0,8,4));focus=[obj for obj,l,k in nodes];lens=42
                        badges=['One linked candidate trajectory']
                    elif t<event('But what happens'):
                        job='candidate_world_detail';cam.location=(16-u,-7,9);target=Vector((7.5,8,3.7));focus=[worlds[2][0]];lens=40
                        badges=['Linked interactions toward a goal']
                    else:
                        job='road_user_handoff';cam.location=(13-u,-20,8);target=Vector((3,-3,1));focus=[car,cycle];lens=39
                else:
                    if t<event('Look back at the road'):
                        job='threshold_and_pruning';cam.location=(5-u,-28,13);target=Vector((0,10,4.5));focus=[obj for obj,l,k in nodes if max(obj.scale)>.05];lens=39
                        badges=['Below threshold: stop developing' if t>event('This is pruning') else 'Illustrative candidates']
                        if t>=event('This is pruning'):
                            job='pruning_consequence';cam.location=(-13+u,-26,14);target=Vector((0,8,4));lens=40
                    elif t<event('The method describes'):
                        job='road_users_remain';cam.location=(13-u,-21,8);target=Vector((1,-3,1));focus=[car,ped,cycle];lens=38
                        badges=['Candidates removed · road users remain']
                    else:
                        job='promising_branch_detail';cam.location=(12-u,-29,14);target=Vector((2,8,4));focus=[obj for obj,l,k in nodes if max(obj.scale)>.05];lens=40
                        badges=['Focused search · no measured saving']
            elif mode=='attention':
                halo.location=cycle.location+Vector((0,0,.03))
                spline=relevance.data.splines[0];spline.points[1].co=(*tuple(cycle.location+Vector((0,0,1))),1)
                relevance.data.bevel_depth=.04*(1-.8*smooth((t-at_group(4))/1.2)+.8*smooth((t-at_group(6))/1.2))
                if group_index<2:
                    job='road_user_question';target=Vector((3,-3,1));cam.location=(13-u,-24,9);focus=[car,cycle];lens=39
                elif group_index<4:
                    job='cyclist_remains_close';target=cycle.location+Vector((0,0,1));cam.location=cycle.location+Vector((-4.5,-7,3));focus=[cycle];lens=43
                elif group_index<6:
                    job='relevance_not_deletion';target=(car.location+cycle.location)*.5+Vector((0,0,.8));cam.location=target+Vector((9-u,-22,8));focus=[car,cycle];lens=39
                else:
                    job='changing_interaction_context';target=(car.location+cycle.location)*.5+Vector((0,0,.8));cam.location=target+Vector((-10+u,-21,9));focus=[car,cycle];lens=39
                badges=['Road user stays represented']
            else:
                p=pose(t,D);x,y=car.location[:2];forward=Vector((-math.sin(p['ev'][2]),math.cos(p['ev'][2]),0));right=Vector((math.cos(p['ev'][2]),math.sin(p['ev'][2]),0))
                if t<event('The road user.'):
                    job='retrieval_question';cam.location=(-13+u,-21,9);target=Vector((2,-4,1));focus=[car,cycle];lens=39
                elif t<6.7:
                    job='retrieval_answer';target=cycle.location+Vector((0,0,.8));cam.location=cycle.location+Vector((-4.5,-7,3));focus=[cycle];lens=43
                elif t<event('Our car can finish')+1.8:
                    job='cleared_turn';target=car.location+forward+Vector((0,0,.65));cam.location=car.location-forward*8+right*5+Vector((0,0,3.5));focus=[car];lens=42
                elif t<event('We can understand'):
                    job='mechanical_turn_detail';target=car.location+right*.91+forward*1.42+Vector((0,0,.34));cam.location=target+right*2.6-forward*.5+Vector((0,0,.6));focus=[frontwheel];lens=43
                else:
                    job='resolved_turn';target=car.location+forward+Vector((0,0,.7));cam.location=car.location-forward*9+right*5+Vector((0,0,3.8));focus=[car];lens=43
                badges=['Illustrative turn · active supervision required'] if group_index>=4 else []
        elif mode=='hardware':
            for marker,track,i in packets:
                q=(t*.25+i*.23)%1;points=track.data.splines[0].points
                if q<.5:marker.location=Vector(points[0].co[:3]).lerp(Vector(points[1].co[:3]),q*2)
                else:marker.location=Vector(points[1].co[:3]).lerp(Vector(points[2].co[:3]),(q-.5)*2)
            if group_index<2:
                job='fixed_module';cam.location=(7-u,-11,9);target=Vector((0,-1,2.5));focus=[board];lens=43
            elif t<event('The document does not'):
                job='whole_system_functions';cam.location=(9-u,-17,12);target=Vector((0,2,3));focus=[board];lens=40
                badges=['Planning is one system function']
            elif t<event('Those need separate'):
                job='disclosure_limit';cam.location=(7-u,-13,12);target=Vector((2,0,2.5));focus=[board];lens=40
                badges=['No HW3 / V14 / 80% result established']
            elif t>=event('The useful check'):
                job='release_evidence_detail';cam.location=(13-u,-7,10);target=Vector((6.5,-1,2.5));focus=[];lens=40
                badges=['Match release and vehicle eligibility']
            else:
                job='evidence_workbench';cam.location=(-8+u,-17,13);target=Vector((0,.6,2.5));focus=[board];lens=40
                badges=['Application ≠ deployed feature','Active driver supervision required']
        else:
            # Replay boundaries are camera cuts, not a false continuous journey.
            switches=[0,event('Compare these'),event('Those factors'),event('A score is useful')]
            phase=max(i for i,start in enumerate(switches) if start<=t);start=switches[phase]
            period=max(3.5,(switches[phase+1] if phase+1<len(switches) else D)-start-.4)
            q=max(0,min(1,(t-start)/period))
            for i,car_i in enumerate(cars):
                progress=motion_progress(q,['abrupt','gradual'][i]);car_i.location=([-7.5,7.5][i],-8+16*progress,.1);wheel_roll(car_i,16*progress)
                for j,tick in enumerate(study_markers[i]):tick.hide_render=j/6>q
            if phase in [0,2]:
                job='equal_time_comparison';cam.location=(17-u,-27,20);target=Vector((0,0,1));focus=cars;lens=38
            elif phase==1:
                job='comparison_replay';cam.location=(-17+u,-25,16);target=Vector((0,0,1));focus=cars;lens=37
            else:
                job='consequences_before_scores';target=cars[1].location+Vector((0,.5,.7));cam.location=cars[1].location+Vector((4.5-u,-6,2.7));focus=[cars[1]];lens=40
            badges=['Equal distance / time · illustrative motion study'+(' · replay' if phase else '')]
            if phase==3:badges=['Follow the candidate behavior']
            factors=['Physics constraints','Comfort','Intervention likelihood','Human-like behavior']
            factor_start=event('The application describes scoring factors')
            factor_end=event('Those factors')
            if factor_start<=t<factor_end:
                badges.append(factors[min(3,int((t-factor_start)/(factor_end-factor_start)*4))])
            elif t>=factor_end:badges.append('Physics · comfort · intervention · human-like behavior')
        # Primary-subject envelopes prevent unnoticed edge clipping in every frame.
        cam.data.lens=lens*scales.get(job,1);aim(cam,target);bpy.context.view_layer.update();ratio=1.
        visibility_jobs={'road_user_question','cyclist_remains_close','relevance_not_deletion','changing_interaction_context','road_users_remain','road_user_handoff','retrieval_question','retrieval_answer'}
        if is_street and job in visibility_jobs and f%5==0:
            graph=bpy.context.evaluated_depsgraph_get();seen=False;blockers=[]
            for target_obj in [cyclist_torso,cyclist_head]:
                location=target_obj.matrix_world.translation;direction=location-cam.location
                hit,point,normal,index,obj,matrix=s.ray_cast(graph,cam.location,direction.normalized(),distance=direction.length+.05)
                original=obj.original if obj is not None else None
                if hit and (original==cycle or original in cycle.children_recursive):seen=True
                elif hit:blockers.append(original.name)
            visibility[f]={'seen':seen,'job':job,'blockers':blockers}
        for obj in focus:
            if obj.type=='EMPTY':
                if obj.get('vehicle_part')=='wheel':bounds=[(x,y,z) for x in [-.2,.2] for y in [-.38,.38] for z in [-.38,.38]]
                elif mode=='hardware':bounds=[(x,y,z) for x in [-2.6,2.6] for y in [-1.9,1.9] for z in [-.25,.5]]
                elif obj.name.startswith('Candidate world'):bounds=[(x,y,z) for x in [-2.7,2.7] for y in [-2.9,2.9] for z in [-.4,1.8]]
                elif is_street and obj==cycle:bounds=[(x,y,z) for x in [-.5,.5] for y in [-1,1] for z in [0,1.9]]
                elif is_street and obj==ped:bounds=[(x,y,z) for x in [-.5,.5] for y in [-.4,.4] for z in [0,1.9]]
                else:bounds=[(x,y,z) for x in [-1.15,1.15] for y in [-2.4,2.4] for z in [0,1.8]]
            else:bounds=obj.bound_box
            for corner in bounds:
                point=world_to_camera_view(s,cam,obj.matrix_world@Vector(corner));assert point.z>0,('Primary subject behind camera',f,job)
                ratio=min(ratio,.45/max(abs(point.x-.5),1e-8),.40/max(abs(point.y-.5),1e-8))
        for text,obj in labels:
            if isinstance(obj,Vector):pos=obj
            else:
                if obj.hide_render or max(obj.scale)<.05:continue
                pos=obj.matrix_world.translation+Vector((0,0,1.7))
            point=world_to_camera_view(s,cam,pos)
            if point.z>0 and .06<point.x<.94 and .1<point.y<.85:callouts.append([text,point.x,1-point.y])
        poses[f]={'camera_job':job,'focal_ratio':ratio,'labels':callouts,'badges':badges,'group':group_index,'count':count}
        return ratio
    for attempt in range(3):
        for f in range(NF):apply(f)
        bad=[p for p in poses.values() if p['focal_ratio']<.999]
        if not bad:break
        for job in {p['camera_job'] for p in poses.values()}:
            ratio=min(p['focal_ratio'] for p in poses.values() if p['camera_job']==job)
            if ratio<1:scales[job]=scales.get(job,1)*ratio*.97
    assert not bad,('Framing repair exhausted',shot['id'])
    hidden=[f for f,v in visibility.items() if not v['seen']]
    assert len(hidden)<=max(1,len(visibility)*.1),('Cyclist teaching view is occluded',shot['id'],{f:visibility[f] for f in hidden[:8]})
    write(folder/'poses.json',poses)
    write(folder/'scene-qa.json',{'passed':True,'frames':NF,'all_frame_primary_bounds':True,'camera_jobs':list(dict.fromkeys(p['camera_job'] for p in poses.values())),'lens_scales':scales,'minimum_pedestrian_clearance':min_clearance if is_street else None,'cyclist_teaching_view_visibility':{'sampled_every_frames':5,'tested':len(visibility),'head_or_torso_visible':len(visibility)-len(hidden),'blocked_samples':{f:visibility[f] for f in hidden}},'mode':mode,'native_animation':True,'persistent_data':False,'accuracy':'Original schematic models. No Tesla scores, timing, software or utilization measurements. Road-user visibility is an illustrative distinction, not a perception guarantee.'})
    deps=[Path(__file__),ROOT/'rich_scene.py',ROOT.parents[1]/'revision_motion.py',ROOT.parents[1]/'vehicle_prop.py',ROOT.parents[1]/'compute_scene.py',ROOT.parents[1]/'traffic_scene.py',ROOT.parents[1]/'visual_tools.py',ROOT.parents[1]/'turn_motion.py']
    stamp={'sources':{str(p.relative_to(ROOT.parents[2])):hashlib.sha256(p.read_bytes()).hexdigest() for p in deps},'voice':shot['voice_sha256'],'shot':hashlib.sha256(str(shot).encode()).hexdigest(),'settings':{k:manifest[k] for k in ['width','height','render_samples','fps']}}
    raw=folder/'raw';raw.mkdir(exist_ok=True)
    if any(raw.glob('*.png')):assert read(folder/'render-source.json')==stamp,'Source changed: do not mix frame versions'
    write(folder/'render-source.json',stamp)
    points={0,NF-1,*[min(NF-1,round(g['start']*30)) for g in groups]}
    selected=sorted(points) if args.stills else args.frames if args.frames is not None else range(NF)
    for f in selected:
        path=raw/f'{f:06d}.png'
        if path.exists():continue
        apply(f);s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
    print('REVISION CHAPTER READY',shot['id'],'diagnostics' if args.stills else 'rendered',flush=True)


if __name__=='__main__':main()
