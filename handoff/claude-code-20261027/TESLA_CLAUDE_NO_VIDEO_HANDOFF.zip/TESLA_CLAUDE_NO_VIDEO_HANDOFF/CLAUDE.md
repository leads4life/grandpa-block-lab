# No-video Tesla production handoff

Read README.md, CLAUDE_CODE_PROMPT.md, COLAB_AND_VOICE.md and handoff/USER_BRIEF.md. The user clarified: no video files; include Colab, JSON, voice and all files/instructions needed for production. This ZIP has those sources/assets/frozen narration and no MP4 files or old-media downloader. Keep historical approval records truthful. The prompt authorizes the new task when the user invokes it. No music or narration captions. Dynamic3D and the selected am_fenrir voice remain required. No YouTube upload is authorized.
