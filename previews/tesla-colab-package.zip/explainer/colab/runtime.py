"""Validate a packaged project, reuse checked clips, and render missing chapters."""
from pathlib import Path
import argparse,hashlib,importlib,json,os,runpy,subprocess,sys,tempfile

REPO=Path(__file__).resolve().parents[2]
PROJECT=REPO/'explainer/projects/tesla-hw3'
OUT=PROJECT/'build/full-v1'

def read(p):return json.loads(Path(p).read_text())
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as stream:
        while chunk:=stream.read(1024*1024):h.update(chunk)
    return h.hexdigest()

def verify():
    package=read(REPO/'COLAB_PACKAGE.json')
    for name,expected in package['sha256'].items():
        p=(REPO/name).resolve()
        if not p.is_relative_to(REPO):raise ValueError('Package path escapes extraction directory')
        if not p.is_file() or sha(p)!=expected:raise ValueError('Missing or changed package file: '+name)
    print('Verified package files:',len(package['sha256']),flush=True)
    return package

def choose_device():
    if os.environ.get('EXPLAINER_FORCE_CPU')=='1':return {'device':'CPU','backend':None,'names':['CPU'],'forced':True}
    import bpy
    prefs=bpy.context.preferences.addons['cycles'].preferences
    errors=[]
    for backend in ['OPTIX','CUDA','HIP','ONEAPI','METAL']:
        try:
            prefs.compute_device_type=backend;prefs.get_devices()
            devices=[d for d in prefs.devices if d.type==backend]
            if devices:
                for d in prefs.devices:d.use=d.type==backend
                return {'device':'GPU','backend':backend,'names':[d.name for d in devices]}
        except Exception as e:errors.append(backend+': '+str(e))
    return {'device':'CPU','backend':None,'names':['CPU'],'gpu_available':False,'probe_notes':errors}

def install_device_handler(device):
    import bpy
    from bpy.app.handlers import persistent
    @persistent
    def configure(scene,*unused):
        if device['device']=='GPU':
            prefs=bpy.context.preferences.addons['cycles'].preferences
            if prefs.compute_device_type!=device['backend']:
                prefs.compute_device_type=device['backend'];prefs.get_devices()
            for d in prefs.devices:d.use=d.type==device['backend']
        scene.cycles.device=device['device'];scene.render.threads_mode='AUTO'
        scene.render.use_persistent_data=False
    bpy.app.handlers.render_pre.append(configure)
    return configure

def smoke():
    import bpy
    device=choose_device();handler=install_device_handler(device)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=1
    scene.render.resolution_x=64;scene.render.resolution_y=64;scene.render.resolution_percentage=100
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8)
    bpy.ops.object.camera_add(location=(0,-5,2));camera=bpy.context.object
    camera.rotation_euler=(1.19,0,0);scene.camera=camera
    with tempfile.TemporaryDirectory() as temp:
        scene.render.filepath=str(Path(temp)/'device-smoke.png')
        bpy.ops.render.render(write_still=True)
        assert Path(scene.render.filepath).exists(),'Renderer did not produce an image'
        assert scene.cycles.device==device['device'],'Device handler was not retained after scene reset'
    bpy.app.handlers.render_pre.remove(handler)
    print(json.dumps(device,indent=2),flush=True)
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'colab-device.json').write_text(json.dumps(device,indent=2)+'\n')
    return device

def render(index):
    device=choose_device();install_device_handler(device)
    print('Render device:',json.dumps(device),flush=True)
    sys.argv=['render_film_chapter','--index',str(index)]
    runpy.run_module('explainer.projects.tesla-hw3.render_film_chapter',run_name='__main__')

def resume():
    package=verify()
    # Validate the original review's content hashes after relocating files. This
    # preserves the original inspection record instead of inventing a new review.
    review=read(OUT/'preflight-review.json')
    for original,expected in review['source_hashes'].items():
        marker='/explainer/'
        if marker not in original:raise ValueError('Unrecognized reviewed source path: '+original)
        target=REPO/'explainer'/original.split(marker,1)[1]
        if not target.is_file() or sha(target)!=expected:raise ValueError('Reviewed source changed: '+str(target))
    if sha(OUT/'manifest.json')!=review['manifest_sha256']:raise ValueError('Reviewed production manifest changed')
    manifest=read(OUT/'manifest.json')
    producer=importlib.import_module('explainer.projects.tesla-hw3.produce_film')
    media=importlib.import_module('explainer.media')
    videos=[]
    for shot in manifest['shots']:
        if shot['index']==0:
            video=PROJECT/'build/opening-v2/tesla-opening-v2.mp4'
            if sha(video)!=package['sha256'][str(video.relative_to(REPO))]:raise ValueError('Approved opening changed')
        else:
            folder=OUT/shot['id'];video=folder/'chapter.mp4';qa=folder/'qa.json'
            ready=qa.exists() and video.exists() and read(qa).get('passed')
            if ready:
                if read(qa)['voice_sha256']!=shot['voice_sha256']:raise ValueError('Narration mismatch')
                print('Reuse checked chapter:',shot['id'],flush=True)
            else:
                print('Render missing chapter:',shot['id'],flush=True)
                subprocess.run([sys.executable,'-m','explainer.colab.runtime','render','--index',str(shot['index'])],check=True,cwd=REPO)
                video=producer.encode(shot)
        videos.append(video)
    result=OUT/'tesla-planning-complete.mp4'
    media.assemble(videos,[s['seconds'] for s in manifest['shots']],result)
    qa=media.check_video(result,manifest['seconds'],manifest['width'],manifest['height'])
    if not qa['passed']:raise ValueError(qa)
    qa.update(review='pending_actual_final_video_inspection',scope='Complete film',chapters=len(videos),execution_environment='Colab portable adapter')
    producer.write(OUT/'final-qa.json',qa)
    producer.write(OUT/'pipeline-state.json',{'stage':'complete_media_pending_final_inspection','video':str(result),'automatic_publication':False})
    importlib.import_module('explainer.projects.tesla-hw3.final_review_packet').main()
    importlib.import_module('explainer.projects.tesla-hw3.export_project_json').export()
    print('COMPLETE VIDEO:',result,'\nActual final inspection is still required.',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['verify','smoke','render','resume']);parser.add_argument('--index',type=int);args=parser.parse_args()
    os.chdir(REPO)
    if args.command=='verify':verify()
    elif args.command=='smoke':smoke()
    elif args.command=='render':
        if args.index is None:parser.error('--index is required for render')
        render(args.index)
    else:resume()
