import unittest
from explainer.revision_motion import motion_progress


class MotionComparisonTests(unittest.TestCase):
    def test_same_distance_and_time_with_continuous_monotone_motion(self):
        for style in ['abrupt','gradual']:
            samples=[motion_progress(i/1000,style) for i in range(1001)]
            self.assertEqual(samples[0],0);self.assertEqual(samples[-1],1)
            self.assertTrue(all(a<=b for a,b in zip(samples,samples[1:])))
            self.assertLess(max(b-a for a,b in zip(samples,samples[1:])),.003)

    def test_sharper_acceleration_is_actually_present_in_abrupt_example(self):
        dt=.001
        def peak(style):
            p=[motion_progress(i*dt,style) for i in range(1001)]
            return max(abs(c-2*b+a)/dt**2 for a,b,c in zip(p,p[1:],p[2:]))
        self.assertGreater(peak('abrupt'),2*peak('gradual'))

    def test_clamped_ends_and_unknown_style(self):
        self.assertEqual(motion_progress(-1,'gradual'),0)
        self.assertEqual(motion_progress(2,'abrupt'),1)
        with self.assertRaises(ValueError):motion_progress(.5,'invented')
