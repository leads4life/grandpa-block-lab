"""python -m explainer --help"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import sys
from .core import VOICE, contained, digest, fingerprint, read, storyboard, validate, write


def import_plan(text):
    """Import storyboard table rows as drafts; never treat attachment instructions as code."""
    shots = []
    for line in text.splitlines():
        cells = [x.strip().replace('**', '') for x in line.strip().strip('|').split('|')]
        if len(cells) != 4:
            continue
        match = re.fullmatch(r'(\d+):(\d\d)\s*[–—-]\s*(\d+):(\d\d)', cells[0])
        if not match:
            continue
        a, b, c, d = map(int, match.groups())
        shots.append({'id': f'shot_{len(shots)+1:03d}', 'duration': (c*60+d)-(a*60+b),
                      'narration': cells[2], 'visual_intent': cells[1], 'audio_notes': cells[3],
                      'teaches': '', 'accuracy': 'schematic', 'simplifications': [], 'claim_ids': [],
                      'visual_type': 'assembly', 'components': [], 'labels': [], 'asset_ids': [],
                      'camera': {'position': [6, -8, 5], 'target': [0, 0, 0], 'lens': 50}})
    return shots


def require_valid(plan, root):
    errors = validate(plan, root)
    if errors:
        raise ValueError('\n'.join(errors))


def current_approval(root, plan, stage):
    path = root / 'approvals' / f'{stage}.json'
    if not path.exists() or read(path)['fingerprint'] != fingerprint(plan, root):
        raise ValueError(f'Current {stage} approval required; changes invalidate prior approval')
    record = read(path)
    if stage == 'preview':
        artifact = contained(root, record['artifact'])
        if hashlib.sha256(artifact.read_bytes()).hexdigest() != record['artifact_sha256']:
            raise ValueError('Approved preview artifact changed')
    return record


def artifact_dir(root, plan, mode):
    return root / 'build' / fingerprint(plan, root)[:16] / mode


def contact_sheet(frames, out):
    from PIL import Image, ImageOps, ImageDraw
    paths = sorted(Path(frames).glob('*.png'))
    if not paths:
        raise ValueError('Renderer produced no frames')
    canvas = Image.new('RGB', (960, 206), '#141820')
    draw = ImageDraw.Draw(canvas)
    for i, index in enumerate([0, len(paths)//2, len(paths)-1]):
        with Image.open(paths[index]) as image:
            image = ImageOps.contain(image.convert('RGB'), (320, 180))
            canvas.paste(image, (i*320, 0))
        draw.text((i*320+8, 185), f'Frame {index}', fill='white')
    canvas.save(out)


def image_frames(asset, root, out, width, height, frames):
    from PIL import Image, ImageOps
    directory = out / 'frames'
    directory.mkdir(parents=True, exist_ok=True)
    with Image.open(contained(root, asset['path'])) as image:
        image = ImageOps.pad(image.convert('RGB'), (width, height), color='#141820')
        for f in range(frames):
            image.save(directory / f'{f:06d}.png')


def prepare_narration(root, plan):
    """Measure before storyboard approval; extend shots without changing speech speed."""
    from .media import voice
    prepared = []
    for shot in plan['shots']:
        directory = root / 'build' / 'preparation' / shot['id']
        evidence = voice(shot, directory)
        shot['duration'] = max(shot['duration'], math.ceil((evidence['seconds'] + .35) * 30) / 30)
        prepared.append((shot['id'], directory, evidence))
    plan['narration_lock'] = {sid: evidence for sid, _, evidence in prepared}
    write(root / 'plan.json', plan)
    for sid, directory, _ in prepared:
        frozen = artifact_dir(root, plan, 'voice') / sid
        frozen.mkdir(parents=True, exist_ok=True)
        for name in ('voice.wav', 'voice.json'):
            shutil.copy2(directory / name, frozen / name)
    return plan


def produce(root, plan, shot, mode):
    from .media import check_video, encode, mix_mechanical, voice
    production_hash = fingerprint(plan, root)
    width, height = (640, 360) if mode == 'preview' else (1920, 1080)
    fps = 30
    out = artifact_dir(root, plan, mode) / shot['id']
    out.mkdir(parents=True, exist_ok=True)
    # Artifacts are only reused in a directory bound to the complete production fingerprint.
    frozen = artifact_dir(root, plan, 'voice') / shot['id']
    evidence_path = frozen / 'voice.json'
    if evidence_path.exists() and (frozen / 'voice.wav').exists():
        evidence = read(evidence_path)
        if evidence['sha256'] != hashlib.sha256((frozen / 'voice.wav').read_bytes()).hexdigest():
            raise ValueError('Frozen voice bytes changed; regenerate this artifact directory')
    else:
        evidence = voice(shot, frozen)
    shutil.copy2(frozen / 'voice.wav', out / 'voice.wav')
    shutil.copy2(frozen / 'voice.json', out / 'voice.json')
    locked = plan.get('narration_lock', {}).get(shot['id'])
    if locked is not None and evidence != locked:
        raise ValueError('Narration differs from the storyboard performance; prepare and approve again')
    if evidence['seconds'] + .2 > shot['duration']:
        raise ValueError(f'{shot["id"]}: measured speech needs {evidence["seconds"]+.2:.2f}s; '
                         'extend shot duration and regenerate storyboard; never speed speech to fit')
    nf = round(shot['duration'] * fps)
    if nf < 2:
        raise ValueError('Shot must contain at least two frames')
    duration = nf / fps
    if shot.get('visual_type', 'assembly') == 'image':
        image_frames(plan['assets'][shot['asset_ids'][0]], root, out, width, height, nf)
    else:
        from .blender_backend import render
        render(shot, out, width, height, fps, nf, samples=4 if mode == 'preview' else 64,
               assets=plan.get('assets', {}), project_root=root)
    expected = {f'{n:06d}.png' for n in range(nf)}
    actual = {p.name for p in (out / 'frames').glob('*.png')}
    if actual != expected:
        raise ValueError('Frame sequence is incomplete or contains unexpected frames')
    from PIL import Image, ImageStat
    for index in sorted({0, nf // 2, nf - 1}):
        with Image.open(out / 'frames' / f'{index:06d}.png') as image:
            image.load()
            if image.size != (width, height) or max(ImageStat.Stat(image.convert('RGB')).stddev) < 1:
                raise ValueError(f'Blank or invalid diagnostic frame {index}; investigate before review')
    contact_sheet(out / 'frames', out / 'contact-sheet.png')
    audio = mix_mechanical(shot, out / 'voice.wav', out / 'mix.wav', duration)
    output = out / 'video.mp4'
    # A failed media check triggers a bounded encode retry. Geometry errors use backend repairs.
    attempts = []
    gain_db = 0
    for attempt in range(4):
        encode(out / 'frames', audio, duration, output, fps, gain_db=gain_db)
        report = check_video(output, duration, width, height, fps)
        attempts.append(dict(report))
        if report['passed']:
            break
        gain_db += -14 - report['lufs']
        gain_db = max(-20, min(30, gain_db))
        # Only audio normalization/encoding failures are safe to repair by re-encoding.
        if any(not value for key, value in report['checks'].items() if key not in ('loudness', 'no_clipping')):
            break
    if fingerprint(plan, root) != production_hash:
        raise ValueError('Production inputs changed during rendering; discard this run and rebuild')
    report.update({'attempts': attempts.copy(), 'fingerprint': production_hash,
                   'artifact_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                   'shot': shot['id'], 'mode': mode,
                   'visual_review': 'pending', 'technical_review': 'pending'})
    write(out / 'qa.json', report)
    if not report['passed']:
        raise ValueError(f'Media QA failed: {out / "qa.json"}')
    return out


def main(argv=None):
    parser = argparse.ArgumentParser(description='Technical explainer production architecture')
    sub = parser.add_subparsers(dest='command', required=True)
    init = sub.add_parser('init', help='Create a draft project; optionally ingest a supplied Markdown storyboard')
    init.add_argument('project'); init.add_argument('--title', required=True); init.add_argument('--source')
    for name in ['validate', 'prepare', 'storyboard', 'status', 'final', 'credits']:
        p = sub.add_parser(name); p.add_argument('project')
    register = sub.add_parser('register-model', help='Copy a free/commercial licensed local model package; visual review stays pending')
    register.add_argument('project'); register.add_argument('asset_id'); register.add_argument('model')
    register.add_argument('--rights', required=True); register.add_argument('--evidence', required=True)
    register.add_argument('--meters-per-unit', required=True, type=float)
    register.add_argument('--units-notes', required=True)
    preview = sub.add_parser('preview', help='Render a complete representative shot at preview resolution')
    preview.add_argument('project'); preview.add_argument('--shot', required=True)
    review = sub.add_parser('review', help='Record Codex visual and technical inspection after opening the output')
    review.add_argument('project'); review.add_argument('--shot', required=True)
    review.add_argument('--notes', required=True)
    approve = sub.add_parser('approve', help='Record explicit user approval; never run without actual user approval')
    approve.add_argument('project'); approve.add_argument('stage', choices=['storyboard', 'preview'])
    approve.add_argument('--user-evidence', required=True, help='Reference/quote the actual user approval')
    approve.add_argument('--shot')
    args = parser.parse_args(argv)
    root = Path(args.project).resolve()
    if args.command == 'init':
        if root.exists():
            raise ValueError('Project already exists; refusing to overwrite')
        text = Path(args.source).read_text() if args.source else ''
        root.mkdir(parents=True)
        (root / 'assets').mkdir()
        if args.source:
            (root / 'supplied-plan.md').write_text(text)
        plan = {'version': 1, 'title': args.title, 'learning_goal': '',
                'format': {'width': 1920, 'height': 1080, 'fps': 30, 'captions': False},
                'narrator': VOICE, 'runtime_policy': 'subject_determined',
                'audio_policy': {'music': False, 'sfx': 'restrained_mechanical'},
                'retention_required': True,
                'subject_bible': {'scope': '', 'mechanism': '', 'terminology': '',
                                  'narration_guidance': '', 'simplifications': ''},
                'sources': {}, 'claims': {}, 'assets': {}, 'open_questions': [], 'shots': import_plan(text)}
        write(root / 'plan.json', plan)
        print(f'Draft created: {root / "plan.json"}; supplied text is unverified reference material')
        return
    plan = read(root / 'plan.json')
    if args.command == 'register-model':
        from .assets import register_model
        register_model(root, args.asset_id, args.model, read(args.rights), args.evidence, args.meters_per_unit, args.units_notes)
        print('Model package registered; inspect it before changing review from pending to approved')
    elif args.command == 'credits':
        from .assets import credits, model_errors
        for asset in plan.get('assets', {}).values():
            if asset.get('kind') == 'model':
                errors = model_errors(asset, root)
                if errors: raise ValueError('\n'.join(errors))
        (root / 'CREDITS.md').write_text(credits(plan))
        print(root / 'CREDITS.md')
    elif args.command == 'validate':
        errors = validate(plan, root)
        print('\n'.join(errors) if errors else 'Plan contract passed (does not certify factual truth)')
        if errors:
            raise ValueError(f'{len(errors)} production blockers')
    elif args.command == 'status':
        statuses = {}
        for stage in ['storyboard', 'preview']:
            try:
                current_approval(root, plan, stage)
                statuses[stage] = 'approved for current fingerprint'
            except (ValueError, FileNotFoundError):
                statuses[stage] = 'missing or stale'
        from .retention import audit
        print(json.dumps({'blockers': validate(plan, root), 'approvals': statuses,'retention':audit(plan)}, indent=2))
    elif args.command == 'prepare':
        require_valid(plan, root)
        prepare_narration(root, plan)
        print('Narration frozen and shot durations fitted; generate the storyboard for approval next')
    elif args.command == 'storyboard':
        require_valid(plan, root)
        (root / 'storyboard.md').write_text(storyboard(plan))
        print(root / 'storyboard.md')
    elif args.command == 'preview':
        require_valid(plan, root)
        current_approval(root, plan, 'storyboard')
        shot = next((s for s in plan['shots'] if s['id'] == args.shot), None)
        if shot is None:
            raise ValueError('Unknown shot')
        out = produce(root, plan, shot, 'preview')
        print(f'Internal preview built: {out}; inspect contact sheet AND full video before review')
    elif args.command == 'review':
        require_valid(plan, root)
        if args.shot not in {shot['id'] for shot in plan['shots']}:
            raise ValueError('Unknown shot')
        out = artifact_dir(root, plan, 'preview') / args.shot
        report = read(out / 'qa.json')
        if report.get('fingerprint') != fingerprint(plan, root) or not report['passed'] or report['artifact_sha256'] != hashlib.sha256((out / 'video.mp4').read_bytes()).hexdigest():
            raise ValueError('Current passing media QA required')
        report.update({'visual_review': 'passed', 'technical_review': 'passed', 'review_notes': args.notes})
        write(out / 'qa.json', report)
        print('Codex review recorded; ready to present for user preview approval')
    elif args.command == 'approve':
        require_valid(plan, root)
        if plan.get('retention_required'):
            from .retention import require
            require(plan,review=True)
        record = {'fingerprint': fingerprint(plan, root), 'user_evidence': args.user_evidence}
        if args.stage == 'storyboard':
            expected = storyboard(plan)
            if not (root / 'storyboard.md').exists() or (root / 'storyboard.md').read_text() != expected:
                raise ValueError('Generate and present the current storyboard first')
        else:
            current_approval(root, plan, 'storyboard')
            if not args.shot:
                raise ValueError('Preview approval requires --shot')
            if args.shot not in {shot['id'] for shot in plan['shots']}:
                raise ValueError('Unknown shot')
            out = artifact_dir(root, plan, 'preview') / args.shot
            report = read(out / 'qa.json')
            video = out / 'video.mp4'
            video_hash = hashlib.sha256(video.read_bytes()).hexdigest()
            if (report.get('fingerprint') != fingerprint(plan, root) or not report['passed'] or
                report['visual_review'] != 'passed' or report['technical_review'] != 'passed' or
                report['artifact_sha256'] != video_hash):
                raise ValueError('Preview must pass current automated, visual and technical checks')
            record.update({'artifact': str(video.relative_to(root)), 'artifact_sha256': video_hash, 'shot': args.shot})
        write(root / 'approvals' / f'{args.stage}.json', record)
        print(f'{args.stage} user approval recorded for this version')
    elif args.command == 'final':
        require_valid(plan, root)
        if plan.get('retention_required'):
            from .retention import require
            require(plan,review=True)
        current_approval(root, plan, 'storyboard')
        current_approval(root, plan, 'preview')
        from .assets import credits
        (root / 'CREDITS.md').write_text(credits(plan))
        outputs = [produce(root, plan, shot, 'final') for shot in plan['shots']]
        from .media import assemble, check_video
        out = artifact_dir(root, plan, 'final')
        final = out / 'assembled.mp4'
        durations = [round(s['duration']*30)/30 for s in plan['shots']]
        assemble([p / 'video.mp4' for p in outputs], durations, final)
        duration = sum(durations)
        report = check_video(final, duration, 1920, 1080)
        report['release_review'] = 'pending: inspect entire assembled video; publication is separate'
        write(out / 'assembled-qa.json', report)
        if not report['passed']:
            raise ValueError('Assembled video failed QA')
        print(f'Final assembly built; human/Codex release review still required: {final}')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, FileNotFoundError, KeyError) as exc:
        print(f'BLOCKED: {exc}', file=sys.stderr)
        sys.exit(1)
