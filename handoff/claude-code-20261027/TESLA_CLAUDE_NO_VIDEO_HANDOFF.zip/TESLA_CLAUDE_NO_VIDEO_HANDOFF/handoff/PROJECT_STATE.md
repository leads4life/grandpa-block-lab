# Written-only transfer scope

**No historical video files are included. Frozen narration and required source assets ARE included under the user’s final clarification.** The paths, statuses and hashes below describe what existed in the prior project. They are provenance and engineering context, not files the recipient can play from this ZIP. Do not claim direct inspection of absent media. Some copied historical manifests reference those missing binaries; they are not a promise of binary completeness or an immediately runnable media resume.

Source code, scripts, research, bibles, plans, original documents and QA/repair records are supplied. Generate new assets/narration and render a new production from the source, with its own validation. Do not automatically download the old archive or old videos.

---

# What exists and what remains

Snapshot date: October 27, 2026. Project paths below are relative to `repository/`.

## Completed main films

| Artifact | Path | State |
|---|---|---|
| Original completed v1 | `explainer/projects/tesla-hw3/build/full-v1/tesla-planning-complete.mp4` | 309.6s, 13 chapters,960×540 export,30fps. Media and decoded-sequence inspection recorded. Not final viewer acceptance. |
| Latest completed main v2 | `explainer/projects/tesla-hw3/build/full-v2/tesla-planning-v2.mp4` | 207.9667s, 8 chapters,6239 native frames. Native 768×432 exported 960×540,30fps. Final inspection/repair recorded. Not native 1080p, not final viewer acceptance. |
| Latest main JSON | `explainer/projects/tesla-hw3/build/full-v2/tesla-project-v2.json` | Source/script/scene/audio/QA snapshot of v2; binary media referenced separately. |
| Matching v2 Colab ZIP | `explainer/projects/tesla-hw3/deliverables/v2/tesla-colab-v2.zip` | All 8 completed chapter clips, frozen narration and sources; integrity checked locally. Actual Colab/GPU execution untested. |
| Original v1 Colab ZIP | `explainer/projects/tesla-hw3/deliverables/tesla-colab-package.zip` | Preserved historical package, including all 13 completed clips. |

SHA256 of final v1: `b67863c981cd765856b49959a5e72e348befe3639fbc3d8bce9b580b4aa3e53b`.

SHA256 of final v2: `427cb6bccd65c4fb7a7a13e71f6e832cfa5f3cf4c45fce9e5c65aa174c101b16`.

V2 audio measured -15.4LUFS, peak -2.1dBFS. Format/levels/hash/timing checks and decoded temporal-frame inspection were performed; direct real-time subjective listening was not claimed.

## New re-cut v3: proposal and opening study, not full film

Read `explainer/projects/tesla-recut-v3/recut-plan.md`, `recut-draft.json`, `audit-response.md` and `retention-draft.json`.

- Corrected 6-scene draft, 755 spoken words. At 179wpm that is approximately 253s before natural pauses; remaining scene times are editorial targets, not measured locks.
- Actual 33.2333s moving opening: `explainer/projects/tesla-recut-v3/build/opening-edit/tesla-recut-v3-opening-edit.mp4`.
- New frozen opening VO: selected `am_fenrir`, measured 185.56wpm, no time stretching.
- Seven edits reuse moving v2 footage. No new native 3D footage was rendered for this edit study. It is a narrative/composition test, not proof that all new final assets exist.
- Media QA passed (-15.4LUFS, -2.6dBFS). All 34 one-second decoded samples and a full-resolution split frame were opened. Subjective voice audition and user preview/storyboard decisions remain unrecorded.
- The user then requested migration to Claude Code. No entire v3 production started.
- Needed additions include final hardware-versus-search composition, a fourth 3-way branching stage if retained, sharper threshold-driven removal, a four-factor evaluation assembly, revised transitions and remaining narration.
- `preview_edit.py` is a bounded opening prototype. It does not implement a complete v3 producer. Do not run it expecting a whole film.

## Urban stress test

`explainer/projects/tesla-urban-stress/build/full-v2/tesla-urban-grit-stress-30s.mp4` now exists, with 900 native frames and identical original opening AAC audio. Media QA passed (-15.4LUFS,-2.9dBFS). The full 30s test's actual final visual review and user style approval remain pending. Do not inherit approval from the 8s peek.

The previously supplied8s moving peek is under `quick-peek-8s/`, and had a recorded decoded-image review. Weathered original procedural streets, graffiti, brick storefronts, utility details and revised cameras are implemented in this isolated project. They are not licensed game assets. Main-film source was not changed by that experiment.

## Known repairs and hazards

- V1: persistent-data cache produced 212 black-road frames; affected frames were re-rendered with that cache disabled. Keep `use_persistent_data=False` unless actually revalidated.
- V2: rooftop obscured the car near 199.8s. An earlier wheel-detail cut replaced 47 native r8 frames 342–388. A camera near-plane intersection with a rider sleeve in frame 347 required one isolated visibility correction. No trajectory, road-user state or narration changed. The final assembled AAC packets and timing match the pre-repair film exactly.
- Read `full-v2/final-inspection.json`, r8QA, `full-v2-camera-repair/`, `full-v2-camera-repair-single/` and `explainer/progress_media/final_camera*.py`.
- Original base native sequences are deliberately not copied into this transfer. Corrected finished clips, manifests, source, narration and repair evidence are included. Regenerating unpatched base code is not the same as regenerating the final repaired chapter. Apply or port the recorded repair, or author a fresh clean camera for the new version.
- All-frame bounds do not prove unobstructed visibility. A global low-motion detector can flag a sparse moving graph; do not silence a detector or claim every frame was watched. Inspect flagged periods.
- Background worker PIDs, old `/workspace` paths, progress timestamps and Git commit links are historical metadata, not live Claude processes.

## Research and capability limits

The retained patent and Tesla FSD text are in `explainer/projects/tesla-hw3/sources/`. Research supports the disclosed graph, scoring and pruning; it does not establish HW3/V14 deployment, 80% saving or hardware parity. Official earnings-call transcript/PDF access was previously incomplete; do not fabricate statements from those sources.

The engine supports procedural geometry, moving vehicle/human rigs, subject-specific graphs, simple local-plane sections, reviewed static GLB/glTF/OBJ/STL imports and original SFX. It is not a general automatic CAD reconstruction, mechanical constraint solver, fluid simulation or arbitrary source-animation retargeter. The visual-quality audit should identify which adapters or better props are actually needed.

## Intended next work

Read the user prompt and brief, inspect the actual material, make an evidence-based premium-quality audit, then create a separate new production version when the user invokes the supplied production prompt. Preserve v1/v2 and all original documents. Finish the whole film under the user's current scope; do not claim a proposal or opening test is the final re-cut.
