"""Build a portable snapshot without touching the active film render or caches."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib,json,shutil,sys,tempfile,zipfile

REPO=Path(__file__).resolve().parents[2]
PROJECT=REPO/'explainer/projects/tesla-hw3'
OUT=PROJECT/'build/full-v1'
DELIVERY=PROJECT/'deliverables'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        while data:=f.read(1024*1024):h.update(data)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())

def notebook():
    cells=[]
    def md(text):cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(True)})
    def code(text):cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':text.splitlines(True)})
    md('# Technical Explainer — Tesla production package\n\nUse **Runtime → Change runtime type → GPU** if available. Upload the matching ZIP below. This notebook reuses frozen narration and completed clips; it needs no AI API key. CPU fallback is supported. A successful encode still needs actual final visual review.\n\nThe package snapshot may have more completed chapters than the original preview. Colab execution itself has not been verified from this chat; the adapter has a local CPU render smoke test.')
    code('''from pathlib import Path
import hashlib, json, os, subprocess, sys, zipfile
from google.colab import files
uploaded = files.upload()
archives = [name for name in uploaded if name.lower().endswith('.zip')]
if len(archives) != 1:
    raise ValueError('Upload exactly one project ZIP.')
snapshot_id = hashlib.sha256(Path(archives[0]).read_bytes()).hexdigest()[:12]
PACKAGE_ROOT = Path('/content') / ('tesla_explainer_' + snapshot_id)
PACKAGE_ROOT.mkdir(exist_ok=True)
with zipfile.ZipFile(archives[0]) as bundle:
    entries = bundle.infolist()
    if len(entries) > 2500 or sum(x.file_size for x in entries) > 2 * 1024**3:
        raise ValueError('Archive exceeds the expected package limits.')
    for item in entries:
        target = (PACKAGE_ROOT / item.filename).resolve()
        if not target.is_relative_to(PACKAGE_ROOT.resolve()) or ((item.external_attr >> 16) & 0o170000) == 0o120000:
            raise ValueError('Unsafe archive entry: ' + item.filename)
    bundle.extractall(PACKAGE_ROOT)
print('Extracted:', PACKAGE_ROOT)
''')
    md('## Install the matching runtime\n\nThis creates a separate Python 3.13 environment. Frozen narration is already included, so the voice weights are unnecessary for this resume operation.')
    code('''subprocess.run([sys.executable, str(PACKAGE_ROOT / 'explainer/colab/bootstrap.py')], cwd=PACKAGE_ROOT, check=True)
RENDER_PYTHON = PACKAGE_ROOT / '.colab-render-venv/bin/python'
''')
    md('## Verify the render device\n\nThis renders a tiny diagnostic, rather than assuming a listed GPU works. If the GPU smoke test fails, set `USE_GPU = False` and rerun this cell for CPU rendering.')
    code('''USE_GPU = True
render_env = dict(os.environ, OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
render_env['EXPLAINER_FORCE_CPU'] = '0' if USE_GPU else '1'
subprocess.run([str(RENDER_PYTHON), '-m', 'explainer.colab.runtime', 'smoke'], cwd=PACKAGE_ROOT, env=render_env, check=True)
''')
    md('## See what will be reused')
    code('''project = PACKAGE_ROOT / 'explainer/projects/tesla-hw3'
production = project / 'build/full-v1'
manifest = json.loads((production / 'manifest.json').read_text())
for chapter in manifest['shots']:
    if chapter['index'] == 0:
        status = 'approved opening — reuse'
    else:
        folder = production / chapter['id']
        qa = folder / 'qa.json'
        ready = qa.exists() and (folder / 'chapter.mp4').exists() and json.loads(qa.read_text()).get('passed')
        status = 'completed clip — reuse' if ready else 'render missing chapter'
    print(f"{chapter['index'] + 1:02d}  {chapter['title']}: {status}")
''')
    md('## Resume production\n\nThe source and media checksums are validated first. Missing chapters are rendered with the detected device, encoded with the frozen narration, then assembled and checked. No footage is published automatically.')
    code('''subprocess.run([str(RENDER_PYTHON), '-m', 'explainer.colab.runtime', 'resume'], cwd=PACKAGE_ROOT, env=render_env, check=True)
''')
    md('## Watch and inspect the assembled film')
    code('''from IPython.display import Video, display
video = production / 'tesla-planning-complete.mp4'
display(Video(str(video), embed=True, width=960))
print('Inspection sheets:', production / 'final-inspection')
print('Master JSON:', production / 'tesla-project.json')
''')
    md('## Download outputs\n\nRun either download line when ready. The JSON describes the project and includes procedural source; audio/video remain separate files.')
    code("files.download(str(production / 'tesla-planning-complete.mp4'))\n")
    code("files.download(str(production / 'tesla-project.json'))\n")
    return {'nbformat':4,'nbformat_minor':5,'metadata':{'colab':{'name':'Tesla_Explainer_Colab.ipynb'},'kernelspec':{'name':'python3','display_name':'Python 3'},'language_info':{'name':'python'}},'cells':cells}

def build():
    DELIVERY.mkdir(exist_ok=True)
    importlib.import_module('explainer.projects.tesla-hw3.export_project_json').export()
    nb=notebook()
    for i,cell in enumerate(nb['cells']):
        cell['id']=f'cell-{i:02d}'
        if cell['cell_type']=='code':compile(''.join(cell['source']),f'notebook-cell-{i}','exec')
    notebook_file=DELIVERY/'Tesla_Explainer_Colab.ipynb';notebook_file.write_text(json.dumps(nb,indent=2)+'\n')
    manifest=read(OUT/'manifest.json')
    with tempfile.TemporaryDirectory(prefix='explainer-colab-') as temp:
        stage=Path(temp);included={};immutable={}
        def copy(source,relative=None,mutable=False):
            source=Path(source)
            if not source.is_file():return
            name=str(relative or source.relative_to(REPO));target=stage/name
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
            included[name]=sha(target)
            if not mutable:immutable[name]=included[name]
        for folder in ['explainer/colab','explainer/bibles','explainer/tests','explainer/examples']:
            for f in (REPO/folder).rglob('*'):
                if '__pycache__' not in f.parts and f.suffix in ['.py','.md','.json','.txt','.gltf','.obj','.mtl','.stl']:copy(f)
        for f in (REPO/'explainer').glob('*.py'):copy(f)
        for name in ['README.md','requirements.txt','AGENTS.md']:copy(REPO/'explainer'/name)
        for f in PROJECT.glob('*.py'):copy(f)
        for name in ['plan.json','full-production-storyboard.md','opening-review.md']:copy(PROJECT/name)
        copy(PROJECT/'production-state.json',mutable=True)
        for f in (PROJECT/'sources').glob('*.md'):copy(f)
        for f in (PROJECT/'review').rglob('*.json'):copy(f)
        archive=PROJECT/'build/visual-revision-archive-v1'
        for f in archive.glob('*.py'):copy(f)
        for f in (PROJECT/'build/renderer-source-history').glob('*.py'):copy(f)
        for name in ['manifest.json','preflight-review.json','CREDITS.md']:copy(OUT/name)
        copy(OUT/'tesla-project.json',mutable=True)
        copy(OUT/'pipeline-state.json',mutable=True)
        for name in ['qa.json','voice.wav','voice.json','tesla-opening-v2.mp4','scene-qa.json','render-source.json','poses.json']:copy(PROJECT/'build/opening-v2'/name)
        ready=[]
        for shot in manifest['shots'][1:]:
            folder=OUT/shot['id']
            for name in ['voice.wav','voice.json']:copy(folder/name)
            qa=folder/'qa.json';video=folder/'chapter.mp4'
            if qa.exists() and video.exists() and read(qa).get('passed'):
                for name in ['qa.json','chapter.mp4','scene-qa.json','render-source.json','poses.json','surface-repair.json']:copy(folder/name)
                ready.append(shot['id'])
        copy(notebook_file,'Tesla_Explainer_Colab.ipynb')
        copy(REPO/'explainer/colab/README.md','README_COLAB.md')
        package={'schema_version':'1.0','created_at_utc':datetime.now(timezone.utc).isoformat(),'project':'tesla-hw3','completed_chapters':ready,'approved_opening_included':True,
                 'runtime':'isolated Python 3.13; Blender bpy 5.2.3','native_render_frames_included':False,'frozen_narration_included':True,'voice_weights_included':False,
                 'validation':{'local_cpu_render_smoke':'passed','colab_execution':'not_run_here','gpu_execution':'not_verified_here'},
                 'sha256':immutable,'initial_file_sha256':included}
        (stage/'COLAB_PACKAGE.json').write_text(json.dumps(package,indent=2)+'\n')
        archive_file=DELIVERY/'tesla-colab-package.zip';temporary=archive_file.with_suffix('.zip.tmp')
        with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
            for f in sorted(stage.rglob('*')):
                if f.is_file():z.write(f,str(f.relative_to(stage)))
        with zipfile.ZipFile(temporary) as z:
            assert z.testzip() is None
            assert len(z.infolist())<2500
            for name,expected in package['sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
        temporary.replace(archive_file)
        (DELIVERY/'tesla-colab-package.sha256').write_text(sha(archive_file)+'  '+archive_file.name+'\n')
        print('COLAB PACKAGE READY:',archive_file,'bytes:',archive_file.stat().st_size,'completed chapters:',len(ready)+1,flush=True)
        return archive_file

if __name__=='__main__':build()
