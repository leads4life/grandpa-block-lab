"""Isolated r8 camera correction; preserve frozen source and native frame version."""
from pathlib import Path
import hashlib, json, sys

REPO = Path(__file__).resolve().parents[2]
PROJECT = REPO / 'explainer/projects/tesla-hw3'
ORIGINAL = PROJECT / 'build/full-v2'
REPAIR = PROJECT / 'build/full-v2-camera-repair-single'

def main():
    original = PROJECT / 'render_revision.py'
    text = original.read_text()
    old = "elif t<event('Our car can finish')+1.8:"
    new = "elif t<11.4:"
    assert text.count(old) == 1
    text = text.replace(old, new)
    roots = "ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v2'"
    assert text.count(roots) == 1
    text = text.replace(roots, f'ROOT=Path({str(PROJECT)!r});OUT=Path({str(REPAIR)!r})')
    render_call = 'apply(f);s.render.filepath=str(path);bpy.ops.render.render(write_still=True)'
    fixed_call = '''apply(f)
        origin=cam.matrix_world.translation.copy();target=frontwheel.matrix_world.translation.copy()
        direction=(target-origin).normalized();deps=bpy.context.evaluated_depsgraph_get()
        hit,loc,normal,face,obstacle,matrix=s.ray_cast(deps,origin,direction,distance=(target-origin).length)
        hero={car,*car.children_recursive}
        if hit and obstacle not in hero:
            obstacle.hide_render=True
            write(OUT/'occluder.json',{'object':obstacle.name,'frame':f,'reason':'Foreground structure between camera and teaching wheel'})
        s.render.filepath=str(path);bpy.ops.render.render(write_still=True)'''
    assert text.count(render_call)==1
    text=text.replace(render_call,fixed_call)
    REPAIR.mkdir(exist_ok=True)
    (REPAIR / 'manifest.json').write_bytes((ORIGINAL / 'manifest.json').read_bytes())
    metadata = {
        'purpose': 'Replace rooftop-obstructed following view with earlier wheel-detail cut; same actors, motion time and narration.',
        'original_renderer_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
        'repair_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'chapter': 'r8', 'frames': [347],
        'original_sources_modified': False, 'user_approval': 'not_recorded',
    }
    (REPAIR / 'repair.json').write_text(json.dumps(metadata, indent=2)+'\n')
    sys.argv = [__file__, '--index', '7', '--frames', *map(str, metadata['frames'])]
    scope = {'__name__':'__main__','__file__':__file__, '__package__':'explainer.projects.tesla-hw3'}
    exec(compile(text, __file__, 'exec'), scope)

if __name__ == '__main__':
    main()
