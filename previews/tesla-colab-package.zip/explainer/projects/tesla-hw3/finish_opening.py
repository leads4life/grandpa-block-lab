"""Finish the continuous-3D search opening; freeze narration and leave review pending.

Run only after opening_search.py has completed every native 30-fps frame.
Spatial denoising avoids temporal trails on moving geometry; no frame interpolation,
held images, narration captions, music or recorded-speech time stretching.
"""
from pathlib import Path
import hashlib
import subprocess
from PIL import Image, ImageDraw, ImageFont
from explainer.core import read, write
from explainer.media import check_video

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'build/opening-v2'
W, H, FPS = 960, 540, 30
FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')


def font(size, bold=False):
    return ImageFont.truetype(str(FONT_DIR / ('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')), size)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def overlay(im, pose, u):
    layer = Image.new('RGBA', (W, H))
    d = ImageDraw.Draw(layer)
    boxes = []
    shot = pose['shot']
    if shot != 'car_question':
        for key, title in [('early', 'TURN NOW'), ('creep', 'CREEP'), ('wait', 'WAIT'),
                           ('turn', 'NEXT CHOICES'), ('later_wait', 'NEXT CHOICES')]:
            x, y, scale = pose['labels'][key]
            threshold = .90 if key in ('turn', 'later_wait') else .85
            if scale <= threshold or not (.025 < x < .975 and .025 < y < .91):
                continue
            descriptor = ''
            color = '#d4e1e8'
            if shot == 'evaluate_and_prune' and u > .49 and key in ('early', 'creep', 'wait'):
                descriptor = {'early': 'CONFLICT AHEAD', 'creep': 'BLOCKS CROSSWALK', 'wait': 'EXPAND'}[key]
                color = '#5edbed' if key == 'wait' else '#f0b58d'
            elif key in ('turn', 'later_wait'):
                color = '#5edbed'
            f = font(18, True)
            sub = font(12, True)
            width = max(d.textlength(title, font=f), d.textlength(descriptor, font=sub)) + 20
            height = 46 if descriptor else 30
            cx, top = x*W, y*H+3
            box = (round(cx-width/2), round(top), round(cx+width/2), round(top+height))
            # Do not slide detached labels into the frame or let neighboring badges overlap.
            if box[0] < 14 or box[2] > W-14 or box[1] < 10 or box[3] > H-32:
                continue
            if any(box[0] < b[2]+5 and box[2] > b[0]-5 and box[1] < b[3]+3 and box[3] > b[1]-3 for b in boxes):
                continue
            alpha = round(235*min(1, max(0, (scale-threshold)/(1-threshold))))
            d.rounded_rectangle(box, radius=5, fill=(8, 23, 34, alpha), outline=(68, 100, 117, alpha), width=1)
            d.text((cx, top+5), title, font=f, fill=color, anchor='mt')
            if descriptor:
                d.text((cx, top+29), descriptor, font=sub, fill=color, anchor='mt')
            boxes.append(box)
    footer = 'Illustrative search · not Tesla software or measured performance'
    d.text((16, H-18), footer, font=font(11), fill='#d1dce5', stroke_width=2, stroke_fill=(8, 18, 27, 190))
    return Image.alpha_composite(im.convert('RGBA'), layer).convert('RGB'), boxes


def main():
    timing = read(OUT / 'timing.json')
    poses = read(OUT / 'poses.json')
    nf, seconds = timing['frames'], timing['seconds']
    if nf != 453 or abs(seconds*FPS-nf) > .001:
        raise ValueError(f'Unexpected opening version/timing: {nf} frames, {seconds} seconds')
    expected = {f'{i:06d}.png' for i in range(nf)}
    actual = {p.name for p in (OUT / 'raw').glob('*.png')}
    if actual != expected:
        raise ValueError(f'Incomplete render: {len(actual)}/{nf}; missing {sorted(expected-actual)[:5]}, extras {sorted(actual-expected)[:5]}')
    if set(poses) != {str(i) for i in range(nf)}:
        raise ValueError('Incomplete motion/label poses')
    audio = OUT / 'voice.wav'
    voice_hash = sha(audio)
    if voice_hash != read(OUT / 'voice.json')['sha256']:
        raise ValueError('Frozen voice bytes changed')
    filtered, frames = OUT / 'filtered', OUT / 'frames'
    filtered.mkdir(exist_ok=True)
    frames.mkdir(exist_ok=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-threads', '2', '-filter_threads', '2',
        '-framerate', str(FPS), '-start_number', '0', '-i', str(OUT / 'raw/%06d.png'),
        '-vf', 'nlmeans=s=5:p=7:r=9,scale=960:540:flags=lanczos', '-frames:v', str(nf),
        '-start_number', '0', str(filtered / '%06d.png')], check=True)
    label_boxes = {}
    selected = [0, round(nf*.20), round(nf*.37), round(nf*.51), round(nf*.58), round(nf*.68), round(nf*.86), nf-1]
    for i in range(nf):
        with Image.open(filtered / f'{i:06d}.png') as raw:
            im, boxes = overlay(raw, poses[str(i)], i/(nf-1))
        im.save(frames / f'{i:06d}.png')
        label_boxes[str(i)] = boxes
        if i in selected:
            im.save(OUT / f'check-{i:06d}.jpg', quality=95)
    output = OUT / 'tesla-opening-v2.mp4'
    gain, attempts = 0, []
    for _ in range(4):
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', str(FPS), '-start_number', '0',
            '-i', str(frames / '%06d.png'), '-i', str(audio),
            '-af', f'volume={gain:.3f}dB,alimiter=limit=0.65:attack=2:release=60:level=false:latency=1,apad',
            '-t', f'{seconds:.9f}', '-c:v', 'libx264', '-threads', '2', '-preset', 'medium', '-crf', '19',
            '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-ar', '48000', '-movflags', '+faststart', str(output)], check=True)
        qa = check_video(output, seconds, W, H, FPS)
        attempts.append(dict(qa, gain_db=gain))
        if qa['passed']:
            break
        if not all(value for key, value in qa['checks'].items() if key not in ('loudness', 'no_clipping')):
            raise ValueError(f'Non-audio encode failure: {qa}')
        gain += -14-qa['lufs']
    if not qa['passed']:
        raise ValueError(f'Bounded media checks failed: {qa}')
    if sha(audio) != voice_hash:
        raise ValueError('Narration changed during encoding')
    qa.update({'review': 'pending', 'attempts': attempts, 'scene_checks': read(OUT / 'scene-qa.json'),
        'voice': timing['voice'], 'speech_wpm': timing['speech_wpm'], 'voice_sha256': voice_hash,
        'script': timing['script'], 'seconds': seconds, 'position_in_film': 'opening from 00:00',
        'static_image_sections': False, 'recorded_speech_time_stretched': False, 'music': False,
        'camera_motion': 'Native continuous 3D frames, no held plates or frame interpolation',
        'denoise': 'Spatial nlmeans only; no temporal averaging of moving vehicles',
        'render_size': [timing['width'], timing['height']], 'output_size': [W, H],
        'scope': 'Short draft opening direction preview; full film is not rendered',
        'source_hashes': {p.name: sha(p) for p in [Path(__file__), ROOT/'opening_search.py', OUT/'poses.json']}})
    write(OUT / 'qa.json', qa)
    write(OUT / 'label-boxes.json', label_boxes)
    sheet = Image.new('RGB', (1920, 588), '#0c1a26')
    draw = ImageDraw.Draw(sheet)
    for j, i in enumerate(selected):
        x, y = (j % 4)*480, (j // 4)*294
        with Image.open(frames / f'{i:06d}.png') as im:
            sheet.paste(im.resize((480, 270)), (x, y))
        draw.text((x+8, y+275), f'{i/FPS:.2f}s · {poses[str(i)]["shot"]}', font=font(12), fill='#d2e0e9')
    sheet.save(OUT / 'review-sheet.jpg', quality=95)
    with Image.open(frames / f'{round(nf*.51):06d}.png') as im:
        im.save(OUT / 'poster.jpg', quality=95)
    print('OPENING ENCODED; ACTUAL REVIEW STILL PENDING:', output, flush=True)


if __name__ == '__main__':
    main()
