"""Revised visual rhythm: eight directed shots, actual 3D reveal, evolving explanation."""
from pathlib import Path
from functools import lru_cache
import math,subprocess
from PIL import Image,ImageDraw,ImageFont,ImageEnhance
from explainer.core import read,write
from explainer.media import check_video
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/motion-v2';OUT.mkdir(parents=True,exist_ok=True)
PRE=ROOT/'build/preview';AUD=ROOT/'build/voice-audition';W,H=960,540
CUTS=[0,.12,.23,.35,.49,.62,.76,.89,1]
WHITE='#eff6ff';CYAN='#65dcf6';GRAY='#9ebacc';DARK='#091726'
@lru_cache(None)
def font(n,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',n)
@lru_cache(130)
def image(path):
 with Image.open(path) as im:return im.convert('RGB').resize((W,H),Image.Resampling.LANCZOS)

def move(im,t,zoom=.05,pan=.025):
 # Small editorial moves over rendered 3D plates; real object motion is rendered separately.
 scale=1+zoom*t;w,h=round(W*scale),round(H*scale)
 im=im.resize((w,h),Image.Resampling.BICUBIC)
 x=max(0,min(w-W,round((w-W)*(.5+pan*(t-.5)))))
 y=max(0,min(h-H,round((h-H)*.45)))
 return im.crop((x,y,x+W,y+H))

@lru_cache(None)
def shade(amount):
 mask=Image.new('RGBA',(W,H));d=ImageDraw.Draw(mask)
 for x in range(W):d.line((x,0,x,H),fill=(4,12,23,int(amount*(1-x/W)**1.5+10)))
 return mask

def background(path,local,dim=220):return Image.alpha_composite(move(image(str(path)).copy(),local).convert('RGBA'),shade(dim)).convert('RGB')

def lines(d,text,x,y,size=38,width=460,color=WHITE):
 words=text.split();row='';rows=[]
 for word in words:
  test=(row+' '+word).strip()
  if d.textlength(test,font=font(size,True))>width and row:rows.append(row);row=word
  else:row=test
 if row:rows.append(row)
 for i,row in enumerate(rows):d.text((x,y+i*(size+8)),row,font=font(size,True),fill=color)

def progress_line(d,points,amount,color,width=3):
 amount=max(0,min(1,amount));lengths=[math.dist(a,b) for a,b in zip(points,points[1:])];remaining=sum(lengths)*amount
 for a,b,length in zip(points,points[1:],lengths):
  if remaining<=0:break
  portion=min(1,remaining/length);end=(a[0]+(b[0]-a[0])*portion,a[1]+(b[1]-a[1])*portion)
  d.line([a,end],fill=color,width=width);remaining-=length

def graph(d,local,mode):
 root=(552,279);candidates=[(782,145),(805,280),(782,416)];scores=[.82,.46,.13]
 for i,((x,y),score) in enumerate(zip(candidates,scores)):
  reveal=max(0,min(1,local*3.5-i*.18)) if mode=='organize' else 1
  if mode=='prune' and i>0:reveal=max(0,1-local*1.8)
  path=[root,(650,y),(x-69,y)]
  progress_line(d,path,reveal,CYAN if i==0 and mode!='organize' else '#5f8da6',3)
  if reveal>.85 or (mode=='prune' and i>0 and reveal>.03):
   color=CYAN if i==0 and mode!='organize' else '#678a9e'
   d.rounded_rectangle((x-67,y-29,x+67,y+29),radius=12,fill=DARK,outline=color,width=2)
   label=f'OPTION {i+1}' if mode=='organize' else f'{score*(min(1,local*2.5) if mode=="score" else 1):.2f}'
   d.text((x-43,y-10),label,font=font(16,True),fill=WHITE)
 d.ellipse((root[0]-29,root[1]-29,root[0]+29,root[1]+29),fill=DARK,outline=CYAN,width=3)
 d.text((root[0]-20,root[1]-7),'GOAL',font=font(11,True),fill=WHITE)
 if mode=='score':d.text((551,466),'Illustrative scores · not Tesla measurements',font=font(11),fill=GRAY)
 if mode=='prune':d.text((550,466),'Example threshold: 0.50',font=font(12),fill=GRAY)
 # A traveling signal gives the viewer an action to follow on the relevant branch.
 u=(local*.5)%1;path=[root,(650,145),(713,145)];lengths=[math.dist(a,b) for a,b in zip(path,path[1:])];distance=u*sum(lengths)
 for a,b,length in zip(path,path[1:],lengths):
  if distance<=length:
   x=a[0]+(b[0]-a[0])*distance/length;y=a[1]+(b[1]-a[1])*distance/length;d.ellipse((x-4,y-4,x+4,y+4),fill=CYAN);break
  distance-=length

def render_frame(t,total):
 normalized=min(.999999,t/total);stage=max(i for i in range(8) if normalized>=CUTS[i]);start=CUTS[stage]*total;duration=(CUTS[stage+1]-CUTS[stage])*total;local=(t-start)/duration
 if stage==0:
  idx=min(89,round(local*100));im=background(PRE/'car'/f'{idx:06d}.png',local)
 elif stage==3:
  idx=min(17,round(local*48));im=background(OUT/'chip'/f'{idx:06d}.png',local,150)
 elif stage in (4,5):im=background(OUT/'chip/000017.png',local,170)
 else:im=background(PRE/'compute.png',local)
 d=ImageDraw.Draw(im)
 d.text((47,31),'INSIDE TESLA’S PLANNING PATENT',font=font(12,True),fill=CYAN)
 if stage==0:
  lines(d,'Can software help older hardware do more?',48,114,38,465)
 elif stage==1:
  lines(d,'Make the planning more selective.',48,112,39,440)
  d.text((50,282),'Smarter search starts with the choices.',font=font(15),fill=GRAY)
 elif stage==2:
  # An original stylized document card, not an unlicensed screenshot of patent drawings.
  y=110+round((1-local)*24)
  d.rounded_rectangle((480,y,890,y+330),radius=10,fill='#e4edf3')
  d.text((508,y+24),'TESLA',font=font(24,True),fill='#10263a')
  d.text((509,y+69),'PATENT APPLICATION',font=font(12,True),fill='#436077')
  d.text((508,y+111),'US20260105614A1',font=font(20,True),fill='#10263a')
  d.text((509,y+160),'Published 16 April 2026',font=font(14),fill='#436077')
  d.line((509,y+197,858,y+197),fill='#a6b9c6',width=2)
  d.text((509,y+225),'Goals → interactions → trajectories',font=font(13),fill='#264d67')
  lines(d,'A real Tesla disclosure.',48,139,39,395)
 elif stage in (3,4,5):
  titles={3:'Organize the choices.',4:'Score the alternatives.',5:'Stop exploring poor branches.'}
  lines(d,titles[stage],48,116,38,410)
  captions={3:'Reveal the planning problem.',4:'Compare coherent candidate paths.',5:'Keep developing useful candidates.'}
  d.text((50,280),captions[stage],font=font(14),fill=GRAY)
  graph(d,local,{3:'organize',4:'score',5:'prune'}[stage])
  if stage==3:d.text((50,317),'Illustrative exploded compute module',font=font(11),fill=GRAY)
 elif stage==6:
  lines(d,'Keep the evidence clear.',48,112,38,430)
  for index,(title,sub,color) in enumerate([('Planning method','Disclosed in the patent',CYAN),('HW3 feature parity','Not established by this document','#e8be73')]):
   reveal=max(0,min(1,local*3-index*.45));y=255+index*104+round((1-reveal)*15)
   if reveal<=0:continue
   d.rounded_rectangle((48,y,521,y+80),radius=10,fill=DARK,outline='#2c4c63')
   d.rectangle((48,y+12,52,y+68),fill=color)
   d.text((68,y+14),title,font=font(18,True),fill=WHITE)
   d.text((68,y+46),sub,font=font(13),fill=color)
 else:
  lines(d,'Let’s look at how it works.',48,116,40,440)
  d.text((50,285),'A source-backed engineering explanation.',font=font(15),fill=GRAY)
 d.text((48,503),'US20260105614A1 · Original illustrative 3D models',font=font(11),fill='#92adbf')
 return im

def main():
 comparison=read(AUD/'comparison.json')
 assert len(list((OUT/'chip').glob('*.png')))==18
 for key,metadata in comparison['auditions'].items():
  total=metadata['seconds'];nf=round(total*30);silent=OUT/f'silent-{key}.mp4';logfile=OUT/f'encode-{key}.log'
  with logfile.open('w') as log:
   process=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-r','30','-i','-',
    '-c:v','libx264','-threads','2','-preset','medium','-crf','19','-pix_fmt','yuv420p',str(silent)],stdin=subprocess.PIPE,stderr=log)
   try:
    for frame in range(nf):process.stdin.write(render_frame(frame/30,total).tobytes())
   finally:process.stdin.close();code=process.wait()
   assert code==0
  output=OUT/f'tesla-preview-v2-{key}.mp4'
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(silent),'-i',str(AUD/f'narration-{key}.mp4'),'-map','0:v','-map','1:a','-c','copy','-t',str(total),'-movflags','+faststart',str(output)],check=True)
  qa=check_video(output,total,W,H);assert qa['passed'],qa
  qa.update({'review':'pending','voice_option':metadata['voice'],'script':comparison['script'],'shot_count':8,'production_voice_changed':False})
  write(OUT/f'qa-{key}.json',qa)
  render_frame(total*.14,total).save(OUT/f'poster-{key}.jpg',quality=94)
  sheet=Image.new('RGB',(960,720),'#091726')
  for i,u in enumerate([.03,.16,.27,.39,.53,.66,.80,.95]):
   sheet.paste(render_frame(total*u,total).resize((320,180)),((i%3)*320,(i//3)*240))
  sheet.save(OUT/f'review-{key}.jpg',quality=95)
  print('MOTION PREVIEW',key,'READY',round(total,2),'seconds',flush=True)
if __name__=='__main__':main()
