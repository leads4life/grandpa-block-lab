"""Blender geometry utilities for physical sections, flow indicators and callout leaders."""
import math
import bpy
import bmesh
from mathutils import Vector


def material(name, rgba, luminous=False):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = rgba
    shader.inputs['Metallic'].default_value = 0 if luminous else .45
    shader.inputs['Roughness'].default_value = .4
    if luminous:
        # Technical ink must not pick up bright studio reflections and lose contrast.
        nodes = mat.node_tree.nodes
        emission = nodes.new('ShaderNodeEmission')
        emission.inputs['Color'].default_value = rgba
        emission.inputs['Strength'].default_value = 1
        mat.node_tree.links.new(emission.outputs[0], nodes.get('Material Output').inputs['Surface'])
    return mat


def tube(wall=.12, segments=48):
    """Closed hollow unit cylinder, axis Z. Wall is a fraction of outer diameter."""
    vertices, faces = [], []
    for z, radius in [(-.5, .5), (.5, .5), (-.5, .5-wall), (.5, .5-wall)]:
        vertices.extend((radius*math.cos(i*2*math.pi/segments), radius*math.sin(i*2*math.pi/segments), z)
                        for i in range(segments))
    for i in range(segments):
        j = (i+1) % segments
        faces.extend([(i, j, segments+j, segments+i),
                      (2*segments+j, 2*segments+i, 3*segments+i, 3*segments+j),
                      (j, i, 2*segments+i, 2*segments+j),
                      (segments+i, segments+j, 3*segments+j, 3*segments+i)])
    mesh = bpy.data.meshes.new('Hollow housing')
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new('Housing', mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def section(obj, spec, cap_material):
    """Cut in normalized LOCAL coordinates before sizing; preserve watertight physical walls."""
    axis = 'xyz'.index(spec['axis'])
    normal = Vector((int(axis == 0), int(axis == 1), int(axis == 2)))
    point = normal * spec.get('offset', 0)
    mesh = bmesh.new()
    try:
        mesh.from_mesh(obj.data)
        bmesh.ops.bisect_plane(mesh, geom=list(mesh.verts)+list(mesh.edges)+list(mesh.faces),
                              dist=1e-6, plane_co=point, plane_no=normal,
                              clear_inner=spec['keep'] == 'positive', clear_outer=spec['keep'] == 'negative')
        boundary = [edge for edge in mesh.edges if edge.is_boundary]
        if boundary:
            caps = bmesh.ops.holes_fill(mesh, edges=boundary, sides=0)['faces']
            obj.data.materials.append(cap_material)
            for face in caps:
                face.material_index = len(obj.data.materials)-1
        bmesh.ops.recalc_face_normals(mesh, faces=list(mesh.faces))
        if not mesh.faces or any(not edge.is_manifold for edge in mesh.edges):
            raise ValueError(f'Section of {obj.name} is empty or not watertight')
        mesh.to_mesh(obj.data)
        obj.data.update()
    finally:
        mesh.free()


def line(name, points, radius, mat):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.bevel_depth, curve.bevel_resolution = radius, 2
    spline = curve.splines.new('POLY')
    spline.points.add(len(points)-1)
    for dest, point in zip(spline.points, points):
        dest.co = (*point, 1)
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    return obj


def flow(cue, mat, frames):
    points = [Vector(p) for p in cue['path']]
    radius = cue.get('radius', .025)
    direction = (points[-1]-points[-2]).normalized()
    head_length = min(radius*6, (points[-1]-points[-2]).length*.4)
    end = points[-1] - direction*head_length
    shaft = line(cue['id']+'_path', [*points[:-1], end], radius, mat)
    bpy.ops.mesh.primitive_cone_add(vertices=24, radius1=radius*2.8, radius2=0, depth=head_length,
                                    location=(end+points[-1])*.5)
    head = bpy.context.object
    head.name = cue['id']+'_arrow'
    head.rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
    head.data.materials.append(mat)
    objects = [shaft, head]
    if cue.get('animate', False):
        bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=radius*1.8)
        packet = bpy.context.object
        packet.name = cue['id']+'_packet'
        packet.data.materials.append(mat)
        lengths = [(b-a).length for a, b in zip(points, points[1:])]
        total, distance = sum(lengths), 0
        for i, point in enumerate(points):
            if i:
                distance += lengths[i-1]
            frame = distance/total*(frames-1)
            packet.location = point
            packet.keyframe_insert(data_path='location', frame=frame)
        # Uniform frame/length spacing; the path remains piecewise linear, not a drifting spline.
        action = packet.animation_data.action
        for slot in action.slots:
            for layer in action.layers:
                for strip in layer.strips:
                    bag = strip.channelbag(slot)
                    if bag:
                        for channel in bag.fcurves:
                            for key in channel.keyframe_points:
                                key.interpolation = 'LINEAR'
        objects.append(packet)
    return objects


def leader(label, target, scene, frames, mat):
    obj = line('Leader_'+label['text'], [label['position'], tuple(target.location)], .008, mat)
    point = obj.data.splines[0].points[1]
    for frame in [0, frames-1]:
        scene.frame_set(frame)
        point.co = (*target.matrix_world.translation, 1)
        point.keyframe_insert(data_path='co', frame=frame)
    return obj
