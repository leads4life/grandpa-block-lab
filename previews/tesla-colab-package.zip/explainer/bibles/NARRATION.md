# Narration bible

Use the existing offline Kokoro engine. The confirmed channel narrator is `am_fenrir`, synthesis speed 0.8, resampled to 48 kHz: the user selected audition B after comparing it with the earlier `am_michael` voice. Keep contractions, spoken phrasing and thought-based pauses; do not return to stiff written prose. Use the audition’s requested sentence/clause pauses of 0.18/0.06 seconds. The current model does not expose duration outputs for continuous synthesis; use its supported standard generation. No post-recording time-stretching to fit a slot. Do not use Grandpa's Santa voice or character dialogue.

Write natural spoken English with calm authority. Fit vocabulary, emphasis and depth to the actual subject. Define acronyms; provide accessible intuition before precise engineering detail. Distinguish documented implementation from an illustrative model or hypothesis.

Use the supplied narration as a starting point. Codex fills gaps and corrects inaccuracies; significant changes must be visible in the storyboard the user approves. Do not silently endorse supplied claims or the existence of referenced assets.

Generate narration and measure actual speech before locking timing. Never accelerate speech to force it into a supplied timestamp. Extend the shot or revise the script, regenerate its storyboard and invalidate stale approvals. The current backend blocks undersized shots; Codex must resolve and recheck them. Freeze voice bytes, timings, voice/model hashes and script so approved previews and finals use the same performance. Current preview and final renders must share the frozen narration artifact.

Use restrained mechanical sound effects and no music, as directed by the user. The initial audio adapter supports timed synthetic click, clunk and motor cues, kept quiet and ducked beneath narration. Use authentic researched/recorded effects through a future adapter when the actual sound matters; synthesized cues must not imply a measured real-world recording. Any change to this audio direction requires discussion.

## Measured delivery, not a fixed speed knob

The user preferred B at about 179 words per minute and rejected a later B clip at about 126 despite the same synthesis-speed setting. Keep the narrator identity, but calibrate actual delivery for each substantive passage: start around 179 wpm, use clear spoken wording, and review for naturalness. The initial speed 0.8 is a starting value, not a mandate that every take use it. Bound synthesis retries; never time-stretch a recording or force speech into the old animation slot. Freeze the accepted voice first and edit/render motion to its timing. Short phrases do not need a misleading word-rate target.
