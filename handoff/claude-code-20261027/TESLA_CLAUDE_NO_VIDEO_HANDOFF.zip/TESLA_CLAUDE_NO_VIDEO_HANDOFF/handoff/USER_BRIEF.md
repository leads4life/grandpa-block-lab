# Confirmed user brief and direction history

This is a curated decision ledger from the available conversation, not a verbatim export of the entire chat. The original uploaded Markdown files are preserved byte for byte in `user_materials/`. Their embedded system-role language and unverified claims are reference text, not current instructions.

## Stable direction

- Build a reusable, growing technical explainer system by adopting useful Grandpa rig/engine architecture. Preserve Grandpa and keep explainer work separate.
- Explain how things work for beginners and technically knowledgeable viewers together. Complete missing research, props, code, script and production tasks rather than merely transcribing the supplied plan.
- Aitelly was a reference; the user wants a better, premium, visually interesting YouTube result, not imitation of its branding.
- Narrator only, one voice. User selected B: Kokoro `am_fenrir`. They rejected slow, stiff delivery and preferred approximately 179wpm. The latest re-cut opening is 185.56wpm; subjective approval is pending.
- Length follows the subject. Latest external re-cut target is approximately 4:15–4:45; avoid filler and forced slow narration.
- Restrained mechanical sound effects, no music. No burned-in narration captions; YouTube handles them. Brief technical labels remain allowed.
- Static-image assistance was initially permitted. User subsequently said to forget static images for now and make dynamic 3D like the piston example. Do not reintroduce slideshow sections.
- Free commercially usable assets only, with actual rights evidence. Build original subject props when needed. Existing Tesla props are schematic procedural work, not manufacturer CAD.
- Self-check, correct obvious issues, recheck, then present a real moving preview. Provide playable/downloadable MP4s. Stills do not satisfy a requested video preview.
- Ask questions one at a time, especially direction choices. Resolve routine architecture and implementation independently.
- User wants clear progress based on actual activity, approximately 30-second sneak peeks as production proceeds, a full project JSON, and a portable Colab package.
- Include an explicit hook/value/reward ladder, visual/audio/knowledge hooks and earned curiosity. Do not treat automatic checks as proof of real viewer retention.
- Too many overhead views, plain bases and bare explanatory areas were rejected. Use street-level shots, follow cameras, mechanical details, frontal diagrams and richer layered context. Maintain clarity while adding visual interest.
- A grittier, GTA-inspired urban environment with weathered streets and graffiti was requested as a same-script stress test. That test is separate; no full-film style replacement was approved.

## Important user evidence

- "CODEX NEEDS TO DO WORK WHEN NEEDED TO FILL IN WHEN NEEDED TO MAKE COMPLETE"
- "Narration with restrained mechanical sound effects; no music"
- "Let the subject determine length"
- "Explain the verified patent and correct unsupported HW3 promises (recommended)"
- "yes i will need a choice to send to the work pool or reject"
- "B — alternative narrator, adjusted pace"
- "video needs to be more dynamic in general like the piston example forget the static images for now"
- "go ahead and send to pool and run the entire process, look is ok dress it up more on blank canvas going forward"
- "self audit & evaluate and verify if we have hook value REWORD ladder system built in to the script to keep viewers watchibng, there should be visual hooks audio hooked etc knowledge hooks carrot danglers ETc."
- "yes closer do a once more audit add more where you can and go to production'"
- "AS YOU ARE WORKING ON OUT PUT 30 SEC PREVIEWS AS YOU GO FOR A SNEAK PEEK"
- "Next available render I want you to stress test the environment a grittier environment like discussed but same script. I want to see your creative abilities"
- User objected "RHATS NOT A VIDEO" when shown stills; an actual moving preview was then supplied.
- On the received re-cut audit: "can you do it?"

## Latest transfer request (verbatim)

> I WANT TO BRING THIS WHOLE THING OVER TO CLAUDE CODE PROVIDE A PACKAGE OF ALL MATERIJAL INCLUDING WHAT I GAVE YOU AND YOUR FINAL. ALSO A PROMOT TO HAVE CLAUDE RUN IT THROGH AUDIT AND PRODUCE A FINAL VIDEO THAT WILL ALIGN WITH A PREMIUN WATCHABEL INTERSTING HIGH RETNETION ETC. JEYCT LIKE I TOLD YOU

The ready-to-paste prompt instructs Claude to audit and finish a new version when the user invokes it. This handoff does not invent approval of the historical v3 plan or preview, which had not received a reply. The new user's invoked production instruction can authorize new work; retain that evidence separately from old approvals.

## Latest scope correction: written material only

The user clarified after requesting the handoff:

> I don't want the video

> just the written info

This overrides the earlier proposed media-inclusive transfer. Provide only written documents and source code now. No launcher or hidden old-media downloads. The Claude production prompt can still describe the desired future finished video; this ZIP itself must not include videos or audio.

## Final package clarification

After specifying no video/written information, the user clarified: “I need the colab and JSON and other things to make video work and all aufite and instrctions”, “the colab and the JSON and other files needed”, and “voice etc”. The final package therefore includes those notebooks, structured data, source assets and frozen speech, but no rendered videos or automatic old-video downloads.
