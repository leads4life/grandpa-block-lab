"""Finish a direction sample; technical count badges are not narration captions."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess
from explainer.core import read,write
from explainer.media import check_video,mix_mechanical

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'retention-v2/build/showcase'
def main():
 t=read(OUT/'timing.json');nf=t['frames'];poses=read(OUT/'poses.json')
 assert {p.name for p in (OUT/'raw').glob('*.png')}=={f'{f:06d}.png' for f in range(nf)},'Incomplete sample'
 filtered=OUT/'filtered';filtered.mkdir(exist_ok=True)
 subprocess.run(['ffmpeg','-v','error','-y','-threads','2','-filter_threads','2','-framerate','30','-i',str(OUT/'raw/%06d.png'),'-vf','nlmeans=s=6:p=7:r=9,scale=960:540:flags=lanczos','-start_number','0',str(filtered/'%06d.png')],check=True)
 frames=OUT/'frames';frames.mkdir(exist_ok=True)
 bold=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',24);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
 selected=[0,nf//5,nf*2//5,nf*3//5,nf*4//5,nf-1];sheet=Image.new('RGB',(1440,580),'#071320');sd=ImageDraw.Draw(sheet)
 for f in range(nf):
  with Image.open(filtered/f'{f:06d}.png') as src:im=src.convert('RGB')
  d=ImageDraw.Draw(im);count=poses[str(f)]['count']
  if count:
   text=f'{count} '+('choices' if count==3 else 'sequences');w=d.textlength(text,font=bold)+32
   d.rounded_rectangle((960-w-24,20,936,66),radius=9,fill='#0a2432',outline='#48ceef',width=1)
   d.text((936-w/2,43),text,font=bold,fill='#e1faff',anchor='mm')
  d.text((18,518),'Illustrative branching · original 3D models · not Tesla measurements',font=small,fill='#bfd2e0')
  im.save(frames/f'{f:06d}.png')
  if f in selected:
   j=selected.index(f);x=j%3*480;y=j//3*290;sheet.paste(im.resize((480,270)),(x,y));sd.text((x+8,y+274),f'{f/30:.2f}s',font=small,fill='white')
 sheet.save(OUT/'review-sheet.jpg',quality=95)
 audio=mix_mechanical({'id':'retention_showcase','sfx':[{'kind':'motor','at':.1,'duration':1.7,'purpose':'Quiet illustrative rolling cue tied to hero movement.'}]},OUT/'voice.wav',OUT/'mix.wav',t['seconds'])
 video=OUT/'richer-3d-retention-sample.mp4';gain=0
 for _ in range(4):
  subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-i',str(frames/'%06d.png'),'-i',str(audio),'-af',f'volume={gain:.3f}dB,alimiter=limit=0.65:level=false:latency=1,apad','-t',str(t['seconds']),'-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-movflags','+faststart',str(video)],check=True)
  qa=check_video(video,t['seconds'],960,540)
  if qa['passed']:break
  gain+=-14-qa['lufs']
 assert qa['passed'],qa
 qa.update(review='pending',purpose='One richer visual-direction and micro hook/reward test; not a new full episode',audio_timing='Measured thought groups drive count reveals; narration is not time-stretched',voice=read(OUT/'voice.json'),scene=read(OUT/'scene-qa.json'))
 write(OUT/'qa.json',qa)
 with Image.open(frames/f'{nf*4//5:06d}.png') as im:im.save(OUT/'poster.jpg',quality=95)
 print('RICHER SAMPLE ENCODED; VISUAL REVIEW STILL PENDING',video,flush=True)

if __name__=='__main__':main()
