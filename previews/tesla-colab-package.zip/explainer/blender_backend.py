"""Declarative assembly renderer. Run through the explainer CLI, never execute plan code."""
from __future__ import annotations
import json
import math
from pathlib import Path
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

from .presentation import resolve_theme
from .visual_tools import flow, leader, material, section, tube


def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def build(shot, width, height, fps, frames, assets=None, project_root=None):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    theme_name, palette = resolve_theme(shot)
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 8
    scene.cycles.use_denoising = True
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = 2
    scene.render.resolution_x, scene.render.resolution_y = width, height
    scene.render.resolution_percentage = 100
    scene.render.fps = fps
    scene.frame_start, scene.frame_end = 0, frames - 1
    scene.render.image_settings.file_format = 'PNG'
    scene.world = bpy.data.worlds.new('Explainer studio')
    scene.world.use_nodes = True
    background = scene.world.node_tree.nodes.get('Background')
    background.inputs['Color'].default_value = palette['background']
    background.inputs['Strength'].default_value = 1 if theme_name == 'light' else .5
    for name, pos, energy, color, size in [
        ('Key', (4, -5, 7), 1300, (1, .93, .84), 5),
        ('Fill', (-4, -2, 3), 700, (.7, .84, 1), 4),
        ('Rim', (2, 5, 5), 1800, (.6, .8, 1), 3)]:
        data = bpy.data.lights.new(name, 'AREA')
        data.energy, data.color, data.shape, data.size = energy, color, 'DISK', size
        obj = bpy.data.objects.new(name, data)
        scene.collection.objects.link(obj)
        obj.location = pos
        aim(obj, (0, 0, 0))
    camera_spec = shot['camera']
    bpy.ops.object.camera_add(location=camera_spec['position'])
    camera = bpy.context.object
    scene.camera = camera
    camera.data.lens = camera_spec.get('lens', 50)
    camera.data.clip_end = 1000
    # No shallow-focus default: the explanatory geometry must remain readable.
    camera.data.dof.use_dof = False
    aim(camera, camera_spec['target'])
    camera.keyframe_insert(data_path='location', frame=0)
    camera.keyframe_insert(data_path='rotation_euler', frame=0)
    camera.location = camera_spec.get('end_position', camera_spec['position'])
    aim(camera, camera_spec['target'])
    camera.keyframe_insert(data_path='location', frame=frames - 1)
    camera.keyframe_insert(data_path='rotation_euler', frame=frames - 1)
    objects = []
    components = {}
    cap_material = material('Physical cut faces', palette['section'])
    ink = material('Technical callout ink', palette['ink'], luminous=True)
    for component in shot.get('components', []):
        shape = component['shape']
        imported_meshes = None
        if shape == 'model':
            if project_root is None or assets is None:
                raise ValueError('Model rendering requires a project root and asset registry')
            from .model_import import import_component
            obj, imported_meshes = import_component(component, assets[component['asset_id']], project_root)
        elif shape == 'box':
            bpy.ops.mesh.primitive_cube_add(size=1)
        elif shape == 'cylinder':
            bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=.5, depth=1)
        elif shape == 'tube':
            obj = tube(component.get('wall', .12))
            bpy.context.view_layer.objects.active = obj
        else:
            bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, radius=.5)
        if imported_meshes is None:
            obj = bpy.context.view_layer.objects.active
            obj.name = component['id']
            obj.data.materials.append(material(component['role'], palette[component['role']]))
            # Preserve the full uncut envelope when sectioning primitives.
            obj.scale = component['size']
            if 'section' in component:
                section(obj, component['section'], cap_material)
        obj.location = component['position']
        obj.rotation_euler = [math.radians(x) for x in component.get('rotation', [0, 0, 0])]
        components[component['id']] = obj
        for f, pos, rot in [(0, component['position'], component.get('rotation', [0, 0, 0])),
                            (frames - 1, component.get('move_to', component['position']),
                             component.get('rotate_to', component.get('rotation', [0, 0, 0])))]:
            obj.location = pos
            obj.rotation_euler = [math.radians(x) for x in rot]
            obj.keyframe_insert(data_path='location', frame=f)
            obj.keyframe_insert(data_path='rotation_euler', frame=f)
        objects.extend(imported_meshes if imported_meshes is not None else [obj])
    for cue in shot.get('flows', []):
        objects.extend(flow(cue, material(cue['id'], palette[cue.get('role', 'flow')], luminous=True), frames))
    for label in shot.get('labels', []):
        bpy.ops.object.text_add(location=label['position'])
        obj = bpy.context.object
        obj.data.body = label['text']
        obj.data.size = label.get('size', .18)
        obj.data.align_x = 'CENTER'
        obj.rotation_euler = camera.rotation_euler.copy()
        obj.data.materials.append(ink)
        tracking = obj.constraints.new('TRACK_TO')
        tracking.target, tracking.track_axis, tracking.up_axis = camera, 'TRACK_Z', 'UP_Y'
        if label.get('target'):
            objects.append(leader(label, components[label['target']], scene, frames, ink))
        objects.append(obj)
    return scene, objects


def framing(scene, objects, frames):
    failures = []
    for frame in range(frames):
        scene.frame_set(frame)
        for obj in objects:
            for corner in obj.bound_box:
                point = obj.matrix_world @ Vector(corner)
                projected = world_to_camera_view(scene, scene.camera, point)
                if projected.z <= scene.camera.data.clip_start or not (.04 <= projected.x <= .96 and .04 <= projected.y <= .96):
                    failures.append({'frame': frame, 'object': obj.name})
                    break
    return failures


def render(shot, out, width, height, fps, frames, samples=8, assets=None, project_root=None):
    """Bounded automatic repair of framing; never repairs factual geometry by guessing."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    scene, objects = build(shot, width, height, fps, frames, assets=assets, project_root=project_root)
    repairs = []
    for attempt in range(4):
        failures = framing(scene, objects, frames)
        if not failures:
            break
        if attempt == 3:
            raise ValueError(f'Framing failed after 3 repairs: {failures[:5]}')
        # Lens widening keeps subject motion intact and covers both animated camera endpoints.
        scene.camera.data.lens /= 1.25
        repairs.append({'attempt': attempt + 1, 'action': 'widen_camera_lens', 'lens': scene.camera.data.lens,
                        'failures_before': len(failures)})
    scene.cycles.samples = samples
    scene.cycles.use_denoising = samples >= 16
    bpy.ops.wm.save_as_mainfile(filepath=str(out / 'scene.blend'))
    frame_dir = out / 'frames'
    frame_dir.mkdir(exist_ok=True)
    for f in range(frames):
        path = frame_dir / f'{f:06d}.png'
        if path.exists():
            continue
        scene.frame_set(f)
        scene.render.filepath = str(path)
        bpy.ops.render.render(write_still=True)
    (out / 'geometry-qa.json').write_text(json.dumps({'framing': 'passed', 'repairs': repairs, 'background': resolve_theme(shot)[0]}, indent=2))
