"""Portable, source-inclusive project record; media binaries remain separate files."""
from pathlib import Path
import argparse,hashlib,json,time
from datetime import datetime,timezone

PROJECT=Path(__file__).resolve().parent
ENGINE=PROJECT.parents[1]
REPO=ENGINE.parent
OUT=PROJECT/'build/full-v1'

def read(path):
    path=Path(path)
    return json.loads(path.read_text()) if path.exists() else None

def relative(path):
    path=Path(path).resolve()
    return str(path.relative_to(REPO)) if path.is_relative_to(REPO) else str(path)

def checksum(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk:=stream.read(1024*1024):h.update(chunk)
    return h.hexdigest()

def file_ref(path):
    path=Path(path)
    if not path.is_file():return {'path':relative(path),'available':False}
    return {'path':relative(path),'available':True,'bytes':path.stat().st_size,'sha256':checksum(path)}

def portable(value):
    if isinstance(value,dict):return {portable(k):portable(v) for k,v in value.items()}
    if isinstance(value,list):return [portable(x) for x in value]
    if isinstance(value,str) and value.startswith(str(REPO)+'/'):return value[len(str(REPO))+1:]
    return value

def export():
    manifest=read(OUT/'manifest.json');plan=read(PROJECT/'plan.json')
    assert manifest and plan,'Production plan is missing'
    chapters=[];start_frame=0
    for shot in manifest['shots']:
        folder=OUT/shot['id']
        if shot['index']==0:
            folder=PROJECT/'build/opening-v2';video=folder/'tesla-opening-v2.mp4'
        else:video=folder/'chapter.mp4'
        qa=read(folder/'qa.json')
        chapter=dict(shot)
        chapter.update(start_frame=start_frame,end_frame_exclusive=start_frame+shot['frames'],
                       start_seconds=start_frame/manifest['fps'],end_seconds=(start_frame+shot['frames'])/manifest['fps'],
                       voice_record=read(folder/'voice.json'),scene_checks=read(folder/'scene-qa.json'),
                       per_frame_metadata=read(folder/'poses.json'),render_provenance=read(folder/'render-source.json'),
                       qa=qa,surface_repair=read(folder/'surface-repair.json'),voice_file=file_ref(folder/'voice.wav'),
                       native_frames={'directory':relative(folder/'raw'),'pattern':'%06d.png','expected_count':shot['frames'],'available_count':len(list((folder/'raw').glob('*.png')))},
                       video_file=file_ref(video) if qa and qa.get('passed') else {'path':relative(video),'available':False,'status':'not_yet_media_checked'})
        chapters.append(chapter);start_frame+=shot['frames']
    sources=[*ENGINE.glob('*.py'),*ENGINE.glob('bibles/*.md'),ENGINE/'README.md',ENGINE/'requirements.txt']
    sources.extend(p for p in (ENGINE/'colab').rglob('*') if p.is_file() and p.suffix in ['.py','.md','.txt'])
    for name in ['produce_film.py','render_film_chapter.py','film_labels.py','final_review_packet.py','export_project_json.py','opening_search.py','finish_opening.py','repair_surface.py','rebuild_after_repair.py']:
        sources.append(PROJECT/name)
    sources.extend((PROJECT/'build/visual-revision-archive-v1').glob('*.py'))
    sources.extend((PROJECT/'build/renderer-source-history').glob('*.py'))
    source_bundle={relative(p):dict(file_ref(p),text=p.read_text()) for p in sources if p.is_file()}
    final_qa=read(OUT/'final-qa.json')
    final=OUT/'tesla-planning-complete.mp4'
    record={
        'schema_name':'technical_explainer_project','schema_version':'1.0',
        'exported_at_utc':datetime.now(timezone.utc).isoformat(),
        'path_base':'repository root; extract referenced files preserving these relative paths',
        'project':{'id':'tesla-hw3','title':manifest['title'],'runtime_seconds':manifest['seconds'],'total_frames':start_frame},
        'production_manifest':manifest,'project_plan':plan,
        'claims':plan.get('claims',{}),'sources':plan.get('sources',{}),'subject_bible':plan.get('subject_bible',{}),
        'chapters':chapters,
        'procedural_scene_definitions':{'kind':'Blender Python source, included below','current_renderer':relative(PROJECT/'render_film_chapter.py'),
            'completed_chapters_2_and_3_renderer':relative(PROJECT/'build/visual-revision-archive-v1/render_film_chapter.py'),
            'approved_opening_renderer':relative(PROJECT/'opening_search.py'),
            'model_factories':[relative(ENGINE/'vehicle_prop.py'),relative(ENGINE/'traffic_scene.py'),relative(ENGINE/'compute_scene.py')],
            'details':'Camera and light definitions, material settings, procedural geometry, actor motion and scene dressing are authoritative in the included source. Mesh binaries are not embedded in this JSON.'},
        'rights_and_accuracy':{'geometry_origin':'Original procedural models; no external model library used in this film','model_accuracy':'Generic schematic props, not engineering CAD or manufacturer-accurate Tesla geometry','source_credits':(OUT/'CREDITS.md').read_text() if (OUT/'CREDITS.md').exists() else None},
        'workflow':{'state':read(PROJECT/'production-state.json'),'live_pipeline_state':read(OUT/'pipeline-state.json'),
            'pipeline_error':read(OUT/'pipeline-error.json'),'preview_user_decision':read(PROJECT/'review/decision.json'),
            'decision_history':[read(p) for p in sorted((PROJECT/'review/history').glob('*.json'))],
            'production_preflight':read(OUT/'preflight-review.json'),
            'full_film_media_qa':final_qa,'full_film_inspection_packet':read(OUT/'final-inspection/packet.json'),
            'final_visual_review_status':final_qa.get('review','pending') if final_qa else 'pending_not_assembled'},
        'outputs':{'full_video':file_ref(final) if final_qa and final_qa.get('passed') else {'path':relative(final),'available':False,'status':'not_yet_media_checked'},
            'description':file_ref(OUT/'video-description.md'),'storyboard':file_ref(PROJECT/'full-production-storyboard.md')},
        'source_bundle':source_bundle,
        'colab_package':{'zip_filename':'tesla-colab-package.zip','notebook_filename':'Tesla_Explainer_Colab.ipynb','kind':'Separate portable source/media snapshot with its own checksum manifest'},
        'not_embedded':['audio and video bytes','native rendered images','Blender scene binaries','Kokoro model and voice weight binaries'],
        'reconstruction_notes':['Use the source bundle and referenced media together; JSON alone does not contain rendered media.','Install the pinned runtime and obtain the voice weights identified by the recorded hashes.','Snapshot status is truthful at export time; pending rendering or review is not marked complete.']}
    destination=OUT/'tesla-project.json';temporary=destination.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(portable(record),indent=2,ensure_ascii=False)+'\n');temporary.replace(destination)
    loaded=read(destination)
    assert len(loaded['chapters'])==13 and sum(c['frames'] for c in loaded['chapters'])==start_frame
    assert loaded['chapters'][-1]['end_frame_exclusive']==start_frame
    print('PROJECT JSON:',destination,'bytes:',destination.stat().st_size,'status:',loaded['workflow']['final_visual_review_status'],flush=True)
    return destination

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--watch',action='store_true');args=parser.parse_args()
    if args.watch:
        deadline=time.monotonic()+12*60*60
        while not (OUT/'final-inspection/packet.json').exists() and not (OUT/'pipeline-error.json').exists():
            if time.monotonic()>deadline:break
            time.sleep(30)
    export()
