# Tesla explainer v2

Use the matching v2 notebook. Sources, frozen narration and any completed clips are included. Native frames and voice weights are excluded. This is a separate version, not an overlay for v1. No YouTube upload or final user approval is implied. Read explainer/AGENTS.md and the production storyboard/audit.
