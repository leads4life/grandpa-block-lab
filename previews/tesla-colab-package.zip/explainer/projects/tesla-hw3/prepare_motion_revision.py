"""Actual 3D exploded-compute reveal; same authored generic electronics, not Tesla CAD."""
from pathlib import Path
import math
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/motion-v2/chip';OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'build/preview/compute.blend'))
s=bpy.context.scene;s.render.threads_mode='FIXED';s.render.threads=4
s.cycles.samples=8;s.cycles.use_denoising=True
members=[o for o in s.objects if o.name in ('Processor','Processor cap') or o.name.startswith('Contact')]
assert len(members)>2
root=bpy.data.objects.new('Exploded processor',None);s.collection.objects.link(root)
for obj in members:
 m=obj.matrix_world.copy();obj.parent=root;obj.matrix_world=m
for f in range(18):
 t=f/17;ease=t*t*(3-2*t);root.location.z=.9*ease
 bpy.context.view_layer.update()
 for obj in members:
  for corner in obj.bound_box:
   p=world_to_camera_view(s,s.camera,obj.matrix_world@Vector(corner))
   assert p.z>0 and .02<p.x<.98 and .02<p.y<.98,('Crop',obj.name,f)
 path=OUT/f'{f:06d}.png'
 if path.exists():continue
 s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
print('EXPLODED COMPUTE MOTION READY')
