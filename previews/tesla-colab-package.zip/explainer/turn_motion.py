"""Checked kinematics for an illustrative yield-then-left-turn scene, not a driving policy."""
import math


def smooth(t):
    t=max(0,min(1,t));return t*t*(3-2*t)


def pose(t,duration):
    wait=6.7;end=duration-.35
    if duration<=wait+.5:raise ValueError('Allow time for the crossing and the turn')
    progress=smooth((t-wait)/(end-wait))
    straight=6.;radius=4.3;arc=radius*math.pi/2;exit_length=8.5
    distance=progress*(straight+arc+exit_length)
    if distance<=straight:
        x,y,yaw=1.8,-8.5+distance,0.;steer=0.
    elif distance<=straight+arc:
        theta=(distance-straight)/radius
        x,y,yaw=-2.5+radius*math.cos(theta),-2.5+radius*math.sin(theta),theta
        steer=math.atan(2.84/radius)
    else:
        x,y,yaw=-2.5-(distance-straight-arc),1.8,math.pi/2;steer=0.
    ped_distance=min(12,max(0,t)*1.8)
    return {'ev':(x,y,yaw),'ev_distance':distance,'steer':steer,'other':(-1.8,16-4*t,math.pi),
            'pedestrian':(4.6-ped_distance,-5.,math.pi/2),'walk_distance':ped_distance,
            'phase':'wait' if t<wait else 'turn','progress':progress}


def circle_clearance(car,point,radius=.4):
    x,y,yaw=car;dx,dy=point[0]-x,point[1]-y
    right=dx*math.cos(yaw)+dy*math.sin(yaw)
    forward=-dx*math.sin(yaw)+dy*math.cos(yaw)
    return math.hypot(max(abs(right)-1.1,0),max(abs(forward)-2.4,0))-radius


def rectangles_overlap(a,b):
    def corners(p):
        x,y,angle=p;c,s=math.cos(angle),math.sin(angle)
        return [(x+rx*c-fy*s,y+rx*s+fy*c) for rx,fy in [(-1.1,-2.4),(1.1,-2.4),(1.1,2.4),(-1.1,2.4)]]
    aa,bb=corners(a),corners(b)
    for angle in [a[2],a[2]+math.pi/2,b[2],b[2]+math.pi/2]:
        axis=(math.cos(angle),math.sin(angle))
        pa=[x*axis[0]+y*axis[1] for x,y in aa];pb=[x*axis[0]+y*axis[1] for x,y in bb]
        if max(pa)<min(pb) or max(pb)<min(pa):return False
    return True
