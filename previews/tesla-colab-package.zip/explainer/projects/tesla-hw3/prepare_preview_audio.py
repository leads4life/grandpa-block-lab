"""Freeze measured narration for the first chapter without synthesizing the whole film."""
from pathlib import Path
import math
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
from kokoro_onnx import Kokoro
import os
from explainer.core import read,write,VOICE
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/preview';OUT.mkdir(parents=True,exist_ok=True)
p=read(ROOT/'plan.json');shot=p['shots'][0]
engine=Kokoro(os.environ['KOKORO_MODEL'],os.environ['KOKORO_VOICES'])
clips=[];timeline=[];cursor=.4
for index,beat in enumerate(shot['beats']):
 a,sr=engine.create(beat['text'],voice=VOICE['voice'],speed=VOICE['speed'])[:2]
 a=np.asarray(a,dtype=np.float64);divisor=math.gcd(int(sr),48000)
 a=resample_poly(a,48000//divisor,int(sr)//divisor)
 if not len(a) or not np.isfinite(a).all() or abs(a).max()<1e-5:raise ValueError('Invalid voice output')
 a*=.7/abs(a).max()
 timeline.append({'start':cursor,'end':cursor+len(a)/48000,'text':beat['text'],'beat':index})
 clips.append((round(cursor*48000),a));cursor+=len(a)/48000+.35
seconds=math.ceil((cursor+.6)*30)/30
track=np.zeros(round(seconds*48000))
for start,a in clips:track[start:start+len(a)]+=a
wavfile.write(OUT/'voice.wav',48000,(track*32767).astype(np.int16))
write(OUT/'timing.json',{'seconds':seconds,'frames':round(seconds*30),'timeline':timeline,'voice':VOICE,'claims':shot['claim_ids']})
print('Measured preview:',round(seconds,2),'seconds; three timed narration beats')
