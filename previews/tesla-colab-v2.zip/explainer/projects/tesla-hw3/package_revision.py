"""Versioned JSON/source/media package for v2; never overwrite v1 deliveries."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,shutil,tempfile,zipfile
from explainer.core import read,write
from .produce_revision import source_files

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];ENGINE=REPO/'explainer';OUT=ROOT/'build/full-v2';DELIVERY=ROOT/'deliverables/v2'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def code_files():
    project_names={p.name for p in source_files() if p.parent==ROOT}
    result=[]
    for p in ENGINE.rglob('*.py'):
        relative=p.relative_to(ENGINE)
        if any(x in relative.parts for x in ['build','deliverables','__pycache__']):continue
        if relative.parts[0]=='projects' and (p.parent!=ROOT or p.name not in project_names):continue
        result.append(p)
    return result


def export():
    m=read(OUT/'manifest.json');plan=read(OUT/'plan.json')
    result={'version':2,'title':m['title'],'production_status':read(OUT/'pipeline-state.json') if (OUT/'pipeline-state.json').exists() else {'stage':'preflight'},
            'user_authorization':read(OUT/'authorization.json'),'plan':plan,'manifest':m,
            'retention_check':read(OUT/'retention-check.json'),'audit':read(OUT/'second-audit.json') if (OUT/'second-audit.json').exists() else {'status':'pending'},
            'format':{'native_width':768,'native_height':432,'native_fps':30,'export_width':960,'export_height':540,'export_fps':30,'music':False,'narration_captions':False},
            'procedural_sources':{str(p.relative_to(REPO)):{'sha256':sha(p),'text':p.read_text()} for p in code_files()},
            'bibles':{p.name:p.read_text() for p in sorted((ENGINE/'bibles').glob('*.md'))},
            'chapters':[],'binary_media':'Referenced as separate files; no base64 media in this JSON. Bundled voice and completed clips live in the matching Colab ZIP.','youtube_uploaded':False}
    for shot in m['shots']:
        folder=OUT/shot['id'];item={'id':shot['id'],'voice':read(folder/'voice.json'),'voice_path':str((folder/'voice.wav').relative_to(REPO))}
        for name in ['scene-qa.json','qa.json','render-source.json']:
            if (folder/name).exists():item[name]=read(folder/name)
        if (folder/'chapter.mp4').exists():item['clip_path']=str((folder/'chapter.mp4').relative_to(REPO))
        result['chapters'].append(item)
    if (OUT/'final-qa.json').exists():result['final_qa']=read(OUT/'final-qa.json')
    write(OUT/'tesla-project-v2.json',result);return result


def notebook():
    cells=[]
    def md(text):cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(True)})
    def code(text):cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':text.splitlines(True)})
    md('# Tesla explainer v2 — matching source and media\n\nUpload the **v2 ZIP**. This is a separate production version; keep the original v1 package intact. Frozen narration is included, so no AI API key or voice weights are needed to resume. Checked clips are reused; missing chapters can use a working Colab GPU. Actual Colab/GPU execution has not been tested from this chat. Final viewing and approval remain separate from automated media checks.')
    code('''from pathlib import Path
import hashlib, json, os, subprocess, sys, zipfile
from google.colab import files
uploaded = files.upload()
archives = [name for name in uploaded if name.lower().endswith('.zip')]
if len(archives) != 1: raise ValueError('Upload exactly one v2 project ZIP.')
archive = Path(archives[0])
PACKAGE_ROOT = Path('/content') / ('tesla_v2_' + hashlib.sha256(archive.read_bytes()).hexdigest()[:12])
PACKAGE_ROOT.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as bundle:
    if len(bundle.infolist()) > 2500 or sum(x.file_size for x in bundle.infolist()) > 2*1024**3:
        raise ValueError('Unexpected archive size.')
    for item in bundle.infolist():
        target = (PACKAGE_ROOT / item.filename).resolve()
        if not target.is_relative_to(PACKAGE_ROOT.resolve()) or ((item.external_attr >> 16) & 0o170000) == 0o120000:
            raise ValueError('Unsafe archive entry.')
    bundle.extractall(PACKAGE_ROOT)
production = PACKAGE_ROOT / 'explainer/projects/tesla-hw3/build/full-v2'
manifest = json.loads((production / 'manifest.json').read_text())
def checked_clip_present(shot):
    folder = production / shot['id']
    if not (folder/'chapter.mp4').exists() or not (folder/'qa.json').exists(): return False
    qa = json.loads((folder/'qa.json').read_text())
    return qa.get('passed') and qa.get('video_sha256') == hashlib.sha256((folder/'chapter.mp4').read_bytes()).hexdigest()
all_clips_present = all(checked_clip_present(s) for s in manifest['shots'])
print('Complete clips bundled:', all_clips_present)
''')
    md('## Runtime\n\nWhen all checked clips are present, this reassembles them with the current Python and FFmpeg. A separate Blender environment is installed only if rendering is needed.')
    code('''render_env = dict(os.environ, OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
if all_clips_present:
    RENDER_PYTHON = Path(sys.executable)
else:
    subprocess.run([sys.executable, str(PACKAGE_ROOT / 'explainer/colab/bootstrap.py')], cwd=PACKAGE_ROOT, check=True)
    RENDER_PYTHON = PACKAGE_ROOT / '.colab-render-venv/bin/python'
    USE_GPU = True  # Set False for deliberate CPU fallback.
    render_env['EXPLAINER_FORCE_CPU'] = '0' if USE_GPU else '1'
    subprocess.run([str(RENDER_PYTHON), '-m', 'explainer.projects.tesla-hw3.revision_colab', 'smoke'], cwd=PACKAGE_ROOT, env=render_env, check=True)
''')
    md('## Verify and resume\n\nFrozen source, plan and narration hashes are checked before use. A changed device with existing native frames is rejected to avoid mixing frame versions. Completing the render leaves final inspection pending; it does not fabricate user approval.')
    code("subprocess.run([str(RENDER_PYTHON), '-m', 'explainer.projects.tesla-hw3.revision_colab', 'resume'], cwd=PACKAGE_ROOT, env=render_env, check=True)\n")
    md('## Watch and download\n\nInspect the complete video and its transitions. Native 768×432 at 30fps, denoised and exported at 960×540. The JSON snapshot describes the package at creation; new output QA is in final-qa.json.')
    code("from IPython.display import Video, display\ndisplay(Video(str(production / 'tesla-planning-v2.mp4'), embed=True, width=960))\n")
    code("files.download(str(production / 'tesla-planning-v2.mp4'))\n")
    code("files.download(str(production / 'tesla-project-v2.json'))\n")
    for i,c in enumerate(cells):
        c['id']=f'v2-{i:02d}'
        if c['cell_type']=='code':compile(''.join(c['source']),f'v2-cell-{i}','exec')
    return {'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'name':'python3','display_name':'Python 3'},'language_info':{'name':'python'},'colab':{'name':'Tesla_Explainer_v2_Colab.ipynb'}},'cells':cells}


def build():
    export();DELIVERY.mkdir(parents=True,exist_ok=True);nb=notebook();write(DELIVERY/'Tesla_Explainer_v2_Colab.ipynb',nb)
    manifest=read(OUT/'manifest.json')
    with tempfile.TemporaryDirectory(prefix='tesla-v2-package-') as temp:
        stage=Path(temp);immutable={};included={}
        def copy(path,mutable=False):
            path=Path(path);name=str(path.relative_to(REPO));target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
            included[name]=sha(path)
            if not mutable:immutable[name]=included[name]
        for path in code_files():copy(path)
        for path in [*sorted((ENGINE/'bibles').glob('*.md')),ENGINE/'AGENTS.md',ENGINE/'README.md',ENGINE/'requirements.txt',ENGINE/'colab/render-requirements.txt']:
            copy(path)
        for path in (ENGINE/'examples').rglob('*'):
            if path.is_file() and path.suffix in ['.json','.md']:copy(path)
        for path in [ROOT/'plan.json',ROOT/'retention-v2/script-and-retention-draft.json',ROOT/'sources/patent.txt',ROOT/'sources/tesla-fsd.txt']:
            copy(path)
        for name in ['plan.json','manifest.json','authorization.json','preflight-review.json','retention-check.json','storyboard.md','second-audit.json','second-audit.md','tesla-project-v2.json']:
            if (OUT/name).exists():copy(OUT/name)
        for shot in manifest['shots']:
            folder=OUT/shot['id']
            for name in ['voice.wav','voice.json','scene-qa.json','poses.json','render-source.json','qa.json','chapter.mp4']:
                if (folder/name).exists():copy(folder/name,mutable=name not in ['voice.wav','voice.json'])
        for name in ['final-qa.json','pipeline-state.json','CREDITS.md']:
            if (OUT/name).exists():copy(OUT/name,mutable=True)
        write(stage/'V2_PACKAGE.json',{'version':2,'created_utc':datetime.now(timezone.utc).isoformat(),'immutable_sha256':immutable,'initial_file_sha256':included,'complete_clips':[s['id'] for s in manifest['shots'] if (OUT/s['id']/'chapter.mp4').exists()],'voice_weights_included':False,'full_movie_included':False,'colab_gpu_execution_tested':False})
        (stage/'README.md').write_text('# Tesla explainer v2\n\nUse the matching v2 notebook. Sources, frozen narration and any completed clips are included. Native frames and voice weights are excluded. This is a separate version, not an overlay for v1. No YouTube upload or final user approval is implied. Read explainer/AGENTS.md and the production storyboard/audit.\n')
        archive=DELIVERY/'tesla-colab-v2.zip'
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
            for path in sorted(stage.rglob('*')):
                if path.is_file():bundle.write(path,str(path.relative_to(stage)))
    assert archive.stat().st_size<100*1024**2,'Split media delivery rather than exceeding the artifact host limit'
    (DELIVERY/'tesla-colab-v2.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
    print('V2 PACKAGE',archive,archive.stat().st_size,'bytes',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--export-only',action='store_true');a=p.parse_args()
    export() if a.export_only else build()
