import copy,unittest
from explainer.retention import audit,content_hash,require

def fixture():
    plan={'shots':[{'id':'a','duration':20,'narration':'Which choice matters? You will learn to trace it. Waiting leaves room.'},
                   {'id':'b','duration':20,'narration':'What survives? The road user stays visible. The branch is removed.'}],
          'claims':{'c':{'status':'verified','sources':['primary']}},'sources':{'primary':{'supports':'Synthetic test source'}}}
    plan['retention']={'version':1,'timing_basis':'estimated',
       'opening':{'viewer_value':'Trace a candidate','visual_action':'Show the conflict','reason_to_care':'Avoid confusing decisions with agents',
                  'value_promise':{'shot':'a','at':2,'quote':'You will learn to trace it.'}},
       'rungs':[{'id':'r1','viewer_question':'Which choice?','new_knowledge':'Why waiting is useful','visual_payoff':'Traffic clears',
                 'audio_direction':'Emphasize choice, maintain pace','claim_ids':['c'],'next_rung':'r2',
                 'prompt':{'shot':'a','at':0,'quote':'Which choice matters?'},'payoff':{'shot':'a','at':9,'quote':'Waiting leaves room.'}},
                {'id':'r2','viewer_question':'What stays represented?','new_knowledge':'Agents remain after a branch is removed',
                 'visual_payoff':'Retain the actor, remove its candidate link','audio_direction':'Pause briefly before the reveal','claim_ids':['c'],
                 'prompt':{'shot':'b','at':0,'quote':'What survives?'},'payoff':{'shot':'b','at':7,'quote':'The road user stays visible.'}}]}
    return plan

class RetentionTests(unittest.TestCase):
    def test_draft_can_pass_structure_without_claiming_audience_results(self):
        result=audit(fixture());self.assertTrue(result['passed'],result['errors']);self.assertTrue(result['warnings'])
        self.assertIn('no measured audience retention',result['scope'])
    def test_missing_ladder_is_reported(self):
        self.assertFalse(audit({'shots':[]})['passed'])
    def test_invented_spoken_promise_is_rejected(self):
        p=fixture();p['retention']['rungs'][0]['prompt']['quote']='Secret upgrade coming soon'
        self.assertIn('quote is absent',';'.join(audit(p)['errors']))
    def test_payoff_must_occur_after_prompt(self):
        p=fixture();p['retention']['rungs'][0]['payoff']['at']=0
        self.assertIn('payoff must follow',';'.join(audit(p)['errors']))
    def test_unverified_claim_cannot_be_used_as_hook(self):
        p=fixture();p['claims']['c']['status']='unverified'
        self.assertIn('unverified',';'.join(audit(p)['errors']))
    def test_unpaid_carrot_is_rejected(self):
        p=fixture();p['shots'][1]['duration']=100;p['retention']['rungs'][0]['payoff']={'shot':'b','at':60,'quote':'The branch is removed.'}
        self.assertIn('unpaid too long',';'.join(audit(p)['errors']))
    def test_long_value_drought_is_rejected(self):
        p=fixture();p['shots'][1]['duration']=100
        self.assertIn('Long stretch',';'.join(audit(p)['errors']))
    def test_dangling_followup_is_rejected(self):
        p=fixture();p['retention']['rungs'][0]['next_rung']='never_paid'
        self.assertIn('Dangling',';'.join(audit(p)['errors']))
    def test_music_and_repeated_reward_are_rejected(self):
        p=fixture();p['retention']['rungs'][0]['music']=True;p['retention']['rungs'][1]['new_knowledge']=p['retention']['rungs'][0]['new_knowledge']
        result=';'.join(audit(p)['errors']);self.assertIn('music',result);self.assertIn('repeats',result)
    def test_nonfinite_or_boolean_times_do_not_pass(self):
        for value in [float('nan'),float('inf'),True]:
            p=fixture();p['retention']['rungs'][0]['prompt']['at']=value
            self.assertFalse(audit(p)['passed'])
    def test_estimated_timing_cannot_authorize_production(self):
        with self.assertRaisesRegex(ValueError,'measured'):require(fixture(),review=True)
    def test_review_goes_stale_when_script_changes(self):
        p=fixture();p['retention']['timing_basis']='measured'
        p['narration_lock']={s['id']:{'text':s['narration'],'sha256':'0'*64,'seconds':10} for s in p['shots']}
        p['retention']['review']={'status':'passed','content_sha256':content_hash(p),'script_notes':'Synthetic test only','visual_notes':'Synthetic test only','audio_notes':'Synthetic test only'}
        self.assertTrue(audit(p,require_review=True)['passed'])
        p['shots'][1]['narration']+=' Changed.'
        self.assertIn('Current editorial',';'.join(audit(p,require_review=True)['errors']))
    def test_cycles_and_missing_sources_are_rejected(self):
        p=fixture();p['retention']['rungs'][1]['next_rung']='r1';p['sources']={}
        errors=';'.join(audit(p)['errors']);self.assertIn('forward',errors);self.assertIn('source reference',errors)
    def test_malformed_points_are_reported_without_crashing(self):
        p=fixture();p['retention']['rungs'][0]['prompt']['shot']=[]
        p['retention']['rungs'][1]['claim_ids']=[{}]
        p['retention']['rungs'][1]['next_rung']={}
        self.assertFalse(audit(p)['passed'])
    def test_new_project_is_marked_retention_required(self):
        import tempfile,json
        from pathlib import Path
        from explainer.__main__ import main
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'synthetic'
            main(['init',str(target),'--title','Synthetic retention gate test'])
            self.assertTrue(json.loads((target/'plan.json').read_text())['retention_required'])
