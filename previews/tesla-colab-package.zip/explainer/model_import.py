"""Static reviewed model instances: preserve materials, hierarchy and relative proportions."""
from pathlib import Path
import json
import bpy
from mathutils import Vector
from .assets import inside, model_errors, sha


def import_component(component, asset, project_root):
    errors = model_errors(asset, project_root)
    if asset.get('review') != 'approved': errors.append('Model requires visual/accuracy review')
    path = inside(project_root, asset['path'])
    if sha(path) != asset.get('sha256'): errors.append('Primary model checksum changed')
    if errors: raise ValueError('\n'.join(errors))
    before = set(bpy.data.objects)
    suffix = path.suffix.lower()
    bpy.context.preferences.filepaths.use_scripts_auto_execute = False
    if suffix in ('.gltf', '.glb'):
        bpy.ops.import_scene.gltf(filepath=str(path), import_pack_images=True)
    elif suffix == '.obj':
        bpy.ops.wm.obj_import(filepath=str(path), forward_axis='NEGATIVE_Z', up_axis='Y')
    elif suffix == '.stl':
        bpy.ops.wm.stl_import(filepath=str(path), forward_axis='Y', up_axis='Z')
    else:
        raise ValueError('Unsupported model format')
    imported = set(bpy.data.objects) - before
    # A model may carry cameras, lights or animation unrelated to the approved storyboard.
    # Static assembly import is intentional; source animation is not advertised as supported.
    for obj in list(imported):
        obj.animation_data_clear()
        if obj.type == 'MESH' and obj.data.shape_keys:
            obj.data.shape_keys.animation_data_clear()
        if obj.type in ('LIGHT', 'CAMERA'):
            for child in list(obj.children):
                matrix = child.matrix_world.copy()
                child.parent = None
                child.matrix_world = matrix
            imported.remove(obj)
            bpy.data.objects.remove(obj, do_unlink=True)
    meshes = [obj for obj in imported if obj.type == 'MESH']
    if not meshes or not any(len(obj.data.polygons) for obj in meshes):
        raise ValueError('Imported model contains no renderable mesh faces')
    bpy.context.view_layer.update()
    corners = [obj.matrix_world @ Vector(corner) for obj in meshes for corner in obj.bound_box]
    low = Vector(tuple(min(p[axis] for p in corners) for axis in range(3)))
    high = Vector(tuple(max(p[axis] for p in corners) for axis in range(3)))
    center = (low+high)*.5
    if (high-low).length < 1e-9: raise ValueError('Model has zero-size geometry')
    root = bpy.data.objects.new(component['id'], None)
    bpy.context.collection.objects.link(root)
    container = bpy.data.objects.new(component['id']+'_source', None)
    bpy.context.collection.objects.link(container)
    names = {}
    for obj in imported:
        old_name = obj.name
        obj.name = component['id']+'::'+old_name
        names[old_name] = obj.name
        if obj.parent not in imported:
            matrix = obj.matrix_world.copy()
            obj.parent = container
            obj.matrix_world = matrix
    container.parent = root
    meters = asset['meters_per_unit']
    container.scale = (meters,)*3
    container.location = -center*meters
    root.scale = (component.get('scale', 1),)*3
    root['asset_path'] = asset['path']
    root['source_names'] = json.dumps(names, sort_keys=True)
    root['source_bounds'] = json.dumps([list(low), list(high)])
    # Packed images keep the saved .blend self-contained; package hashes still govern approvals.
    for obj in meshes:
        for mat in obj.data.materials:
            if mat and mat.use_nodes:
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.image and not node.image.packed_file:
                        node.image.pack()
    return root, meshes
