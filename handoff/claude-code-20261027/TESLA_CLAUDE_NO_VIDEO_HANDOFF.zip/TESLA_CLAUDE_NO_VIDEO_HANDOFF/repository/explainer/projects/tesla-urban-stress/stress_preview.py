"""Render a separate 30-second urban test with the delivered opening's exact audio."""
from pathlib import Path
from datetime import datetime,timezone
from importlib import import_module
import argparse,hashlib,json,subprocess,sys
from PIL import Image,ImageDraw,ImageFont
from explainer.core import read,write
from explainer.media import check_video

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'build/full-v2';REPO=ROOT.parents[2]
MAIN=ROOT.parent/'tesla-hw3/build/full-v2'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def audio_packet_hashes(path):
    result=subprocess.run(['ffprobe','-v','error','-select_streams','a:0','-show_packets','-show_data_hash','sha256','-show_entries','packet=data_hash','-of','json',str(path)],capture_output=True,text=True,check=True)
    return [p['data_hash'] for p in json.loads(result.stdout)['packets']]


def verify_inputs():
    m=read(OUT/'manifest.json');original=read(OUT/'reference-manifest.json')
    for i,shot in enumerate(m['shots']):
        for key in ['narration','seconds','thought_groups','voice_sha256']:
            assert shot[key]==original['shots'][i][key],('Original script or timing changed',key)
        assert sha(OUT/shot['id']/'voice.wav')==shot['voice_sha256']
    auth=read(OUT/'authorization.json');assert sha(OUT/'reference-opening.mp4')==auth['reference_opening_sha256']
    review=read(OUT/'preflight-review.json');assert review['passed'] and review['purpose']=='authorized_urban_environment_test'
    for name,expected in review['source_hashes'].items():assert sha(REPO/name)==expected,('Urban preflight source changed',name)
    return m


def encode():
    m=verify_inputs();decorate=import_module('explainer.projects.tesla-hw3.produce_revision').decorate
    parts=[(m['shots'][0],0,709),(m['shots'][1],0,191)]
    for shot,a,b in parts:
        folder=OUT/shot['id'];assert read(folder/'scene-qa.json')['passed']
        assert all((folder/'raw'/f'{f:06d}.png').is_file() for f in range(a,b))
    poses={s['id']:read(OUT/s['id']/'poses.json') for s,_,_ in parts}
    video=OUT/'tesla-urban-grit-stress-30s.mp4';reference=OUT/'reference-opening.mp4'
    command=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-framerate','30','-i','pipe:0','-i',str(reference),'-map','0:v:0','-map','1:a:0','-frames:v','900','-t','30','-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(video)]
    with (OUT/'encode.log').open('wb') as log:
        process=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=log)
        try:
            for shot,a,b in parts:
                for f in range(a,b):
                    with Image.open(OUT/shot['id']/'raw'/f'{f:06d}.png') as im:
                        picture=decorate(im,poses[shot['id']][str(f)],shot['mode'])
                    process.stdin.write(picture.tobytes())
            process.stdin.close();assert process.wait()==0,(OUT/'encode.log').read_text()
        except BaseException:
            process.kill();process.wait();raise
    qa=check_video(video,30,960,540);assert qa['passed'],qa
    expected=audio_packet_hashes(reference);actual=audio_packet_hashes(video);assert expected==actual,'Audio changed in the environment comparison'
    qa.update(status='ready_for_visual_review',visual_review='pending',user_style_approval='not_recorded',seconds=30,native_frames=900,video_sha256=sha(video),reference_opening_sha256=sha(reference),exact_encoded_audio_preserved=True,audio_packets=len(actual),script_unchanged=True,actor_motion_and_narration_timing_unchanged=True,environment='Original procedural industrial-neighborhood stress test',main_production_modified=False,limitations=['Schematic rig and original generic props; not manufacturer CAD or a game-engine reconstruction.','No claim of subjective auditory audition; encoded audio matches the delivered reference packet for packet.'])
    write(OUT/'qa.json',qa)
    decoded=OUT/'decoded-review';decoded.mkdir(exist_ok=True)
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-vf',"select='not(mod(n,30))',scale=480:270",'-fps_mode','vfr','-start_number','0',str(decoded/'%03d.png')],check=True)
    frames=sorted(decoded.glob('*.png'));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
    for start in range(0,len(frames),12):
        selected=frames[start:start+12];sheet=Image.new('RGB',(1440,((len(selected)+2)//3)*296),'#081420');draw=ImageDraw.Draw(sheet)
        for i,path in enumerate(selected):
            x=i%3*480;y=i//3*296
            with Image.open(path) as im:sheet.paste(im,(x,y))
            draw.text((x+8,y+278),f'{start+i}s · urban environment test',font=font,fill='white')
        sheet.save(OUT/f'decoded-review-{start//12:02d}.jpg',quality=95)
    subprocess.run(['ffmpeg','-v','error','-y','-ss','13','-i',str(video),'-frames:v','1',str(OUT/'poster.jpg')],check=True)
    write(OUT/'pipeline-state.json',{'stage':'awaiting_actual_visual_review','seconds':30,'encoded_audio_identical_to_reference':True,'user_style_approval':'not_recorded','main_production_modified':False})
    print('URBAN THIRTY-SECOND TEST ENCODED; VISUAL REVIEW PENDING',video,flush=True)


def run():
    m=verify_inputs()
    try:
        for i,(shot,count) in enumerate(zip(m['shots'],[709,191])):
            write(OUT/'pipeline-state.json',{'stage':'rendering_urban_test','section':i+1,'sections':2,'chapter_id':shot['id'],'target_native_frames':count,'total_test_frames':900,'same_script':True,'same_audio':True,'main_production_modified':False,'updated_utc':datetime.now(timezone.utc).isoformat()})
            subprocess.run([sys.executable,'-m','explainer.projects.tesla-urban-stress.render_revision','--index',str(i),'--frames',*[str(f) for f in range(count)]],check=True)
        write(OUT/'pipeline-state.json',{'stage':'encoding_urban_test','same_script':True,'same_audio':True,'main_production_modified':False})
        encode()
    except BaseException as e:
        write(OUT/'pipeline-error.json',{'type':type(e).__name__,'message':str(e),'utc':datetime.now(timezone.utc).isoformat()});raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');parser.add_argument('--encode',action='store_true');args=parser.parse_args()
    if args.run:run()
    elif args.encode:encode()
